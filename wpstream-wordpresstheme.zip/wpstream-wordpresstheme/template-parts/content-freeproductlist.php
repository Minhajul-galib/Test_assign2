<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WpStream WordpressTheme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<?php
            global $wpstream_row_number;
            
            $class_no=3;
            $design_type        = wpstream_get_option('wpstream_unit_card');
            $wpstream_layout    = get_post_meta( get_the_ID(), 'page_layout', true);
            
            if($design_type==2){
                $class_no= wpstream_get_option('wpstream_unit2_per_row');
                if($class_no >3 &&($wpstream_layout!=3 && $wpstream_layout!=4) ){
                    $class_no=$class_no-1;
                }

            }else if($design_type==1){
                if( $wpstream_layout==1 || $wpstream_layout==2){
                    $class_no=2;
                }else{
                    $class_no=3;
                }
            }
            $wpstream_row_number=$class_no;
        ?>
        
        <div class=" columns-<?php echo $class_no; echo ' s'.$wpstream_layout; ?>">
            <ul class="products columns-<?php echo $class_no; ?>">
                <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 0;
                $args = array(
                    'post_type' => 'wpstream_product',
                    'paged'     => $paged,
                    'status'    =>'published'
                );
                $blog_selection = new WP_Query($args);
                global $count;
                $count=0;
                while ($blog_selection->have_posts()): $blog_selection->the_post();
                    get_template_part('templates/free_product_unit');
                    $count++;
                endwhile;
                wp_reset_query();	
           
                ?>
            </ul>
            <?php  echo    wpstream_pagination($blog_selection->max_num_pages, $range = 2);            ?>
        </div>

        
        
</article><!-- #post-<?php the_ID(); ?> -->
