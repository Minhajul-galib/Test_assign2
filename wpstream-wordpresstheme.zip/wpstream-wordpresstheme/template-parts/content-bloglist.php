<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WpStream WordpressTheme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
	</header><!-- .entry-header -->

        <?php
        global $wpstream_layout;
        global $wpstream_row_number;
      
        $wpstream_layout = get_post_meta( get_the_ID(), 'page_layout', true);
        $blog_list_class    = 'columns-2';
        $wpstream_row_number         =  2;
        if($wpstream_layout==3 || $wpstream_layout==4){
            $blog_list_class    =   'columns-3';
            $wpstream_row_number         =   3;
        }
        
        ?>
        
	
        <ul class="blog_list_wrapper products  <?php echo $blog_list_class; ?>">
            <?php
            global $count;
            $count=0;
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 0;
            $args = array(
                'post_type' => 'post',
                'paged'     => $paged,
                'status'    =>'published'
            );
            $blog_selection = new WP_Query($args);
            
                while ($blog_selection->have_posts()): $blog_selection->the_post();
                    get_template_part('templates/blog_unit');
                    $count++;
                endwhile;
            
            wp_reset_query();	
            wpstream_pagination($blog_selection->max_num_pages, $range = 2);            
            ?>
        </ul>

        
        
</article><!-- #post-<?php the_ID(); ?> -->
