<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WpStream WordpressTheme
 */

$footer_class   =   '';
$footer_style   =   '';

$wide_footer  = wpstream_get_option('wide_footer');
    if($wide_footer == '1'){
        $footer_class=' wide_footer';
}

$show_subfooter      =   wpstream_get_option('sub_footer_section');
$sub_footer_nav      =   wpstream_get_option('sub_footer_nav');
$subfooter_copyright =   wpstream_get_option('subfooter_copyright');
$footer_background   =   wpstream_get_option('footer_background_image','url');
if($footer_background != ''){
        $footer_style='style=" background-image: url('.$footer_background.') "';
}

$repeat_footer_back_status  =   wpstream_get_option('repeat_footer_back');
if( $repeat_footer_back_status=='repeat' ){
    $footer_back_class = ' footer_back_repeat ';
}else if( $repeat_footer_back_status=='repeat x' ){
    $footer_back_class = ' footer_back_repeat_x ';
}else if( $repeat_footer_back_status=='repeat y' ){
    $footer_back_class = ' footer_back_repeat_y ';
}else if( $repeat_footer_back_status=='no repeat' ){
    $footer_back_class = ' footer_back_repeat_no ';
}


?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer <?php print $footer_back_class;?>" <?php print $footer_style; ?>>
          
                <div class="footer-wrapper <?php echo $footer_class; ?>" >
                    <?php  get_sidebar('footer');?>
                </div>
            <?php  if($show_subfooter == '1'){?>
		<div class="site-info <?php echo $footer_class; ?>">
                    <div class="site-footer-wrapper">
                        <span class="copyright">
                            <?php  
                            print $subfooter_copyright;
                            if(is_front_page()){
                                print '<span class="powered_by_wpstream">, Powered by <a href="https://wpstream.net" target="_blank">WpStream</a></span>';
                            }
                            ?>
                        </span>
                        <?php if($sub_footer_nav == '1'){     
                                wp_nav_menu( array(
                                    'theme_location'    => 'footer_menu',
                                    'depth'             => 1   ,
                                    'container_class'   => 'footer_menu_wrapper'
                                ));  
                            }
                        ?>
                    </div>
		</div><!-- .site-info -->
            <?php } ?>
                
          
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php 
wp_footer();
?>

</body>
</html>
