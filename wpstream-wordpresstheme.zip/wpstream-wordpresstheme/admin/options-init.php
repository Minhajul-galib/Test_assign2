<?php

    /**
     * For full documentation, please visit: http://docs.reduxframework.com/
     * For a more extensive sample-config file, you may look at:
     * https://github.com/reduxframework/redux-framework/blob/master/sample/sample-config.php
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "redux_builder_wpstream";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name' => 'redux_builder_wpstream',
        'display_name' => $theme->get( 'Name' ),
        'display_version' => $theme->get( 'Version' ),
        'page_slug' => 'wpstream_options',
        'page_title' => 'Theme Options',
        'update_notice' => false,
        //'intro_text' => 'intro_text',
       // 'footer_text' => 'footer text',
        'admin_bar' => TRUE,
        'menu_type' => 'menu',
        'menu_title' => 'WpStream Theme',
        'allow_sub_menu' => TRUE,
        'page_parent_post_type' => 'your_post_type',
        'customizer' => TRUE,
        //'default_mark' => '*',
        'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
        'class' => 'wpstream',
        'hints' => array(
            'icon_position' => 'right',
            'icon_size' => 'normal',
            'tip_style' => array(
                'color' => 'light',
            ),
            'tip_position' => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect' => array(
                'show' => array(
                    'duration' => '500',
                    'event' => 'mouseover',
                ),
                'hide' => array(
                    'duration' => '500',
                    'event' => 'mouseleave unfocus',
                ),
            ),
        ),
        'output' => TRUE,
        'output_tag' => TRUE,
        'settings_api' => TRUE,
        'show_options_object' => false,
        'cdn_check_time' => '1440',
        'compiler' => TRUE,
        'page_permissions' => 'manage_options',
        'save_defaults' => TRUE,
        'show_import_export' => TRUE,
        'database' => 'options',
        'transient_time' => '3600',
        'network_sites' => TRUE,
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
//    $args['share_icons'][] = array(
//        'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
//        'title' => 'Visit us on GitHub',
//        'icon'  => 'el el-github'
//        //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
//    );
//    $args['share_icons'][] = array(
//        'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
//        'title' => 'Like us on Facebook',
//        'icon'  => 'el el-facebook'
//    );
//    $args['share_icons'][] = array(
//        'url'   => 'http://twitter.com/reduxframework',
//        'title' => 'Follow us on Twitter',
//        'icon'  => 'el el-twitter'
//    );
//    $args['share_icons'][] = array(
//        'url'   => 'http://www.linkedin.com/company/redux-framework',
//        'title' => 'Find us on LinkedIn',
//        'icon'  => 'el el-linkedin'
//    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'wpstream-wordpresstheme' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'wpstream-wordpresstheme' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'wpstream-wordpresstheme' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'wpstream-wordpresstheme' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'wpstream-wordpresstheme' );
    Redux::setHelpSidebar( $opt_name, $content );


              
              
              
              
              
              
    Redux::setSection( $opt_name, array(
        'title'  => __( 'General Settings', 'wpstream-wordpresstheme' ),
        'id'     => 'general-settings',
        'desc'   => __( 'WpStream Theme-General Settings', 'wpstream-wordpresstheme' ),
        'icon'   => 'el el-cog',
        'fields' => array(
           
            array(
                'id'       => 'wp_estate_google_analytics_code',
                'type'     => 'text',
                'title'    => __( 'Google Analytics Tracking id (ex UA-41924406-1', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Google Analytics Tracking id (ex UA-41924406-1)', 'wpstream-wordpresstheme' ),
            ),
            
            array(
                'id'       => 'wpstream_enable_user_pass',
                'type'     => 'button_set',
                'title'    => __( 'Users can type the password on registration form', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'If no, users will get the auto generated password via email', 'wpstream-wordpresstheme' ),
                'options'  => array(
                    'yes' => 'yes',
                    'no'  => 'no'
                    ),
                'default'  => 'no',
            ),
        )
    ) );
    
     Redux::setSection( $opt_name, array(
        'title'      => __( 'Logo & Favicon', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Logo & Favicon','wpstream-wordpresstheme' ),
        'id'         => 'header-logo-subsection',
        'subsection' => true,
        'fields'     => array(
        
            
        array(
                'id'       => 'wpstream_use_retina',
                'type'     => 'button_set',
                'title'    => __( 'Use retina images for logos', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'If you want to use retina images you need to manualy upload a retina version of that image in the same folder as the original one. The uploaded image must have the _2x at the end . For example logo.png becomes logo_2x.png', 'wpstream-wordpresstheme' ),
                'default'  => 0,
                'options'   => array(0=>'off',1=>'on'),
            ),
            
        array(
            'id'		=> 'header_logo',
            'url'		=> true,
            'type'		=> 'media',
            'title'		=> esc_html__( 'Header Logo', 'wpstream-wordpresstheme' ),
            'read-only'         => false,
            'default'           => '',
            'subtitle'          => esc_html__( 'Custom Header Logo', 'wpstream-wordpresstheme' ),
        ),
        array(
            'id'		=> 'transparent_header_logo',
            'url'		=> true,
            'type'		=> 'media',
            'title'		=> esc_html__( 'Transparent Header Logo', 'wpstream-wordpresstheme' ),
            'read-only'         => false,
            'default'           => '',
            'subtitle'          => esc_html__( 'Custom Header Logo', 'wpstream-wordpresstheme' ),
        ),
        array(
            'id'		=> 'sticky_header_logo',
            'url'		=> true,
            'type'		=> 'media',
            'title'		=> esc_html__( 'Sticky Header Logo', 'wpstream-wordpresstheme' ),
            'read-only'         => false,
            'default'           => '',
            'subtitle'          => esc_html__( 'Custom Sticky Header Logo', 'wpstream-wordpresstheme' ),
        ),
            array(
            'id'		=> 'mobile_header_logo',
            'url'		=> true,
            'type'		=> 'media',
            'title'		=> esc_html__( 'Mobile Header Logo', 'wpstream-wordpresstheme' ),
            'read-only'         => false,
            'default'           => '',
            'subtitle'          => esc_html__( 'Custom Mobile Header Logo', 'wpstream-wordpresstheme' ),
        ),
            array(
            'id'		=> 'fav_icon',
            'url'		=> true,
            'type'		=> 'media',
            'title'		=> esc_html__( 'Favicon', 'wpstream-wordpresstheme' ),
            'read-only'         => false,
            'default'           => '',
            'subtitle'          => esc_html__( 'Custom Favicon', 'wpstream-wordpresstheme' ),
        ),
           
        )
    ) );
     
       Redux::setSection( $opt_name, array(
        'title'      => __( 'Layout', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Layout','wpstream-wordpresstheme' ),
        'id'         => 'site_layout-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
               'id'       => 'content_width',
               'type'     => 'text',
               'title'    => __( 'Content Width (In Percent)', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Content Width (In Percent)', 'wpstream-wordpresstheme' ),
            ),
           
        )
    ) );
     
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Design Elements', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Design Elements','wpstream-wordpresstheme' ),
        'id'         => 'design_elements-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'wpstream_unit_card',
                'type'     => 'button_set',
                'title'    => __( 'Product/Free Product Unit Design', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Product/Free Product Design', 'wpstream-wordpresstheme' ),
                'default'  => 1,
                'options'   => array(1=>'type 1',2=>'type 2'),
            ),
            array(
                'id'       => 'wpstream_unit2_per_row',
                'type'     => 'button_set',
                'title'    => __( 'No of Product/Free Product units per full row (Works for Type 2)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'If you use a sidebar and the number of units is bigger than 3 we will substract 1', 'wpstream-wordpresstheme' ),
                'default'  => 6,
                'options'   => array(3=>'3',4=>'4',5=>'5',6=>'6'),
            ),
     
            array(
               'id'       => 'movie_type_label',
               'type'     => 'text',
               'title'    => __( 'Movie Type Label', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Movie Type Label - on show page', 'wpstream-wordpresstheme' ),
               'default'  => esc_html__('Movie Type','wpstream-wordpresstheme')
            ),
            array(
               'id'       => 'cast_label',
               'type'     => 'text',
               'title'    => __( 'Cast Label', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Cast Label - on show page', 'wpstream-wordpresstheme' ),
                'default'  => esc_html__('Cast','wpstream-wordpresstheme')
            ),
            array(
               'id'       => 'rating_label',
               'type'     => 'text',
               'title'    => __( 'Rating Label', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Rating Label - on show page', 'wpstream-wordpresstheme' ),
               'default'  => esc_html__('Rating','wpstream-wordpresstheme')
            ),
        )
        ));   
       
    
    

    Redux::setSection( $opt_name, array(
        'title' => __( 'Header', 'wpstream-wordpresstheme' ),
        'id'    => 'header-section',
        'desc'  => __( 'Basic fields as subsections.', 'wpstream-wordpresstheme' ),
        'icon'  => 'el el-photo'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Header Details','wpstream-wordpresstheme' ),
        'id'         => 'header-details-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'show_top_bar_user_menu',
                'type'     => 'switch',
                'title'    => __( 'Show top bar widget menu ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Enable or disable top bar widget area.', 'wpstream-wordpresstheme' ),
                'default'  => 'Default Text',
            ),
            
             array(
                'id'       => 'show_login_in_header',
                'type'     => 'button_set',
                'title'    => __( 'Show login in header and mobile menu', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Show Menu and login icon in header and mobile menu.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'no'  => 'no', 
                            'yes' => 'yes'
                            ),
                'default'  => 'yes',
            ),
            
            
            array(
                'id'       => 'global_header_transparent',
                'type'     => 'switch',
                'title'    => __( 'Global Transparent Header', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Global Transparent Header', 'wpstream-wordpresstheme' ),
                'default'  => 'Default Text',
            ),
            
            array(
                'id'       => 'header_type',
                'type'     => 'button_set',
                'title'    => __( 'Header Type', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Header Type', 'wpstream-wordpresstheme' ),
                'default'  => 'type 1',
                'options'   => array(1=>'type 1',2=>'type 2'),
            ),
            
            array(
                'id'       => 'header_align',
                'type'     => 'select',
                'title'    => __( 'Header Align(Logo Position)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select header alignment.', 'wpstream-wordpresstheme' ),
                'default'  => 'left',
                'options'   => array(1=>'left',2=>'center',3=>'right'),
            ),
             array(
                'id'       => 'wide_header',
                'type'     => 'switch',
                'title'    => __( 'Wide Header', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Wide Header', 'wpstream-wordpresstheme' ),
                'default'  => 'Default Text',
            ),
             array(
                'id'       => 'show_top_bar_cart_icon',
                'type'     => 'switch',
                'title'    => __( 'Show cart icon in header?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Show cart icon in header?', 'wpstream-wordpresstheme' ),
                'default'  => true,
            ),
            
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header Media', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Header Media Details','wpstream-wordpresstheme' ),
        'id'         => 'header-media-details-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'media_header_type',
                'type'     => 'select',
                'title'    => __( 'Select Media Header', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select Media Header', 'wpstream-wordpresstheme' ),
                'default'  => 'type 1',
                'options'   => array(
                    1   =>  'none',
                    2   =>  'Image',
                    3   =>  'Revolution Slider',
                    4   =>  'Theme slider',
                  ),
            ),  
         
            
            
            array(
                'id'       => 'global_revolution_slider',
                'type'     => 'text',
                'required' => array('media_header_type', '=', '3'),
                'title'    => __( 'Global Revolution Slider', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Global Revolution Slider', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
            
            
            array(
                'id'       => 'global_header_static_image',
                'type'     => 'media',
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Global Header Static Image', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Global Header Static Image', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
             array(
                'id'       => 'global_header_static_image_height',
                'type'     => 'text',
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Global Header Static Image Height', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'The image will be used as background of a div', 'wpstream-wordpresstheme' ),
                'default'  => '500',
              
            ), 
            array(
                'id'       => 'global_header_static_image_height_back_type',
                'type'     => 'select',
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'default'  => 'cover',
                'options'   => array('cover','contain'),
            ),
            array(
                'id'       => 'wp_estate_paralax_header',
                'type'     => 'button_set',
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Parallax efect for image/video header media ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Enable parallax efect for image/video media header.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            
            array(
               'id'       => 'global_header_title_over_image',
               'type'     => 'text',
               'required' => array('media_header_type', '=', '2'),
               'title'    => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
            ),
             array(
               'id'       => 'global_header_subtitle_over_image',
               'type'     => 'text',
                'required' => array('media_header_type', '=', '2'),
               'title'    => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
            ),
            
            
            array(
                'id'       => 'global_header_overlay_color',
                'type'     => 'color',                
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Header Overlay color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Header Overlay color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
               array(
                'id'       => 'global_header_overlay_opacity',
                'type'     => 'text',
                'required' => array('media_header_type', '=', '2'),
                'title'    => __( 'Header Overlay Opacity', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Overlay Opacity(betwen 0 and 1 , Ex:0.5, default 0.6)', 'wpstream-wordpresstheme' ),
                'default'  => '0.6',
              
            ), 
            
    
            array(
                'id'       => 'video_header_mp4',
                'type'     => 'media',
                'required' => array('media_header_type', '=', '5'),
                'class'    => 'video_splash',
                'url'      => true,
                'preview'  => false,
                'mode'     => false,
                'title'    => __( 'Video in mp4 format', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Video in mp4 format', 'wpstream-wordpresstheme' ),
            ),
            
            
            
            
            
            
            
            
            
            
            ////////////
            array(
                'id'       => 'media_header_type_taxonomy',
                'type'     => 'select',
                'title'    => __( 'Select Media Header for Categories', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select Media Header for Categories', 'wpstream-wordpresstheme' ),
                'default'  => 'type 1',
                'options'   => array(
                    0   => 'global',
                    1   =>  'none',
                    2   =>  'Image',
                    3   =>  'Revolution Slider',
                    4   =>  'Theme slider',
                    ),
            ),  
            
            
            
            array(
                'id'       => 'tax_header_revolution_slider',
                'type'     => 'text',
                'required' => array('media_header_type_taxonomy', '=', '3'),
                'title'    => __( 'Category Header Revolution Slider', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Category Header Revolution Slider', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
             array(
                'id'       => 'tax_header_use_featured_image',
                'type'     => 'button_set',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Use category featured image or a custom image(global)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Use category featured image or a custom image(global)', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'Featured Image',
                            'no' => 'Custom Image'
                            ),
                'default'  => 'yes'
            ),
            
            array(
                'id'       => 'tax_header_static_image',
                'type'     => 'media',
                'required' => array('tax_header_use_featured_image', '=', 'no'),
                'title'    => __( 'Category Header Image', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Category Header Image', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
             array(
                'id'       => 'tax_header_static_image_height',
                'type'     => 'text',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Category Header Static Image Height', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'The image will be used as background of a div', 'wpstream-wordpresstheme' ),
                'default'  => '500',
              
            ), 
            array(
                'id'       => 'tax_header_static_image_height_back_type',
                'type'     => 'select',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Category Header Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Category Header Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'default'  => 'cover',
                'options'   => array('cover','contain'),
            ),
            array(
                'id'       => 'tax_header_paralax_header',
                'type'     => 'button_set',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Category Header Parallax efect for image/video header media ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Category Header Enable parallax efect for image/video media header.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            array(
                'id'       => 'tax_header_use_title',
                'type'     => 'button_set',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Use Category Title & Tagline or Custom Title(global)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Use Category Title  & Tagline or a global custom title & subtitle', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            
            array(
               'id'       => 'tax_header_title_over_image',
               'type'     => 'text',
               'required' => array('tax_header_use_title', '=', 'no'),
               'title'    => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
            ),
             array(
               'id'       => 'tax_header_subtitle_over_image',
               'type'     => 'text',
                'required' => array('tax_header_use_title', '=', 'no'),
               'title'    => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
               'subtitle' => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
            ),
            
            
    
            array(
                'id'       => 'tax_video_header_mp4',
                'type'     => 'media',
                'required' => array('media_header_type_taxonomy', '=', '5'),
                'class'    => 'video_splash',
                'url'      => true,
                'preview'  => false,
                'mode'     => false,
                'title'    => __( 'Category Header Video in mp4 format', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Category Header Video in mp4 format', 'wpstream-wordpresstheme' ),
            ),
            
            
            
              array(
                'id'       => 'tax_header_overlay_color',
                'type'     => 'color',                
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Category Header Overlay color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Overlay color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
               array(
                'id'       => 'tax_header_overlay_opacity',
                'type'     => 'text',
                'required' => array('media_header_type_taxonomy', '=', '2'),
                'title'    => __( 'Category Header Overlay Opacity', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Overlay Opacity(betwen 0 and 1 , Ex:0.5, default 0.6)', 'wpstream-wordpresstheme' ),
                'default'  => '0.6',
              
            ), 
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            array(
                'id'       => 'media_header_type_blog',
                'type'     => 'select',
                'title'    => __( 'Select Media Header for Blog Post', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select Media Header for Blog Post', 'wpstream-wordpresstheme' ),
                'default'  => 'type 1',
                'options'   => array(
                    0   => 'global',
                    1   =>  'none',
                    2   =>  'Image',
                    3   =>  'Revolution Slider',
                    4   =>  'Theme slider',
                    ),
            ),
            
             
            array(
                'id'       => 'blog_header_revolution_slider',
                'type'     => 'text',
                'required' => array('media_header_type_blog', '=', '3'),
                'title'    => __( 'Blog Post Header Revolution Slider', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Revolution Slider', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
            array(
                'id'       => 'blog_use_featured_image',
                'type'     => 'button_set',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header - Use Featured Image from post ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header - Use Featured Image from post?.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            
            array(
                'id'       => 'blog_header_static_image',
                'type'     => 'media',
                'required' => array('blog_use_featured_image', '=', 'no'),
                'title'    => __( 'Blog Post Header Image', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Image', 'wpstream-wordpresstheme' ),
                'default'  => '',
              
            ),
            
            array(
                'id'       => 'blog_header_use_title',
                'type'     => 'button_set',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Use Post Title or Custom Title(global)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Use Post Title or a global custom title & subtitle', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            
            
             array(
                'id'       => 'blog_header_title_over_image',
                'type'     => 'text',
                'required' => array('blog_header_use_title', '=', 'no'),
                'title'    => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Title Over Image', 'wpstream-wordpresstheme' ),
            ),
             array(
                'id'       => 'blog_header_subtitle_over_image',
                'type'     => 'text',
                'required' => array('blog_header_use_title', '=', 'no'),
                'title'    => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Subtitle Over Image', 'wpstream-wordpresstheme' ),
            ),
            
           
            array(
                'id'       => 'blog_header_static_image_height',
                'type'     => 'text',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header Static Image Height', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'The image will be used as background of a div', 'wpstream-wordpresstheme' ),
                'default'  => '500',
              
            ), 
            
            array(
                'id'       => 'blog_header_static_image_height_back_type',
                'type'     => 'select',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Full Screen Background Type?', 'wpstream-wordpresstheme' ),
                'default'  => 'cover',
                'options'   => array('cover','contain'),
            ),
            
            array(
                'id'       => 'blog_header_paralax_header',
                'type'     => 'button_set',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header Parallax efect for image/video header media ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Enable parallax efect for image/video media header.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                            'yes' => 'yes',
                            'no' => 'no'
                            ),
                'default'  => 'no'
            ),
            
            array(
                'id'       => 'blog_header_overlay_color',
                'type'     => 'color',                
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header Overlay color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Overlay color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
               array(
                'id'       => 'blog_header_overlay_opacity',
                'type'     => 'text',
                'required' => array('media_header_type_blog', '=', '2'),
                'title'    => __( 'Blog Post Header Overlay Opacity', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Overlay Opacity(betwen 0 and 1 , Ex:0.5, default 0.6)', 'wpstream-wordpresstheme' ),
                'default'  => '0.6',
              
            ), 
            
            
    
            array(
                'id'       => 'blog_video_header_mp4',
                'type'     => 'media',
                'required' => array('media_header_type_blog', '=', '5'),
                'class'    => 'video_splash',
                'url'      => true,
                'preview'  => false,
                'mode'     => false,
                'title'    => __( 'Blog Post Header Video in mp4 format', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Blog Post Header Video in mp4 format', 'wpstream-wordpresstheme' ),
            ),
            
            
            
            
            
            
            
            
            
            
            
            
        )
    ) );
    
   
    
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header Menu & Topbar Design', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Adjust Colors and Font Sizes for Header Menu & Topbar','wpstream-wordpresstheme' ),
        'id'         => 'opt-textarea-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'header-height',
                'type'     => 'text',
                'title'    => __( 'Header Menu Height', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Header Menu Height', 'wpstream-wordpresstheme' ),
              
            ),
            array(
                'id'       => 'sticky-header-height',
                'type'     => 'text',
                'title'    => __( 'Sticky Header Menu Height', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sticky Header Menu Height', 'wpstream-wordpresstheme' ),
              
            ),
            array(
                'id'       => 'top_bar_back',
                'type'     => 'color',
                'title'    => __( 'Top Bar Background Color (Header Widget Menu)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Top Bar Background Color (Header Widget Menu)', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'header_color',
                'type'     => 'color',
                'title'    => __( 'Header Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Header Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
            array(
                'id'       => 'sticky_header_color',
                'type'     => 'color',
                'title'    => __( 'Sticky Header Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sticky Header Background Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
            array(
                'id'       => 'sticky_menu_font_color',
                'type'     => 'color',
                'title'    => __( 'Sticky Menu Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sticky Menu Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'menu_font_color',
                'type'     => 'color',
                'title'    => __( 'Top Menu Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Top Menu Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'top_menu_hover_font_color',
                'type'     => 'color',
                'title'    => __( 'Top Menu Hover Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Top Menu Hover Font Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
     
            array(
                'id'       => 'transparent_menu_font_color',
                'type'     => 'color',
                'title'    => __( 'Transparent Header - Top Menu Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Transparent Header - Top Menu Font Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
            array(
                'id'       => 'transparent_menu_hover_font_color',
                'type'     => 'color',
                'title'    => __( 'Transparent Header - Top Menu Hover Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Transparent Header - Top Menu Hover Font Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
            array(
                'id'       => 'menu_items_color',
                'type'     => 'color',
                'title'    => __( 'Menu Item Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Menu Item Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'menu_hover_font_color',
                'type'     => 'color',
                'title'    => __( 'Menu Item hover font color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Menu Item hover font color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
            array(
                'id'       => 'menu_item_back_color',
                'type'     => 'color',
                'title'    => __( 'Menu Item Back Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Menu Item Back Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
            array(
                'id'       => 'menu_hover_back_color',
                'type'     => 'color',
                'title'    => __( 'Menu Item Hover Back Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Menu Item Hover Back Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),
             array(
                'id'       => 'menu_border_top_color',
                'type'     => 'color',
                'title'    => __( 'Menu Item Border Top Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Menu Item Border Top Color', 'wpstream-wordpresstheme' ),
                 'transparent'  => false,
            ),  
            array(
                'id'       => 'top_bar_font',
                'type'     => 'color',
                'title'    => __( 'Top Bar Font Color (Header Widget Menu)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Top Bar Font Color (Header Widget Menu)', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'          => 'typo-menu',
                'type'        => 'typography',
                'title'       => esc_html__('Menu', 'wpstream-wordpresstheme'),
                'google'      => true,
                'font-family' => true,
                'font-backup' => false,
                'text-align'  => false,
                'text-transform' => true,
                'font-style' => false,
                'line-height'=> false,
                'color'      => false,
                'units'       =>'px',
                'subtitle'    => esc_html__('Select your custom font options for your main menu font.', 'wpstream-wordpresstheme'),
                'all_styles'  => true,
                
            ),
             array(
                'id'          => 'typo-menu-items',
                'type'        => 'typography',
                'title'       => esc_html__('Menu Items', 'wpstream-wordpresstheme'),
                'google'      => true,
                'font-family' => true,
                'font-backup' => false,
                'text-align'  => false,
                'text-transform' => true,
                'font-style' => false,
                'line-height'=> false,
                'color'      => false,
                'units'       =>'px',
                'subtitle'    => esc_html__('Select your custom font options for your menu items font.', 'wpstream-wordpresstheme'),
                'all_styles'  => true,
               
            ),

        )
    ) );

    
    Redux::setSection( $opt_name, array(
        'title' => __( 'Footer', 'wpstream-wordpresstheme' ),
        'id'    => 'footer_section',
        'desc'  => __( 'Basic fields as subsections.', 'wpstream-wordpresstheme' ),
        'icon'  => 'el el-th'
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer & Sub Footer', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Footer & Sub Footer','wpstream-wordpresstheme' ),
        'id'         => 'footer-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'wide_footer',
                'type'     => 'switch',
                'title'    => __( 'Wide Footer', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Wide Footer', 'wpstream-wordpresstheme' ),
                'default'  => false,
            ),
             array(
                'id'       => 'footer_type',
                'type'     => 'button_set',
                'title'    => __( 'Footer Type', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Footer Type', 'wpstream-wordpresstheme' ),
                'options'  => array(
                        '0'  =>     '4 equal columns',
                        '1'  =>     '3 equal columns',
                        '2'  =>     '2 equal columns',
                        '3'  =>     '100% width column',
                        '4'  =>     '3 columns: 1/2 + 1/4 + 1/4',
                        '5'  =>     '3 columns: 1/4 + 1/2 + 1/4',
                        '6'  =>     '3 columns: 1/4 + 1/4 + 1/2',
                        '7'  =>     '2 columns: 2/3 + 1/3',
                        '8'  =>     '2 columns: 1/3 + 2/3'
                        ),
                'default'  => '0'
            ), 
            
            array(
                'id'       => 'sub_footer_section',
                'type'     => 'switch',
                'title'    => __( 'Display Sub Footer?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Display Sub Footer?', 'wpstream-wordpresstheme' ),
                'default'  => true,
            ),
            array(
                'id'       => 'sub_footer_nav',
                'type'     => 'switch',
                'required' => array('sub_footer_section', '=', true),
                'title'    => __( 'Show Sub Footer Navigation?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Show Sub Footer Navigation?', 'wpstream-wordpresstheme' ),
                'default'  => true,
            ),
            
            array(
                'id'       => 'subfooter_copyright',
                'type'		=> 'textarea',
                'required' => array('sub_footer_section', '=', true),
                'title'		=> esc_html__( 'Sub Footer Copyright Text', 'wpstream-wordpresstheme' ),
                'subtitle' => __('Custom HTML Allowed (wp_kses)', 'redux-framework-demo'),
                'default'	=> 'Copyright All Rights Reserved &copy; 2017s',
                'validate' => 'html_custom',
                'default' => '<br />Some HTML is allowed in here.<br />',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array()
                )
            ),
            
           
        )
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Design', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Footer Design','wpstream-wordpresstheme' ),
        'id'         => 'footer-design-subsection',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'footer_background_image',
                'type'     => 'media',
                'url'      => true,
                'title'    => __( 'Background image for Footer', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Insert background footer image below.', 'wpstream-wordpresstheme' ),         
            ),
            array(
                'id'       => 'repeat_footer_back',
                'type'     => 'button_set',
                'title'    => __( 'Repeat Footer background ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Set repeat options for background footer image.', 'wpstream-wordpresstheme' ),
                'options'  => array(
                        'repeat'   => 'repeat',
                        'repeat x' => 'repeat x',
                        'repeat y' => 'repeat y',
                        'no repeat'=> 'no repeat'
                        ),
                'default'  => 'no repeat'
            ),
            array(
                'id'       => 'footer_widget_title_color',
                'type'     => 'color',
                'title'    => __( 'Footer Widget Title Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Footer Widget Title Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'footer_background',
                'type'     => 'color',
                'title'    => __( 'Footer Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Footer Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'footer_font_color',
                'type'     => 'color',
                'title'    => __( 'Footer Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Footer Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'subfooter_background',
                'type'     => 'color',
                'title'    => __( 'Sub Footer Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sub Footer Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'subfooter_copyright_font_color',
                'type'     => 'color',
                'title'    => __( 'Sub Footer Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sub Footer Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),

            
           
        )
    ) );
    
    
    Redux::setSection( $opt_name, array(
        'title'  => __( 'Subscription Model', 'wpstream-wordpresstheme' ),
        'id'     => 'subscription_model_options-section',
        'desc'   => __( 'Subscription Model', 'wpstream-wordpresstheme' ),
        'icon'   => 'el el-retweet',
        'fields'     => array(
            array(
                'id'   => 'info_normal_sub',
                'type' => 'raw',
                'desc' => __('If you use global subscription mode:
                    <ul>
                        <li>1. Add products(movies or live streams) with a default price.</li>
                        <li>2. Add a Simple Subscription with a  price value (this is the one that will be used as the only subscription.</li>
                        <li>3. Select the subscription from no2 on the "Select subscription for global subscription model" field.</li>
                        After that users will buy the selected subscription and will be able to see all the products(videos and live streams).
                    </ul>   
                   
                        
                        ', 'redux-framework-demo')
            ),
            array(
                'id'       => 'subscription_model',
                'type'     => 'switch',
                'title'    => __( 'Subscription Model - Use global subscription ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Global Subscription -If on a buyer will have acces to all media. If off a buyer will acces only the media he bought', 'wpstream-wordpresstheme' ),
                'default'  => false,
            ),
            array(
                'id'        => 'subscription_global_array',
                'type'      => 'select',
                'multi'     =>  'false',
                'data'      =>  'posts',
                'default'  => false,
                'args'  => array(
                    'post_type'      => 'product',
                    'posts_per_page' => -1,
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                    'tax_query' => array(
                        'relation' => 'AND',
                        array(
                                'taxonomy' => 'product_type',
                                'field'    => 'slug',
                                'terms'    => array( 'subscription'),
                        )
                    )
                ),
                
                'title'    => __( 'Select subscription for global subscription model', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select subscription for global subscription model', 'wpstream-wordpresstheme' ),
             
            ),
           
        )
    ) );
     
     
    Redux::setSection( $opt_name, array(
        'title'  => __( 'Membership Settings', 'wpstream-wordpresstheme' ),
        'id'     => 'membership-settings-section',
        'desc'   => __( 'Membership Settings', 'wpstream-wordpresstheme' ),
        'icon'   => 'el el-user',
        'fields'     => array(
            array(
                'id'       => 'allow_streaming_regular_users',
                'type'     => 'switch',
                'title'    => __( 'Allow Streaming for regular users ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Regular users will be able to live stream on 1 free channel', 'wpstream-wordpresstheme' ),
                'default'  => false,
            ),
            array(
                'id'       => 'wpstream_use_chat_live_stream',
                'type'     => 'button_set',
                'title'    => __( 'Enable chat on live stream ?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Enable chat on live stream ?', 'wpstream-wordpresstheme' ),
                'default'  => 2,
                'options'   => array(1=>'yes',2=>'no'),
            ),
            
        )
        )
    );
            
    
    
    Redux::setSection( $opt_name, array(
        'title'  => __( 'Advanced', 'wpstream-wordpresstheme' ),
        'id'     => 'advanced_options-section',
        'desc'   => __( 'Advanced', 'wpstream-wordpresstheme' ),
        'icon'   => 'el el-cogs'
    ) );
    
     Redux::setSection( $opt_name, array(
        'title'      => __( 'Theme Cache', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Theme Cache','wpstream-wordpresstheme' ),
        'id'         => 'wpstream_cache_control',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'enable_cache',
                'type'     => 'switch',
                'title'    => __( 'Enable Theme Cache?', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'We will cache only heavy database requests.Set this to yes in production mode and no in developement mode. We also recommed using a cache plugin for production since this feature covers only database queries.', 'wpstream-wordpresstheme' ),
                'default'  => false,
            ),
            
    )
         ));
     
     
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Custom Colors', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Custom Colors','wpstream-wordpresstheme' ),
        'id'         => 'wpstream_custom_colors',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'main_color',
                'type'     => 'color',
                'title'    => __( 'Main Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Main Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
            array(
                'id'       => 'background_color',
                'type'     => 'color',
                'title'    => __( 'Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
        
            array(
                'id'       => 'meta_font_color',
                'type'     => 'color',
                'title'    => __( 'Breadcrumbs, Meta and Second Line Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Breadcrumbs, Meta and Second Line Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'font_color',
                'type'     => 'color',
                'title'    => __( 'Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'link_color',
                'type'     => 'color',
                'title'    => __( 'Link Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Link Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            
            array(
                'id'       => 'heading_color',
                'type'     => 'color',
                'title'    => __( 'Headings Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Headings Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'default_button_color',
                'type'     => 'color',
                'title'    => __( 'Button Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Button Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
             array(
                'id'       => 'default_button_color_text',
                'type'     => 'color',
                'title'    => __( 'Button Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Button Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'hover_button_color',
                'type'     => 'color',
                'title'    => __( 'Hover Button Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Hover Button Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'sidebar_heading_color',
                'type'     => 'color',
                'title'    => __( 'Sidebar Heading Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sidebar Heading Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'sidebar_font_color',
                'type'     => 'color',
                'title'    => __( 'Sidebar Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Sidebar Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
                array(
                'id'       => 'product_page_background_color',
                'type'     => 'color',
                'title'    => __( 'Product Page Tabs Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Product Page Tabs Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'product_page_font_color',
                'type'     => 'color',
                'title'    => __( 'Product Page Tabs Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Product Page Tabs Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'product_page_selected_tab_back_color',
                'type'     => 'color',
                'title'    => __( 'Product Page Selected Tab Background Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Product Page Selected Tab Background Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
            array(
                'id'       => 'product_page_selected_tab_font_color',
                'type'     => 'color',
                'title'    => __( 'Product Page Selected Tab Font Color', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Product Page Selected Tab Font Color', 'wpstream-wordpresstheme' ),
                'transparent'  => false,
            ),
        )   
    ) );
    
     
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Custom CSS', 'wpstream-wordpresstheme' ),
        'desc'       => __( 'Custom CSS','wpstream-wordpresstheme' ),
        'id'         => 'wpstream_custom_css-subsection',
        'subsection' => true,
        'fields'     => array(
             array(
            'id'       => 'css_editor',
            'type'     => 'ace_editor',
            'title'    => __('CSS Code', 'wpstream-wordpresstheme'),
            'subtitle' => __('Paste your CSS code here.', 'wpstream-wordpresstheme'),
            'mode'     => 'css',
            'theme'    => 'monokai',
            //'desc'     => 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.',
            'default'  => "#header{\nmargin: 0 auto;\n}"
        ),
            
        )   
    ) );
    
    
     
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Theme Slider', 'wpstream-wordpresstheme' ),
        'id'         => 'theme_slider_tab',
        'icon'       => 'el el-picture',
        'fields'     => array(
            array(
                'id'       => 'wp_estate_theme_slider',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Select Product ', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Select Product for header theme listing slider. For speed reason we show only the first 50 products. If you want to add other listings, use the field below to select properties by ID. ', 'wpstream-wordpresstheme' ),
                'options'  => wprentals_return_theme_slider_list(),
            ),
            array(
                'id'       => 'wp_estate_theme_slider_manual',
                'type'     => 'text',
                'title'    => __( 'Add Products in theme slider by ID. Place here the Products Id separated by comma.', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Place here the Products Id separated by comma. Will Overwrite the above selection!', 'wpstream-wordpresstheme' ),
            ),
            array(
                'id'       => 'wp_estate_slider_cycle',
                'type'     => 'text',
                'title'    => __( 'Number of milisecons before auto cycling an item', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Number of milisecons before auto cycling an item (5000=5sec).Put 0 if you don\'t want to autoslide.', 'wpstream-wordpresstheme' ),
                'default'  => '5000'
            ),      
            array(
                'id'       => 'wp_estate_theme_slider_height',
                'type'     => 'text',
                'title'    => __( 'Height in px (put 0 for full screen)', 'wpstream-wordpresstheme' ),
                'subtitle' => __( 'Height in px(put 0 for full screen, Default :580px)', 'wpstream-wordpresstheme' ),
                'default'  => '580'
            ),
            
        ),
    ) );
    /*
     * <--- END SECTIONS
     */
