<?php
require_once    get_template_directory().'/libs/css_js_include.php';
require_once    get_template_directory().'/libs/plugins.php';
require_once    get_template_directory().'/libs/help_functions.php';
require_once    get_template_directory().'/libs/design_functions.php';
require_once    get_template_directory().'/libs/metaboxes.php';
require_once    get_template_directory().'/libs/shortcodes_install.php';
require_once    get_template_directory().'/libs/shortcodes.php';
require_once    get_template_directory().'/libs/widgets.php';
require_once    get_template_directory().'/libs/general-settings.php';
require_once    get_template_directory().'/libs/theme-slider.php';
require_once    get_template_directory().'/libs/woo-helper.php';
require_once    get_template_directory().'/libs/ajax_functions.php';
require_once    get_template_directory().'/libs/shortcodes_install.php';
require_once    get_template_directory().'/libs/updatetheme.php';
require_once    get_template_directory().'/libs/user_streaming.php';

remove_action( 'woocommerce_before_single_product', 'wpstream_user_logged_in_product_already_bought', 10 );
remove_filter( 'the_content', 'wpstream_insert_player');
remove_filter( 'the_content', 'wpstream_filter_the_title' );
global $wpstream_plugin;
remove_filter( 'the_content',array($wpstream_plugin->main->wpstream_player, 'wpstream_filter_the_title') );
remove_filter( 'woocommerce_before_single_product', array($wpstream_plugin->main->wpstream_player,'wpstream_user_logged_in_product_already_bought') );
     
     
function wpstream_load_classes(){
    require_once    get_template_directory().'/classes/login_register.php';
    global $wpestate_login_register;
    $wpestate_login_register =new WpEstate_login_register();
}
add_action('init','wpstream_load_classes');





if ( ! function_exists( 'wpstream_wordpresstheme_setup' ) ) :
	
	function wpstream_wordpresstheme_setup() {

	/*
	 * Add Redux Framework
	 */
	require get_template_directory() . '/admin/admin-init.php';
                
                load_theme_textdomain( 'wpstream-wordpresstheme', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );
                add_theme_support( 'title-tag' );
                add_theme_support( 'post-thumbnails' );
                wpstream_image_size();
		
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'wpstream_wordpresstheme_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );
                add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
                add_theme_support( 'gutenberg', array(
                    // Theme supports wide images, galleries and videos.
                    'wide-images' => true,

                    // Make specific theme colors available in the editor.
                    'colors' => array(
                        '#ffffff',
                        '#000000',
                        '#cccccc',
                    ),

                ) );
                add_theme_support( 'align-wide' );
                
                add_action('tgmpa_register', 'wpstream_required_plugins');
              

                add_action('init', 'wpstream_theme_shortcodes');
	}
endif;
add_action( 'after_setup_theme', 'wpstream_wordpresstheme_setup' );





/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wpstream_wordpresstheme_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'wpstream_wordpresstheme_content_width', 1240 );
}
add_action( 'after_setup_theme', 'wpstream_wordpresstheme_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wpstream_wordpresstheme_widgets_init() {
    register_nav_menu( 'primary', esc_html__(  'Primary Menu', 'wpstream-wordpresstheme' ) ); 
    register_nav_menu( 'mobile', esc_html__(  'Mobile Menu', 'wpstream-wordpresstheme' ) ); 
    register_nav_menu( 'footer_menu', esc_html__(  'Footer Menu', 'wpstream-wordpresstheme' ) ); 
    
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'wpstream-wordpresstheme' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'wpstream-wordpresstheme' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
        
        register_sidebar(array(
            'name'          => esc_html__( 'Primary Widget Area', 'wpstream-wordpresstheme'),
            'id'            => 'primary-widget-area',
            'description'   =>  esc_html__( 'The primary widget area', 'wpstream-wordpresstheme'),
'           before_widget'  => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));

        register_sidebar(array(
            'name'          => esc_html__( 'Secondary Widget Area', 'wpstream-wordpresstheme'),
            'id'            => 'secondary-widget-area',
            'description'   => esc_html__( 'The secondary widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));

        
        register_sidebar(array(
            'name' => esc_html__( 'First Footer Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'first-footer-widget-area',
            'description' => esc_html__( 'The first footer widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title-footer">',
            'after_title' => '</h3>',
        ));


        register_sidebar(array(
             'name' => esc_html__('Second Footer Widget Area', 'wpstream-wordpresstheme'),
             'id' => 'second-footer-widget-area',
             'description' => esc_html__('The second footer widget area', 'wpstream-wordpresstheme'),
             'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
             'after_widget' => '</li>',
             'before_title' => '<h3 class="widget-title-footer">',
             'after_title' => '</h3>',
         ));


        register_sidebar(array(
            'name' => esc_html__( 'Third Footer Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'third-footer-widget-area',
            'description' => esc_html__( 'The third footer widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title-footer">',
            'after_title' => '</h3>',
        ));
     
        register_sidebar(array(
            'name' => esc_html__( 'Fourth Footer Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'fourth-footer-widget-area',
            'description' => esc_html__( 'The fourth footer widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title-footer">',
            'after_title' => '</h3>',
        ));

        register_sidebar(array(
            'name' => esc_html__( 'Top Bar Left Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'top-bar-left-widget-area',
            'description' => esc_html__( 'The top bar left widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title-topbar">',
            'after_title' => '</h3>',
        ));
       
        register_sidebar(array(
            'name' => esc_html__( 'Top Bar Right Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'top-bar-right-widget-area',
            'description' => esc_html__( 'The top bar right widget area', 'wpstream-wordpresstheme'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
           'before_title' => '<h3 class="widget-title-topbar">',
            'after_title' => '</h3>',
        ));
    
         register_sidebar(array(
            'name' => esc_html__( 'User Event Widget Area', 'wpstream-wordpresstheme'),
            'id' => 'user-event-area',
            'description' => esc_html__( 'Widget Area for User Events', 'wpstream-wordpresstheme'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));

}
add_action( 'widgets_init', 'wpstream_wordpresstheme_widgets_init' );

/**
 * Enqueue scripts and styles.
 */




/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}


/**
 * Clear theme cache
 */
if ( ! function_exists( 'wpstream_admin_bar_menu' ) ) {
	function wpstream_admin_bar_menu() {
            global $wp_admin_bar;
            $theme_data = wp_get_theme();
		

            if ( ! current_user_can( 'manage_options' ) || ! is_admin_bar_showing() ) { 
                return;
            }

            $wp_admin_bar->add_menu(
                    array(
                        'title' => esc_html__( 'Clear WpStream Cache', 'wpstream-wordpresstheme' ),
                        'id' => 'clear_cache',
                        'href' => wp_nonce_url( admin_url( 'admin-post.php?action=wpstream_purge_cache' ) , 'theme_purge_cache' ),
                    )
            );
            }
}
add_action( 'admin_bar_menu', 'wpstream_admin_bar_menu', 100 );

/**
 * Generate Custom Css
 */

add_action('wp_head', 'wpstream_generate_options_css');

if( !function_exists('wpstream_generate_options_css') ):
    function wpstream_generate_options_css() {
      
        $css_cache          =   wpstream_get_transient( 'wpstream_custom_css'  );

        if( $css_cache === false ) {   
            ob_start();
                print "<style type='text/css'>" ;
                    require_once ('libs/customcss.php');    
                print "</style>"; 
                $css_cache   =  ob_get_contents();
                $css_cache   =  wpstream_css_compress($css_cache); 
            ob_end_clean();
            wpstream_set_transient('wpstream_custom_css',$css_cache,60*60*24);
        }
        print $css_cache; 
    }
endif; 



function wpstream_css_compress($buffer) {
    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
    return $buffer;
}

function wpstream_html_compress($buffer){
    $search = array(
        '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
        '/[^\S ]+\</s',     // strip whitespaces before tags, except space
        '/(\s)+/s',         // shorten multiple whitespace sequences
        '/<!--(.|\s)*?-->/' // Remove HTML comments
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );

    $buffer = preg_replace($search, $replace, $buffer);

    return $buffer;
}



/**
*Comments
**/

if (!function_exists('wpstream_comment')) :

    function wpstream_comment($comment, $args, $depth) {
        $GLOBALS['comment'] = $comment;
        switch ($comment->comment_type) :
            case 'pingback' :
            case 'trackback' :
                ?>
                <li class="post pingback">
                    <p><?php esc_html_e('Pingback:', 'wpstream-wordpresstheme'); ?> <?php comment_author_link(); ?><?php edit_comment_link(esc_html__( 'Edit', 'wpstream-wordpresstheme'), '<span class="edit-link">', '</span>'); ?></p>
                <?php
                break;
            default :
                ?>




        <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">


                <div id="comment-<?php comment_ID(); ?>" class="comment">     
 
                    <div class="comment-meta">  
                        <?php
                        $avatar =esc_url( get_avatar_url(get_avatar($comment, 80)));
                        print '<div class="comment_avatar" style="background-image: url(' . esc_url($avatar) . ');">';
                        print '</div>';
                        ?>
                        <div class="comment-author vcard">
                            <?php
                            print '<div class="comment_name">' . get_comment_author_link() . '</div>';
                            ?>

                            <div class="comment-content">
                            <?php comment_text(); ?>
                            </div>
                            <div class="comment-details">
                                <?php print'<span class="comment_date">'.get_comment_date(). '</span>'; ?>
                                <?php edit_comment_link(esc_html__( 'Edit', 'wpstream-wordpresstheme'), '<span class="edit-link">', '</span>'); ?>
                                <?php comment_reply_link(array_merge($args, array( esc_html__( 'Reply', 'wpstream-wordpresstheme'), 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
                            </div>
                        </div><!-- .comment-author .vcard -->

                <?php if ($comment->comment_approved == '0') : ?>
                    <em class="comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'wpstream-wordpresstheme'); ?></em>
                    <br />
                <?php endif; ?>

                </div>


            </div><!-- #comment-## -->
            <?php
            break;
        endswitch;
    }

endif; // ends check for  wpstream_comment 


function wpstream_check_global_subscription_model(){
    if( is_user_logged_in()  && function_exists('wcs_user_has_subscription') ){
      
        global $woocommerce;
        $current_user   =       wp_get_current_user(); 
        
        
        $subscription_model = intval( wpstream_get_option('subscription_model')) ;
        
        
        if($subscription_model==1){
            $main_subscription = wpstream_get_option('subscription_global_array');

            $product_id=intval($main_subscription[0]);
                    
            if( wcs_user_has_subscription( $current_user->ID, $product_id ,'active') ) {
                return true;
            }
        }
        return false;
        
    }
    return false;
}


function wpstream_is_global_subscription(){
    $subscription_model = intval( wpstream_get_option('subscription_model')) ;
    if($subscription_model==1){
        return true;
    }
    return false;
}


function wpstream_text_strings( $translated_text, $text, $domain ) {
    switch (strtolower( $translated_text) ) {
        case 'related products' :
            $translated_text = esc_html__( 'You May Also like', 'wpstream-wordpresstheme' );
            break;
    }
    return $translated_text;
}
add_filter( 'gettext', 'wpstream_text_strings', 20, 3 );



// theme install hooks

function ocdi_plugin_intro_text( $default_text ) {
    $default_text = '<div class="ocdi__intro-text intro-text_wpestate">For copyright & speed purposes, demo images & videos are not included in the import. </div>';

    return $default_text;
}
add_filter( 'pt-ocdi/plugin_intro_text', 'ocdi_plugin_intro_text' );


function ocdi_import_files() {
  return array(
    array(
        'import_file_name'             =>   'Hollywood demo',  
        'local_import_file'            =>   trailingslashit( get_template_directory() ) . 'wpstream_templates/hollywood/theme_content.xml',
        'local_import_widget_file'     =>   trailingslashit( get_template_directory() ) . 'wpstream_templates/hollywood/widgets.wie',
        'local_import_redux'           => array(
                array(
                  'file_path'   => trailingslashit( get_template_directory() ) . 'wpstream_templates/hollywood/redux_options.json',
                  'option_name' => 'redux_builder_wpstream',
                ),
        ),
        'import_preview_image_url'     =>   get_theme_file_uri('wpstream_templates/hollywood/preview.jpg')  ,
        'import_notice'                =>   esc_html__( 'Clear theme cache after demo import is complete!', 'wpstream-wordpresstheme' ),
        'preview_url'                  =>   'http://hollywood.wpstream.net/',
    ),
    
      
      
    array(
        'import_file_name'             =>     'GoLive Demo',
        'local_import_file'            =>     trailingslashit( get_template_directory() ) . 'wpstream_templates/golive/theme_content.xml',
        'local_import_widget_file'     =>     trailingslashit( get_template_directory() ) . 'wpstream_templates/golive/widgets.wie',
        'local_import_redux'           => array(
                                                array(
                                                  'file_path'   => trailingslashit( get_template_directory() ) . 'wpstream_templates/golive/redux_options.json',
                                                  'option_name' => 'redux_builder_wpstream',
                                                ),
        ),
        'import_preview_image_url'     =>     get_theme_file_uri('wpstream_templates/golive/preview.jpg')  ,
        'import_notice'                =>     esc_html__( 'Clear theme cache after demo import is complete!', 'wpstream-wordpresstheme' ),
        'preview_url'                  =>     'http://golive.wpstream.net/',
    ),
      
   
  );
}


add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );



function ocdi_after_import_setup() {
    
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
   
    
    set_theme_mod( 'nav_menu_locations', array(
        'primary'       => $main_menu->term_id,
        'mobile'        => $main_menu->term_id,
        'footer_menu'   => $main_menu->term_id,
        )
    );
  
    $front_page_id = get_page_by_title( 'Home' );
    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    

}
add_action( 'pt-ocdi/after_import', 'ocdi_after_import_setup' );


