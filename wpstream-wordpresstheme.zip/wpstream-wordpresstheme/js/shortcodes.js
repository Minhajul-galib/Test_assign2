
///////////////////////////////////////////////////////////////////////////////////////////
///  shortcode - places list
/////////////////////////////////////////////////////////////////////////////////////////



(function () {
    "use strict";
    tinymce.create('tinymce.plugins.places_list', {
        init: function (ed, url) {
            ed.addButton('places_list', {
                title: 'Places List',
                image: url + '/tiny_icons/recent_posts.png',
                onclick: function () {
                    ed.selection.setContent('[places_list place_list="ID,s of places separated by comma" place_per_row="4" ][/places_list]');
                }
            });
        },
        createControl: function (n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('places_list', tinymce.plugins.places_list);
})();



///////////////////////////////////////////////////////////////////////////////////////////
///  shortcode - recent_posts_slider_pictures
/////////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.slider_recent_items', {
      init : function(ed, url) {
	        ed.addButton('slider_recent_items', {
            title : 'Recent Items', 
            image : url+'/tiny_icons/recent_posts.png',

         	 onclick : function() {  
                    ed.selection.setContent('[slider_recent_items title="Title Here" type="properties or articles" category_ids="" action_ids="" city_ids="" area_ids="" number="how many items"  show_featured_only="yes/no" autoscroll="0"][/slider_recent_items]');                
                 } 
         });
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('slider_recent_items', tinymce.plugins.slider_recent_items);
})();







/////////////////////////////////////////////////////////////////////////////////////////
///  shortcode - Item by id
///////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.list_items_by_id', {
      init : function(ed, url) {
	        ed.addButton('list_items_by_id', {
            title : 'List Items by Id', 
            image : url+'/tiny_icons/recent-items-2.png',

         	 onclick : function() {  
                    ed.selection.setContent('[list_items_by_id title="Title Here" type="properties or articles" ids="" number="how many items/row"  align="vertical or horizontal" link="link to global listing"][/list_items_by_id]');  
                } 
         });
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('list_items_by_id', tinymce.plugins.list_items_by_id);
})();



    
///////////////////////////////////////////////////////////////////////////////////////
/////  shortcode - login form 
///////////////////////////////////////////////////////////////////////////////////////

(function() {  
    tinymce.create('tinymce.plugins.login_form', {  
        init : function(ed, url) {  
            ed.addButton('login_form', {  
                title : 'Add a login_form',  
                image : url+'/tiny_icons/user-login.png',
                onclick : function() {  
                     ed.selection.setContent('[login_form register_label="register here" register_url="..." ]' + ed.selection.getContent() + '[/login_form]');  
  
                }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        },  
    });  
    tinymce.PluginManager.add('login_form', tinymce.plugins.login_form);  
})();  




///////////////////////////////////////////////////////////////////////////////////////
///  shortcode - register_form 
///////////////////////////////////////////////////////////////////////////////////////


(function() {
   tinymce.create('tinymce.plugins.register_form', {
      init : function(ed, url) {
	 ed.addButton('register_form', {
            title : 'Insert Register Form', 
            image : url+'/tiny_icons/register_form.png',

         	 onclick : function() {
                     ed.selection.setContent('[register_form][/register_form]');
                } 
         }); 
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('register_form', tinymce.plugins.register_form);
})();




///////////////////////////////////////////////////////////////////////////////////////
///  shortcode - featured_property 
///////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.featured_property', {
      init : function(ed, url) {
	        ed.addButton('featured_property', {
            title : 'Insert Featured Property', 
            image : url+'/tiny_icons/featured-property.png',

         	 onclick : function() {
                     ed.selection.setContent('[featured_property id="property id" sale_line="sale line goes here"][/featured_property]');
                } 
         }); 
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('featured_property', tinymce.plugins.featured_property);
})();





///////////////////////////////////////////////////////////////////////////////////////
///  shortcode - featured article
///////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.featured_article', {
      init : function(ed, url) {
	        ed.addButton('featured_article', {
            title : 'Insert Featured Article', 
            image : url+'/tiny_icons/featured-article.png',

         	 onclick : function() {
                     ed.selection.setContent('[featured_article id="article id" second_line="featured article"][/featured_article]');
                } 
         }); 
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('featured_article', tinymce.plugins.featured_article);
})();




///////////////////////////////////////////////////////////////////////////////////////
///  shortcode - featured agent
///////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.featured_agent', {
      init : function(ed, url) {
	        ed.addButton('featured_agent', {
            title : 'Insert Featured Agent', 
            image : url+'/tiny_icons/featured-agent.png',

         	 onclick : function() {
                     ed.selection.setContent('[featured_agent id="agent id" notes="notes about agent"][/featured_agent]');
                } 
         }); 
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('featured_agent', tinymce.plugins.featured_agent);
})();












/////////////////////////////////////////////////////////////////////////////////////////
///  shortcode - recent_posts_pictures
/////////////////////////////////////////////////////////////////////////////////////////

(function() {
   tinymce.create('tinymce.plugins.recent_items', {
      init : function(ed, url) {
	        ed.addButton('recent_items', {
            title : 'Recent Items', 
            image : url+'/tiny_icons/recent_posts.png',

         	 onclick : function() {  
                    ed.selection.setContent('[recent_items title="Title Here" type="properties or articles" category_ids="" action_ids="" city_ids="" area_ids="" number="how many items" rownumber="no of items per row" link="link to global listing" show_featured_only="yes/no" random_pick="yes/no"][/recent_items]');                
                 } 
         });
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('recent_items', tinymce.plugins.recent_items);
})();










//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////  shortcode - places_slider
////////////////////////////////////////////////////////////////////////////////////////////////////////////////..
(function() {
   tinymce.create('tinymce.plugins.places_slider', {
      init : function(ed, url) {
	        ed.addButton('places_slider', {
            title : 'Insert Places Slider', 
            image : url+'/tiny_icons/slider.png',

         	 onclick : function() {  
                     ed.selection.setContent('[places_slider place_list="" place_per_row="3"  ]');  
                } 
         });
      },
    createControl : function(n, cm) {  
        return null;  
        },  

    });  
    tinymce.PluginManager.add('places_slider', tinymce.plugins.places_slider);
})();