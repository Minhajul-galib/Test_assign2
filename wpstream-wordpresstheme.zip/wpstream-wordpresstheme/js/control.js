/* global control_vars, $, jQuery, ajaxcalls_vars,window,control_vars*/

function wpstream_header_sticky(scroll){
    "use strict";
    
    var switch_logo;
 
    if (scroll >= 100) {
        
        if (!window.matchMedia('screen and (max-width: 1023px)').matches) {
         
            jQuery("#page").css('padding-top','50px');
            jQuery("#masthead").addClass("master_header_sticky");
            jQuery('.custom-logo-link').addClass('miclogo');
                switch_logo = jQuery('#masthead').attr('data-sticky-logo');
          
            
            if(wpstream_isRetinaDisplay()){
                switch_logo=wpstream_Return_retina(switch_logo);
            }
            
            if( switch_logo!=='' ){
                jQuery('#logo_image').attr('src',switch_logo);
            }
        }

        jQuery('.wpstream_menu_trigger').hide();          
   
    } else {
      jQuery("#page").css('padding-top','0px');
  
        jQuery("#masthead").removeClass("master_header_sticky");
            if( switch_logo!=='' ){
                switch_logo = jQuery('#masthead').attr('data-logo');

                if(wpstream_isRetinaDisplay()){
                    switch_logo=wpstream_Return_retina(switch_logo);
                }
                jQuery('#logo_image').attr('src',switch_logo);
            }
    }
   

}




function wpstream_isRetinaDisplay() {
    "use strict";
    if(control_vars.use_retina==='1'){
       
        if (window.matchMedia) {
            var mq = window.matchMedia("only screen and (min--moz-device-pixel-ratio: 1.3), only screen and (-o-min-device-pixel-ratio: 2.6/2), only screen and (-webkit-min-device-pixel-ratio: 1.3), only screen  and (min-device-pixel-ratio: 1.3), only screen and (min-resolution: 1.3dppx)");
            return (mq && mq.matches || (window.devicePixelRatio > 1)); 
        }
    }else{
        
        return false;
    }
}

function wpstream_Return_retina(switch_logo){
    "use strict";
    var  replacement = '_2x.';
    var return_string = switch_logo.replace(/.([^.]*)$/,replacement+'$1');
    return return_string;
}


jQuery(window).scroll(function () {
    "use strict";
    var scroll = jQuery(window).scrollTop();  
    wpstream_header_sticky(scroll);
});


jQuery(document).ready(function ($) {
    "use strict";
    
    

    $('.mobile-trigger').on('click',function () {
        if ($('#page').hasClass('moved_mobile')) {
            $('.mobilewrapper-user').show();
            $('#page').removeAttr('style');
            $('#page').removeClass('moved_mobile');
            $('.mobilewrapper').removeAttr('style');
        } else {
            $('.mobilewrapper-user').hide();
            $('.mobilewrapper').show();
            $('#page').css('-webkit-transform', 'translate(265px, 0px)');
            $('#page').css('-moz-transform', 'translate(265px, 0px)');
            $('#page').css('-ms-transform', 'translate(265px, 0px)');
            $('#page').css('-o-transform', 'translate(265px, 0px)');

            $('#page').addClass('moved_mobile');
          
            $('.mobilewrapper').css('-webkit-transform', 'translate(0px, 0px)');
            $('.mobilewrapper').css('-moz-transform', 'translate(0px, 0px)');
            $('.mobilewrapper').css('-ms-transform', 'translate(0px, 0px)');
            $('.mobilewrapper').css(' -o-transform', 'translate(0px, 0px)');
        }
    });

    $('.mobile-trigger-user').on('click',function () {
        if ($('#page').hasClass('moved_mobile_user')) {
            $('#page').removeClass('moved_mobile_user');
        
            $('#page').removeAttr('style');
            $('.mobilewrapper-user').hide();
            $('.mobilewrapper').show();    
            $('.mobilewrapper-user').removeAttr('style');
         
        } else {
            $('#page').css('-webkit-transform', 'translate(-265px, 0px)');
            $('#page').css('-moz-transform', 'translate(-265px, 0px)');
            $('#page').css('-ms-transform', 'translate(-265px, 0px)');
            $('#page').css('-o-transform', 'translate(-265px, 0px)');
            $('#page').addClass('moved_mobile_user');
          
            $('.mobilewrapper-user').show();
            $('.mobilewrapper').hide();
            $('.mobilewrapper-user').css('-webkit-transform', 'translate(0px, 0px)');
            $('.mobilewrapper-user').css('-moz-transform', 'translate(0px, 0px)');
            $('.mobilewrapper-user').css('-ms-transform', 'translate(0px, 0px)');
            $('.mobilewrapper-user').css(' -o-transform', 'translate(0px, 0px)');
        }
    });
    
    
    
        $('.user_tab_menu_close').on('click',function () {
        $('#page').removeAttr('style');
        $('#page').removeClass('moved_mobile_user');
        $('#user_tab_menu_container').removeAttr('style');
    });
    
    
    $('.mobilemenu-close-user').on('click',function () {
        $('#page').removeAttr('style');
        $('#page').removeClass('moved_mobile_user');
        $('.mobilewrapper-user').removeAttr('style');
    });

    $('.mobilemenu-close').on('click',function () {
        $('.mobilewrapper-user').show();
        $('#page').removeAttr('style');
        $('#page').removeClass('moved_mobile');
        $('.mobilewrapper').removeAttr('style');
    });

    $('.mobilex-menu li').on('click',function (event) {
        event.stopPropagation();
        var selected;
        selected = $(this).find('.sub-menu:first');
        selected.slideToggle();
    });






    var videolity;
    $(document).on('click', '[data-my-lightbox]', lity);
    
    $(document).on('lity:ready', function(event, instance) {
      
        videolity= document.querySelector('#'+event.target.id+'video' );
        if( typeof videolity !==    "undefined"){
            videolity.play();
        }
    });

    $(document).on('lity:close', function(event, instance) {
        if( typeof videolity !==    "undefined"){
            videolity.pause();
        }
    });
    
    
    
    
    
    if(document.querySelector('#hero-vid')){     
        var promise = document.querySelector('#hero-vid').play();

        document.querySelector('#hero-vid').addEventListener('ended',function() {
            var teaser_video=document.querySelector('#hero-vid');
            teaser_video.autoplay=false;
            var v=teaser_video.currentSrc;
            teaser_video.src='';
            teaser_video.src=v; 
        })


        if (promise !== undefined) {
          promise.then(_ => {
            // Autoplay started!
          
          }).catch(error => {
             
                $('#hero-vid').prop('muted',true);
                $('#wpstream_mute_preview').html('<i class="demo-icon icon-volume-off"></i>');
                var teaser_video = document.getElementById("hero-vid"); 
                teaser_video.play();
                teaser_video.addEventListener('ended',function() {
                    teaser_video.autoplay=false;
                    var  v=teaser_video.currentSrc;
                    teaser_video.src='';
                    teaser_video.src=v; 
                })
        
            // Autoplay was prevented.
            // Show a "Play" button so that user can start playback.
          });
        }
        
      
    }

    var box = document.querySelector(".wpstream_menu_trigger");
    document.addEventListener("click", function(event) {
            if (event.target.closest(".wpstream_menu_trigger")) {
                return;
            }
            if (event.target.closest(".wpstream_header_shoping_cart")) {
                return;
            }
            jQuery('.wpstream_menu_trigger').hide();
           
    });


    
    ////////////////////////////
    // taxonomy slick slider
    ////////////////////////////
    
    $('.wpstream_categories_slider').each(function(){
        var items   = $(this).attr('data-items-per-row');
        var auto    = parseInt(  $(this).attr('data-auto') );
        var slick=$(this).slick({
            infinite: true,
            slidesToShow: items,
            slidesToScroll: 1,
            dots: false,

            responsive: [
                {
                 breakpoint:1025,
                 settings: {
                   slidesToShow: 2,
                   slidesToScroll: 1
                 }
                },
                {
                  breakpoint: 560,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                  }
                }
            ]
        });
        if(control_vars.is_rtl==='1'){
            $(this).slick('slickSetOption','rtl',true,true);
            $(this).slick('slidesToScroll','-1');
        }
    });
  
   
    
    $('.theme_slider').each(function(){
        var items   = 1;
        var auto    = parseInt(  $(this).attr('data-auto') );
        
        if (auto === 0 ){
        
            $(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
                autoplay: false,
             
               
            });
            if(control_vars.is_rtl==='1'){
                  $(this).slick('slickSetOption','rtl',true,true);
            }
            
        }else{
            
            $(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
                autoplay: true,
                autoplaySpeed: auto
              
            });
            if(control_vars.is_rtl==='1'){
                  $(this).slick('slickSetOption','rtl',true,true);
            }
        }
    });
    

	
    $('.theme_slider_2').each(function(){
        var items   = 3;
        var auto    = parseInt(  $(this).attr('data-auto') );
        
        if (auto === 0 ){
        
            $(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
             
                responsive: [
                    {
                     breakpoint:1025,
                     settings: {
                       slidesToShow: 2,
                       slidesToScroll: 1
                     }
                   },
                    {
                      breakpoint: 480,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });
            if(control_vars.is_rtl==='1'){
                  $(this).slick('slickSetOption','rtl',true,true);
            }
            
        }else{
            
            $(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
                autoplay: true,
                autoplaySpeed: auto,
                
                 responsive: [
                    {
                     breakpoint:1025,
                     settings: {
                       slidesToShow: 2,
                       slidesToScroll: 1
                     }
                   },
                    {
                      breakpoint: 480,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });
            if(control_vars.is_rtl==='1'){
                  $(this).slick('slickSetOption','rtl',true,true);
            }
        }
    });
    
    
    $('.wpstream_header_shoping_cart_icon').on('click',function(event){
        event.preventDefault();
        $('.wpstream_header_shoping_cart_search, .wpstream_header_user_menu_container ').fadeOut("fast");
        $('.wpstream_header_shoping_cart_container').fadeIn(300);
    });
    
    
    $('.wpstream_header_user_menu_icon').on('click',function(event){
        event.preventDefault();
        $('.wpstream_header_shoping_cart_container, .wpstream_header_shoping_cart_search  ').fadeOut("fast");
        $('.wpstream_header_user_menu_container').fadeIn(300);
    });
    
    $('.wpstream_header_search_icon').on('click',function(event){
        event.preventDefault();
        $('.wpstream_header_shoping_cart_container,.wpstream_header_user_menu_container ').fadeOut("fast");
        $('.wpstream_header_shoping_cart_search').fadeIn(300);
    });
    
    
    
    
    
    
    
    
    $('#wpstream_play_video').on('click',function(){
        jQuery("#hero-vid").remove();
        
        var player = videojs('wpstream-video');
        player.requestFullscreen();
        player.play();
            
        $('.wpstream_item_image_preview,#hero-vid').fadeOut(300,
        function(){
            $('.wpstream_player_container').fadeIn();
        })
    });
    
    
   

    $('#wpstream_mute_preview').on('click',function(){
        var trailer_player  = document.getElementById("hero-vid"); 
        if(  trailer_player.muted  ){
            trailer_player.muted    =   false;
            $('#wpstream_mute_preview').html('<i class="demo-icon icon-volume-up"></i>');;
        }else{
            trailer_player.muted    =   true;
            $('#wpstream_mute_preview').html('<i class="demo-icon icon-volume-off"></i>');
        }
        
    });
    
    
    

    
    $('.wpstream_thumb_wrapper') .mouseover(function() {
        
        if( $(this).find('.wpstream_thumb_video').length>0 ){
        //    $(this).find('.wp-post-image').hide();
            $(this).find('.wpstream_thumb_video').show();
            var videoIdName=$(this).find('.wpstream_thumb_video').attr('id');

            var myVideo = document.getElementById(videoIdName); 
            myVideo.play();
        }
    })
    .mouseout(function() {
        if( $(this).find('.wpstream_thumb_video').length>0 ){
            $(this).find('.wpstream_thumb_video').hide();

            var videoIdName=$(this).find('.wpstream_thumb_video').attr('id');
            var myVideo = document.getElementById(videoIdName); 
            myVideo.pause();
        }
    });
    
    
    $('.wpstream_in_cart_remove').on('click',function(event){
        event.preventDefault();
        var product_id  =   $(this).attr('data-productid');
        var ajaxurl     =   control_vars.ajaxurl;
        var parent      =   $(this).parent();
       
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            dataType: 'json',
            data: {
                'action'            :   'wpstream_in_cart_remove',
                'product_id'        :   product_id
            },
            success: function (data) { 
                parent.remove();
                jQuery('.wpestream_cart_counter_header').html(data);
            },
            error: function (errorThrown) {
                console.log(errorThrown);
            }
        });//end ajax     
        
    });
    
    
    $('.wpstream_slick_slider').each(function(){
        var items   = $(this).attr('data-items-per-row');
        var auto    = parseInt(  $(this).attr('data-auto') );
        var slick;
        if (auto === 0 ){
       
            slick=$(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
        
                responsive: [
                    {
                     breakpoint:1025,
                     settings: {
                       slidesToShow: 2,
                       slidesToScroll: 1
                     }
                   },
                    {
                      breakpoint: 480,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });
            if(control_vars.is_rtl==='1'){
                $(this).slick('slickSetOption','rtl',true,true);
            
            }
        }else{
            
            slick= $(this).slick({
                infinite: true,
                slidesToShow: items,
                slidesToScroll: 1,
                dots: true,
                autoplay: true,
                autoplaySpeed: auto,
          
                 responsive: [
                    {
                     breakpoint:1025,
                     settings: {
                       slidesToShow: 2,
                       slidesToScroll: 1
                     }
                   },
                    {
                      breakpoint: 480,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });
            if(control_vars.is_rtl==='1'){
                $(this).slick('slickSetOption','rtl',true,true);
            }
        }
    });
     
    
   

///////////////////////////////////////////////////////////////////////////////////////////  
//////// WIDGET  login/forgot password  actions
////////////////////////////////////////////////////////////////////////////////////////////     


     
    $('.wpestat_login_but').on( 'click', function() {
        wpestate_login(1,jQuery(this));
    });
     
    $('.wpestate_login_user_field,.wpestate_login_pass_field').keydown(function (e) {
        if (e.keyCode === 13) {
            e.preventDefault();
            wpestate_login(1,jQuery(this));
        }
    });
    
    
    function wpestate_login(tip,button) {
        "use strict";

        var login_user, login_pwd, security, ispop, ajaxurl,mesaj;
        var container = button.parent();
        login_user          =  container.find('.wpestate_login_user_field').val();
        login_pwd           =  container.find('.wpestate_login_pass_field').val();
        security            =  jQuery('#wpestate_login_register_nonce').val();
        ispop               =  container.find('.loginpop').val();
        mesaj               =  container.find('.login-message-area');
      
    
        mesaj.empty().append('<div class="login-alert">' + control_vars.login_loading + '</div>');
    
        jQuery.ajax({
            type: 'POST',
            dataType: 'json',
            url: control_vars.ajaxurl ,
            data: {
                'action'            :   'wpestate_ajax_login_function',
                'login_user'        :   login_user,
                'login_pwd'         :   login_pwd,
                'ispop'             :   ispop,
                'security-login'    :   security,
                'tip'               :   tip
            },
            success: function (data) {
                mesaj.empty().append('<div class="login-alert alert_err">' + data.message + '<div>');
                if (data.loggedin === true) {
                    document.location.href = control_vars.login_redirect;
                    jQuery('#user_not_logged_in').hide();
                    jQuery('#user_logged_in').show();
                } else {
                    jQuery('.wpestate_login_user_field').val('');
                    jQuery('.wpestate_login_pass_field').val('');
                }
            },
            error: function (errorThrown) {
                console.log(errorThrown);
            }
        });
    }



    
    
    
    $('.wpestate_register_but').click(function () {
        wpstream_register_sh(jQuery(this));
    });
    
    $('#user_email_register_sh, #user_login_register_sh').keydown(function (e) {
        if (e.keyCode === 13 ) {
            e.preventDefault();
            wpstream_register_sh(jQuery(this));
        }
    });
    
    
  
    function wpstream_register_sh(button) {
        "use strict";
     
        var user_pass_sh,user_pass_retype_sh,user_login_register_sh, user_email_register_sh, nonce, ajaxurl,mesaj;
        var container = button.parent();
        
        user_login_register_sh =    container.find('.wpestate_register_user_field').val();
        user_email_register_sh =    container.find('.wpestate_register_email_field').val();
        nonce                  =    jQuery('#wpestate_login_register_nonce').val();
        user_pass_sh           =    container.find('.wpestate_register_pass_field').val();
        user_pass_retype_sh    =    container.find('.wpestate_register_pass2_field').val();
        mesaj                  =    container.find('.register-message-area');

        if ( !container.find('.wpestate_check_field').is(":checked") ) {
            mesaj.empty().append('<div class="alert_err login-alert">' + control_vars.terms_cond + '</div>');
            return;
        } 



        jQuery.ajax({
            type: 'POST',
            url: control_vars.ajaxurl ,
            dataType: 'json',
            data: {
                'action'                    :   'wpestate_ajax_register_function',
                'user_login_register_sh'    :   user_login_register_sh,
                'user_email_register_sh'    :   user_email_register_sh,
                'security-register'         :   nonce,
                'user_pass_sh'              :   user_pass_sh,
                'user_pass_retype_sh'       :   user_pass_retype_sh
            },
            success: function (data) {
         
                if (data.register === true) {
                    mesaj.empty().append('<div class="login-alert register_succes">' + data.message + '</div>'); 
                }else{
                    mesaj.empty().append('<div class="alert_err login-alert">' + data.message + '</div>'); 
                }
                jQuery('.wpestate_register_user_field').val('');
                jQuery('.wpestate_register_email_field').val('');
            },
            error: function (errorThrown) {
                console.log(errorThrown); 
            }
        });
    }

   
   
    
      
    $('.wpestat_forgot_but').click(function () {
        wpestate_forgot_pass(jQuery(this));
    });
    
    $('.forgot-pass-field').keydown(function (e) {
        if (e.keyCode === 13 ) {
            e.preventDefault();
            wpestate_forgot_pass(jQuery(this));
        }
    });
    
    
    
    function wpestate_forgot_pass(button){
        "use strict";
   
        var  forgot_email, securityforgot, postid, ajaxurl,mesaj;
        var container         =     button.parent();
        forgot_email          =     container.find('.forgot-pass-field').val();;
        securityforgot        =     jQuery('#wpestate_login_register_nonce').val();
        postid                =     container.find('.postid').val();;
        mesaj                  =    container.find('.forgot-pass-area');
        jQuery.ajax({
            type: 'POST',
            url: control_vars.ajaxurl,
            data: {
                'action'            :   'wpestate_ajax_forgot_pass',
                'forgot_email'      :   forgot_email,
                'postid'            :   postid,
                'security'          :   securityforgot
            },

            success: function (data) {
                container.find('.forgot-pass-field').val('');
                mesaj.empty().append('<div class="login-alert">' + data + '<div>');        
            },
            error: function (errorThrown) {
            }
        });
    }
    
    
    
    
    
    
    

    
    $('.wpestate_login_register_control a').on( 'click', function(event) {
        event.preventDefault();
        var item_parent =   jQuery(this).parent().parent();
        var action      =   jQuery(this).attr('data-action');
        
    
        item_parent.find('.wpestate_item_wrapper').hide(0, function() {
            item_parent.find('.'+action).show();
        });
   
   
   
    });
       
       

});

