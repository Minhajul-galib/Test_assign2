/*global $, jQuery, document, window */
jQuery(document).ready(function ($) {
    
    
    $('#page_header_type').on('change', function(){

        var value=$(this).val();
        wpestate_show_heder_options(value);
               
    });
    
    function wpestate_show_heder_options(value){

            $('.header_admin_options').hide();

            if (value=='2'){
                $('.header_admin_options.image_header').show();
            }
            else if (value=='4'){
                $('.header_admin_options.theme_slider').show();
            }
            else if (value=='3'){
                $('.header_admin_options.revolution_slider').show();
            }
            else if (value=='5'){
                $('.header_admin_options.video_header').show();
            }
        }
            
    $('#page_header_type').trigger('change');
        
        
        
        
    var formfield;
    
    $('#item_image_preview_button').on( 'click', function(event) {
        formfield = $('#item_image_preview').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            var imgurl,
            srcCheck = $(html).attr('src');

            if (srcCheck && typeof srcCheck !== 'undefined') {
                imgurl = srcCheck;
            } else {
                imgurl = $('img', html).attr('src');
            }           
            $('#item_image_preview').val(imgurl);
            tb_remove();
            

        };
        return false;
    });
    
    $('#item_poster_preview_button').on( 'click', function(event) {
        formfield = $('#item_poster_preview').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            var imgurl,
            srcCheck = $(html).attr('src');

            if (srcCheck && typeof srcCheck !== 'undefined') {
                imgurl = srcCheck;
            } else {
                imgurl = $('img', html).attr('src');
            }           
            $('#item_poster_preview').val(imgurl);
            tb_remove();
            
          
        };
        return false;
    });
    
    jQuery('.savesend input[type=submit]').click(function(){  
         var url = jQuery(this).parents('.describe').find('.urlfile').data('link-url');
         var field = jQuery(this).parents('.describe').find('.urlfield');
         field.val(url);
     });
     
     
    $('#item_video_preview_button').on( 'click', function(event) {
        formfield = $('#item_video_preview').attr('name');
        tb_show('Upload Video', 'media-upload.php?type=video&amp;TB_iframe=true',false);
       
        window.send_to_editor = function (html) {
            var fileurl = jQuery(html).attr('href');
             jQuery('#item_video_preview').val(fileurl);
            tb_remove();
        };
        return false;
    });
    
    
    $('#page_custom_image_button').on( 'click', function(event) {
        formfield = $('#page_custom_image').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            imgurl = $('img', html).attr('src');
            $('#page_custom_image').val(imgurl);
            tb_remove();
        };
        return false;
    });
    
    $('#page_custom_video_button').on( 'click', function(event) {
        formfield = $('#page_custom_video').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            var pathArray = html.match(/<media>(.*)<\/media>/);
            var mediaUrl = pathArray != null && typeof pathArray[1] != 'undefined' ? pathArray[1] : '';
          
            if(mediaUrl===''){
               mediaUrl = jQuery(html).attr("href");
            }
            jQuery('#page_custom_video').val(mediaUrl);
            tb_remove();
        };
        return false;
    });
    
    
    
    $('#page_custom_video_cover_image_button').on( 'click', function(event) {
        formfield = $('#page_custom_image').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            imgurl = $('img', html).attr('src');
            $('#page_custom_video_cover_image').val(imgurl);
            tb_remove();
        };
        return false;
    });
    
    
    $('#post_local_video_button').on( 'click', function(event) {
        formfield = $('#post_local_video').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function (html) {
            var pathArray = html.match(/<media>(.*)<\/media>/);
            var mediaUrl = pathArray != null && typeof pathArray[1] != 'undefined' ? pathArray[1] : '';
          
            if(mediaUrl===''){
               mediaUrl = jQuery(html).attr("href");
            }
            jQuery('#post_local_video').val(mediaUrl);
            tb_remove();
        };
        return false;
    });


});