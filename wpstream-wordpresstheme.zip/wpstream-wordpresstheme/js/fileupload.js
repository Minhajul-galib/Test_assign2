(function($){

    $(document).ready( function(){



    wpstream_start_upload('featured_image');
    wpstream_start_upload('media_logo'); 
    wpstream_start_upload('movie_poster');
    wpstream_start_upload('video_preview');

        // Just to be sure that the input will be called
       function wpstream_start_upload(name){
            $("#"+name+"_file_upload").on("click", function(){
                $('#'+name+'_file_input').click(function(event) {
                    event.stopPropagation();
                });
            });

            $('#'+name+'_file_input').on('change', prepareUpload);
       }

        function prepareUpload(event) { 
            var file = event.target.files;
            var parent = $("#" + event.target.id).parent();
          
            var data = new FormData();
            var nonce = $("#_wpnonce").val();
            data.append("action", "wpstream_file_upload");
            data.append("nonce", nonce );
            $.each(file, function(key, value){
                data.append("wpstream_file_upload", value);
            });

            var previewID = parent.attr("id") + "_preview";
            var previewParent = $("#"+previewID);
            previewParent.children(".wpstream_upload_mess").show(); 
            previewParent.children(".wpstream_file_delete").hide(); 
            
            
            
            $.ajax({
    		  url: fileup_vars.ajax_url,
	          type: 'POST',
	          data: data,
	          cache: false,
	          dataType: 'json',
	          processData: false, // Don't process the files
	          contentType: false, // Set content type to false as jQuery will tell the server its a query string request
	          success: function(data, textStatus, jqXHR) {	
                  
	              if( data.response == "SUCCESS" ){
		                var preview = "";
		                if( data.type === "image/jpg" 
		                  || data.type === "image/png" 
		                  || data.type === "image/gif"
		                  || data.type === "image/jpeg"
		                ) {
		                  preview = "<img src='" + data.url + "' />";
		                } else {
		                  preview = "<img src='" + file_upload_vars.nonimage + "' />";
		                }
		  
		                var previewID = parent.attr("id") + "_preview";
		                var previewParent = $("#"+previewID);
		                previewParent.show();
                                previewParent.children(".wpstream_submit").val(data.attach_id);
                                previewParent.children(".wpstream_upload_mess").hide();
                                previewParent.children(".wpstream_file_delete").show(); 
                                previewParent.find(".wpstream_file_preview img").remove();
                          
		                previewParent.children(".wpstream_file_preview").prepend( preview );
		                previewParent.children( "button" ).attr("data-fileurl",data.attach_id ).show();
		                parent.children("input").val("");
		                //parent.hide();
	                
	                 } else {
		             alert( data.error );
	                 }

		}

            });

        }


        
        
        $(".wpstream_file_delete").on("click", function(e){
                e.preventDefault();
                var nonce = $("#_wpnonce").val();
                var fileurl = $(this).attr("data-fileurl");
                var parent = $(this).parent().parent();
                var data = { fileurl: fileurl, action: 'wpstream_file_delete', nonce: nonce  };
                $.ajax({
                  url: fileup_vars.ajax_url,
                  type: 'POST',
                  data: data,
                  cache: false,
                  dataType: 'json',
                  success: function(data, textStatus, jqXHR) {	

                        if( data.response == "SUCCESS" ){
                            parent.find('img').remove();
                            parent.find('.wpstream_file_delete').hide();
                            parent.find('.wpstream_submit').val('');
                        }

                if( data.response == "ERROR" ){
                    
                }
                  },
                  error: function(jqXHR, textStatus, errorThrown)
            { 
             
            }
          });

        });




    });



})(jQuery);