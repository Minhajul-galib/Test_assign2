<?php
// 1 is none ,2 is image, 3 rev slder,4 themeslider, 5 is video
global $post;
$global_media_header=wpstream_get_option('media_header_type');

if( isset($post->ID) && is_single() ){
    $global_media_header=wpstream_get_option('media_header_type_blog');
}else if( is_tax() || is_category()  ){
    $global_media_header=wpstream_get_option('media_header_type_taxonomy');
}

?>

<div class="header_media">
    <?php
    $local_header='';
    if(isset($post->ID)){
        $local_header= get_post_meta($post->ID,'media_header_type','true');
        
        if( class_exists( 'WooCommerce' ) && is_shop()  ){
            $local_header= get_post_meta(wc_get_page_id('shop'),'media_header_type','true');
        }
    }

    if($local_header==0){
        $header_media   =   $global_media_header;
    }else{
        $header_media   =   $local_header;
    }
    
    
    if(is_singular('product') || is_singular('wpstream_product')){
        $header_media=10;
    }


    switch ($header_media) {
        case 1:
            //none
            break;
        case 2:
          
            if($local_header==0){
                $image = wpstream_get_option('global_header_static_image','url');
                
                if( isset($post->ID) && is_single() ){
                    if(wpstream_get_option('blog_use_featured_image')=='yes'){
                         $image = get_the_post_thumbnail_url($post->ID);
                    }else{
                        $image = wpstream_get_option('blog_header_static_image','url');
                    }
                  
                }else if( is_tax() || is_category()  ){
                    if(wpstream_get_option('tax_header_use_featured_image')=='yes'){
                        global $wp_query;
                        $tax = $wp_query->get_queried_object();
                 
                        
                        $page_header_title_over_image       =   $tax->name; 
                        $cat_id                             =   $tax->term_id; 
                        $term_meta                          =   get_option( "taxonomy_$cat_id");
                        $image                              =   $term_meta['category_featured_image'] ? $term_meta['category_featured_image'] : '';
                    }else{
                        $image = wpstream_get_option('tax_header_static_image','url');
                    }
                   
                }


            }else{
                $image = get_post_meta($post->ID,'page_custom_image','true');
            }
            wpstream_header_image($image);
            break;
        case 3:
            if($local_header==0){
                $slider= wpstream_get_option('global_revolution_slider');
                
                if( isset($post->ID) && is_single() ){
                    $slider= wpstream_get_option('blog_header_revolution_slider');
                }else if( is_tax() || is_category()  ){
                    $slider= wpstream_get_option('tax_header_revolution_slider');
                }
                
            }else{
                $slider=get_post_meta($post->ID,'rev_slider','true');
            }
            if(function_exists('putRevSlider')){
                putRevSlider($slider);
            }
            break;
        case 4:   
            wpestate_present_theme_slider();
            break;
        case 5:
            wpstream_video_header();
            break;
        case 10:
            wpstream_video_header_product($post->ID);
            break;
        case 11:
            wpstream_title_header($post->ID);
            break;
    }
    ?>
</div>