<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of login_register
 *
 * @author cretu
 */


//change get_template_link
// css for wpstream_button wpstream_button_effect


class WpEstate_login_register {
   
    
    
    /**
     * Constructor
     * 
     *
     * 
     */
    function __construct() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->start_init_login_register();
    }
    
    
    /**
    *  Start loading actions 
    * 
    *
    * 
    */
    
    public function start_init_login_register(){
        add_action('wp_footer', array($this,'add_footer_nonces'));
        add_action('wp_head',array($this,'wpestate_reset_password'));
       
        // ajax actions       
        add_action( 'wp_ajax_nopriv_wpestate_ajax_login_function',array($this,'wpestate_ajax_login_function') );  
        add_action( 'wp_ajax_wpestate_ajax_login_function', array($this,'wpestate_ajax_login_function') );  
        
        add_action( 'wp_ajax_nopriv_wpestate_ajax_register_function',array($this,'wpestate_ajax_register_function') );  
        add_action( 'wp_ajax_wpestate_ajax_register_function', array($this,'wpestate_ajax_register_function') );  

        add_action( 'wp_ajax_nopriv_wpestate_ajax_forgot_pass',array($this, 'wpestate_ajax_forgot_pass') );  
        add_action( 'wp_ajax_wpestate_ajax_forgot_pass',array($this, 'wpestate_ajax_forgot_pass') );  
    } 
    
    
    
  
    /**
    *  Compose form
    *  
    *
    * 
    */
    function compose_form($context='topbar'){
        $return='';
        $return.=   '<div class="wpestate_login_register_wrapper wpestate_item_wrapper">';
        $return.=   $this->show_login_form($context);
        $return.=   $this->show_register_form($context);
        $return.=   $this->show_forgot_form($context);
        
        $return.='<div class="wpestate_login_register_control login-modal-control">
                <a href="#" data-action="wpestate_show_on_register"     
                        class="show_register_form_action wpestate_item_wrapper  wpestate_show_on_login wpestate_show_on_forgot"    
                        id="widget-register-'.$context.'">'.esc_html__('Need an Account? Register here!','wpstream-wordpresstheme').'</a>
               
                <a href="#" data-action="wpestate_show_on_forgot"       
                        class="show_forgot_pass_form_action wpestate_item_wrapper wpestate_show_on_register wpestate_show_on_login" 
                        id="forgot-pass-'.$context.'">'.esc_html__('Forgot Password?','wpstream-wordpresstheme').'</a>
                            
                <a href="#" data-action="wpestate_show_on_login"        
                        class="show_login_form_again_action wpestate_item_wrapper wpestate_show_on_forgot wpestate_show_on_register" 
                        id="widget-login-'.$context.'">'.esc_html__('Back to Login','wpstream-wordpresstheme').'</a>  
              
                <input type="hidden" name="loginpop" id="loginpop" value="0">
            </div>';
        
        $return.='</div>';
        return $return;
    }
    
    
    
     /**
     * Show login form
     * 
     *
     * 
     */
    function show_login_form($context='topbar'){
        
        $return='<div class="show-login-form-wrapper wpestate_show_on_login wpestate_item_wrapper">
                    <h3 id="login-div-title-'.$context.'" class="login-register-heading">'.esc_html__('Sign into your account','wpstream-wordpresstheme').'</h3>
                    <div class="login_form" id="login-div-'.$context.'">
                        <div class="loginalert login-message-area" id="login-message-area-'.$context.'" ></div>

                        <input type="text" class="form-control wpestate_login_user_field" name="log" id="login-user-'.$context.'"     placeholder="'.esc_html__('Username','wpstream-wordpresstheme').'"/>
                        <input type="password" class="form-control wpestate_login_pass_field" name="pwd" id="login-pwd-'.$context.'"  placeholder="'.esc_html__('Password','wpstream-wordpresstheme').'"/>
                        <input type="hidden" class="loginpop" name="loginpop" id="loginpop-wd-'.$context.'" value="0">

                        <button class=" wpestat_login_but wpstream_button_effect" id="wp-login-but-'.$context.'">'.esc_html__('Login','wpstream-wordpresstheme').'</button>
                   </div> 
                </div>';
        return $return;
    }
    
    
    
    
    
     /**
     * Show Register form
     * 
     *
     * 
     */
    
    function show_register_form($context='topbar'){

        $return='<div class="show-register-form-wrapper wpestate_show_on_register '.$context.'_is wpestate_item_wrapper">
                <h3 id="register-div-title-'.$context.'" class="login-register-heading">'.esc_html__('Create an account','wpstream-wordpresstheme').'</h3>
                <div class="login_form" id="register-div-'.$context.'">

                    <div class="loginalert register-message-area" id="register-message-area-'.$context.'" ></div>
                    <input type="text" name="user-login-register" id="user-login-register-'.$context.'" class="form-control wpestate_register_user_field" placeholder="'.esc_html__('Username','wpstream-wordpresstheme').'"/>
                    <input type="text" name="user-email-register" id="user-email-register-'.$context.'" class="form-control wpestate_register_email_field" placeholder="'.esc_html__('Email','wpstream-wordpresstheme').'"  />';

                    $enable_user_pass_status='yes';//hardcoded for the moment
                    if($enable_user_pass_status == 'yes'){
                        $return.= '<input type="password" name="user-password"         id="user-password-'.$context.'" class="form-control wpestate_register_pass_field" placeholder="'.esc_html__('Password','wpstream-wordpresstheme').'"/>
                                   <input type="password" name="user_password_retype" id="user-password-topbar-retype-'.$context.'" class="form-control wpestate_register_pass2_field" placeholder="'.esc_html__('Retype Password','wpstream-wordpresstheme').'"  />
                        ';
                    }

                    $return.='<div class="terms_conditions_wrapper"><input type="checkbox" name="terms" class="wpestate_check_field" id="user-terms-register-'.$context.'" />
                    <label id="user-terms-register-'.$context.'-label" for="user-terms-register-'.$context.'">'. esc_html__('I agree with ','wpstream-wordpresstheme').'<a href="'. wpstream_get_template_link('terms_conditions.php').'" class="wpestate_i_agree_with" target="_blank" id="user-terms-register-'.$context.'-link">'.esc_html__('terms & conditions','wpstream-wordpresstheme').'</a> </label></div>';

                    if(wpstream_get_option('wp_estate_use_captcha','')=='yes'){
                        $return.= '<div id="top-register-menu" style="float:left;transform:scale(0.75);-webkit-transform:scale(0.75);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>';
                    }

                    if($enable_user_pass_status != 'yes'){  
                        $return.='<p id="reg-passmail-'.$context.'">'. esc_html__('A password will be e-mailed to you','wpstream-wordpresstheme').'</p>';
                    }

                    $return.='<button class="wpstream_button wpestate_register_but wpstream_button_effect" id="wp-submit-register_'.$context.'" >'.esc_html__('Register','wpstream-wordpresstheme').'</button>
                  </div>
            </div>';
                
         return $return;   
    }
    
    
    
    
    
    
    
    
    
     /**
     * Show forgot form
     * 
     *
     * 
     */
    
    function show_forgot_form($context='topbar'){
        global $post;
        $return='';
        $return.='<div class="show-forgot-form-wrapper wpestate_show_on_forgot wpestate_item_wrapper">
                <h3 id="forgot-div-title-'.$context.'" class="login-register-heading">'.esc_html__('Reset Password','wpstream-wordpresstheme').'</h3>
                <div class="login_form" id="forgot-pass-div-'.$context.'">
                    <div class="loginalert forgot-pass-area" id="forgot-pass-area-'.$context.'"></div>
                    <div class="loginrow">
                        <input type="text" class="forgot-pass-field form-control" name="forgot_email" id="forgot-email-'.$context.'" placeholder="'.esc_html__('Enter Your Email Address','wpstream-wordpresstheme').'" size="20" />
                    </div>
                    <input class="postid" type="hidden"  value="';
                    if( isset($post->ID) ){
                         $return.= intval($post->ID);
                        }
                    $return.=' ">    
                    <button class="wpstream_button wpestat_forgot_but wpstream_button_effect" id="wp-forgot-but-'.$context.'" name="forgot" >'.esc_html__('Reset Password','wpstream-wordpresstheme').'</button>
                </div>
            </div>';
                
       return $return;
    }
    
    
     
     /**
     * add nonces in footer
     * 
     *
     * 
     */
    function add_footer_nonces(){
        $wpestate_login_register_nonce = wp_create_nonce( "wpestate_login_register_nonce" );
        print'<input type="hidden" id="wpestate_login_register_nonce" value="'.esc_html($wpestate_login_register_nonce).'" /> ';

    }
    
    
     
     /**
     * Login user
     * 
     *
     * 
     */


    function wpestate_ajax_login_function(){
     
        
        if ( is_user_logged_in() ) { 
            echo json_encode(array('loggedin'=>true, 'message'=>esc_html__('You are already logged in! redirecting...','wpstream-wordpresstheme')));   
            exit();
        } 


        if( !wp_verify_nonce($_POST['security-login'], 'wpestate_login_register_nonce') ){
            echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('You are not submiting from site or you have too many atempts!','wpstream-wordpresstheme'))); 
            exit();
        }



        $allowed_html   =  array();
        $login_user     =  sanitize_text_field ( $_POST['login_user'] ) ;
        $login_pwd      =  sanitize_text_field ( $_POST['login_pwd'] ) ;
        $ispop          =  intval ( $_POST['ispop'] );

        if ($login_user=='' || $login_pwd==''){      
            echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('Username and/or Password field is empty!','wpstream-wordpresstheme')));   
            exit();
        }




        wp_clear_auth_cookie();
        $info                   = array();
        $info['user_login']     = $login_user;
        $info['user_password']  = $login_pwd;
        $info['remember']       = true;
        $user_signon            = wp_signon( $info, true );


        if ( is_wp_error($user_signon) ){
            echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('Wrong username or password!','wpstream-wordpresstheme')));       
        } else {
            global $current_user;
            wp_set_current_user($user_signon->ID);
            do_action('set_current_user');
            $current_user = wp_get_current_user();


            echo json_encode(array('loggedin'=>true,'ispop'=>$ispop,'newuser'=>$user_signon->ID, 'message'=>esc_html__('Login successful, redirecting...','wpstream-wordpresstheme')));

        }
        die(); 

    }

    
     
     /**
     * Register user
     * 
     *
     * 
     */
     function wpestate_ajax_register_function(){
        
   
        $user_email  =   trim( sanitize_text_field ($_POST['user_email_register_sh']) );
        $user_name   =   trim( sanitize_text_field ($_POST['user_login_register_sh']) ) ;
       
        if (preg_match("/^[0-9A-Za-z_]+$/", $user_name) == 0) {
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'Invalid username (do not use special characters or spaces)!','wpstream-wordpresstheme')));
            die();
        }
        
        
        if ($user_email=='' || $user_name==''){
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'Username and/or Email field is empty!','wpstream-wordpresstheme')));
            exit();
        }
        
        if(filter_var($user_email,FILTER_VALIDATE_EMAIL) === false) {
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'The email doesn\'t look right!','wpstream-wordpresstheme')));
            exit();
        }
        
        // deactivated because fail checkdnsrr
//        $domain = substr(strrchr($user_email, "@"), 1);
//        if( !checkdnsrr ($domain) ){
//            echo json_encode(array('register'=>false,'message'=>esc_html__( 'The email\'s domain doesn\'t look right!','wpstream-wordpresstheme')));
//            exit();
//        }
        
        
        $user_id     =   username_exists( $user_name );
        if ($user_id){
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'Username already exists.  Please choose a new one.!','wpstream-wordpresstheme')));
            exit();
        }
        
        
        $user_pass              =   trim( sanitize_text_field(wp_kses( $_POST['user_pass_sh'] ,$allowed_html) ) );
        $user_pass_retype       =   trim( sanitize_text_field(wp_kses( $_POST['user_pass_retype_sh'] ,$allowed_html) ) );

        if ($user_pass=='' || $user_pass_retype=='' ){
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'One of the password field is empty!','wpstream-wordpresstheme')));
            exit();
        }

        if ($user_pass !== $user_pass_retype ){
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'Passwords do not match!','wpstream-wordpresstheme')));
            exit();
        }
     
        
         
        if ( !$user_id and email_exists($user_email) == false ) {
           
            $user_id         = wp_create_user( $user_name, $user_pass, $user_email );
            
            if ( is_wp_error($user_id) ){
               echo json_encode(array('register'=>false,'message'=>esc_html__( 'Internal Server Error.Please try again or contact the website owner!','wpstream-wordpresstheme')));
            }else{
               echo json_encode(array('register'=>true,'message'=>esc_html__( 'The account was created. You can login now.','wpstream-wordpresstheme')));
            }
             
        } else {
            echo json_encode(array('register'=>false,'message'=>esc_html__( 'Email already exists.  Please choose a new one!','wpstream-wordpresstheme')));
        }
        die(); 
              
    }
    
    
     /**
     * Forgot pass
     * 
     *
     * 
     */
    function wpestate_ajax_forgot_pass(){
        check_ajax_referer( 'wpestate_login_register_nonce', 'security' );
        global $wpdb;

        $allowed_html   =   array();
        $post_id        =   intval( $_POST['postid'] ) ;
        $forgot_email   =   sanitize_text_field( $_POST['forgot_email'] );
     

        if ($forgot_email==''){      
            echo esc_html__('Email field is empty!','wpstream-wordpresstheme');   
            exit();
        }

        $user_input = trim($forgot_email);

        if ( strpos($user_input, '@') ) {
            $user_data = get_user_by( 'email', $user_input );
            if(empty($user_data) || isset( $user_data->caps['administrator'] ) ) {
                echo esc_html__('Invalid E-mail address!','wpstream-wordpresstheme');
                exit();
            }

        }else {
            $user_data = get_user_by( 'login', $user_input );
            if( empty($user_data) || isset( $user_data->caps['administrator'] ) ) {
               echo esc_html__('Invalid Username!','wpstream-wordpresstheme');
               exit();
            }
        }
        $user_login = $user_data->user_login;
        $user_email = $user_data->user_email;

      

        $key = $wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login));
        if(empty($key)) {
            //generate reset key
            $key = wp_generate_password(20, false);
            $wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));
        }

        
 
       
        $message = esc_html__('Someone requested that the password be reset for the following account:','wpstream-wordpresstheme') . "\r\n\r\n";
        $message .= get_option('siteurl') . "\r\n\r\n";
        $message .= sprintf(__('Username: %s','wpstream-wordpresstheme'), $user_login) . "\r\n\r\n";
        $message .= esc_html__('If this was a mistake, just ignore this email and nothing will happen.','wpstream-wordpresstheme') . "\r\n\r\n";
        $message .= esc_html__('To reset your password, visit the following address:','wpstream-wordpresstheme') . "\r\n\r\n";
        $message .= $this->wpestate_tg_validate_url($post_id) . "action=reset_pwd&key=$key&login=" . rawurlencode($user_login) . "\r\n";
        $subject=esc_html__('Password Reset Request','wpstream-wordpresstheme');
        
        
        
        $headers[] = 'From: No Reply <noreply@'.$_SERVER['HTTP_HOST'].'>' . "\r\n";
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        @wp_mail(
            $user_email,
            stripslashes($subject),
            stripslashes($message),
            $headers
        );         
        

        echo '<div>'.esc_html__('We have just sent you an email with Password reset instructions.','wpstream-wordpresstheme').'</div>';
        die(); 

    }
    


    function wpestate_reset_password(){
        global $wpdb;
        $allowed_html   =   array();
        if(isset($_GET['key']) && isset($_GET['action'])&& $_GET['action'] == "reset_pwd") {
            $reset_key  = sanitize_text_field($_GET['key'] );
            $user_login = sanitize_text_field($_GET['login'] );
            $user_data  = $wpdb->get_row($wpdb->prepare("SELECT ID, user_login, user_email FROM $wpdb->users 
                    WHERE user_activation_key = %s AND user_login = %s", $reset_key, $user_login));


            if(!empty($user_data)){
                $user_login = $user_data->user_login;
                $user_email = $user_data->user_email;

                if(!empty($reset_key) && !empty($user_data)) {
                    $new_password = wp_generate_password(7, false); 
                    wp_set_password( $new_password, $user_data->ID );
                    //mailing the reset details to the user
                    $message = esc_html__('Your new password for the account at:','wpstream-wordpresstheme') . "\r\n\r\n";
                    $message .= get_bloginfo('name') . "\r\n\r\n";
                    $message .= sprintf(esc_html__('Username: %s','wpstream-wordpresstheme'), $user_login) . "\r\n\r\n";
                    $message .= sprintf(esc_html__('Password: %s','wpstream-wordpresstheme'), $new_password) . "\r\n\r\n";
                    $message .= esc_html__('You can now login with your new password at: ','wpstream-wordpresstheme') . get_option('siteurl')."/" . "\r\n\r\n";

                    $headers = 'From: noreply  <noreply@'.$this->wpestate_replace_server_global(site_url()).'>' . "\r\n".
                    'Reply-To: noreply@'.$this->wpestate_replace_server_global(site_url()). "\r\n" .
                    'X-Mailer: PHP/' . phpversion();

                    wp_mail($user_email, 'Your Password  Was Reseted', $message,$headers);
                    $mess= '<div class="login-alert">'.esc_html__('A new password was sent via email!','wpstream-wordpresstheme').'</div>';

                }else {
                    exit('Not a Valid Key.');
                }
            }// end if empty
        print  $mes='<div class="login_alert_full">'.esc_html__('We have just sent you a new password. Please check your email!','wpstream-wordpresstheme').'</div>';   

        } 

    }








     /**
     * url clean
     * 
     *
     * 
     */
    function wpestate_replace_server_global($link){
       return    str_replace(array('http://','https://'),'',$link);
    }   
    
    /**
     * validate url
     * 
     *
     */
    function wpestate_tg_validate_url($post_id) {
       
        $page_url = esc_url(home_url('/'));     
        $urlget = strpos($page_url, "?");
        if ($urlget === false) {
                $concate = "?";
        } else {
                $concate = "&";
        }
        return $page_url.$concate;
    }

    
}