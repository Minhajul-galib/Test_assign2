<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WpStream WordpressTheme
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

        <?php
        $favicon        =   esc_html( wpstream_get_option('fav_icon','url') );
        if ( $favicon!='' ){
            print '<link rel="shortcut icon" href="'.$favicon.'" type="image/x-icon" />';
        } else {
            print '<link rel="shortcut icon" href="'.get_theme_file_uri('/img/favicon.gif').'" type="image/x-icon" />';
        }
        
        if( is_tax() ) {
            print '<meta name="description" content="'.strip_tags( term_description('', get_query_var( 'taxonomy' ) )).'" >';
        }

        ?>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php include(locate_template('templates/mobile_menu.php')); ?>
 
<?php 
global $post;


$page_class =   '';

if(isset($post->ID)){
    $wpstream_layout         = intval( get_post_meta($post->ID,'page_layout',true) );
    
    switch ($wpstream_layout) {
        case 0:
            $page_class=' default_layout ';
            break;

        case 1:
            $page_class=' left_sidebar_layout ';
            break;

        case 2:
            $page_class=' right_sidebar_layout ';
            break;

        case 3:
             $page_class=' full_layout ';
            break;

        case 4:
            $page_class=' full_width_layout ';
            break;

        default:
            break;
    }
    }

    $wide_header  = wpstream_get_option('wide_header');
    if($wide_header == '1'){
        $page_class.=' wide_header';
    }
        
    $header_type = wpstream_get_option('header_type');
    if($header_type==1){
        $page_class.=' header_type_1 ';
    }else if($header_type==2){
        $page_class.=' header_type_2 ';
    }
    
    $header_align = wpstream_get_option('header_align');
    if($header_align==1){
        $page_class.=' header_align_left ';
    }else if($header_align==2){
        $page_class.=' header_align_center ';
    }else if($header_align==3){
        $page_class.=' header_align_right ';
    }
   
$is_transparent         =   wpstream_return_transparent_header_class();    
$logo                   =   wpstream_get_option('header_logo','url');
$stikcy_logo_image      =   wpstream_get_option('sticky_header_logo','url');
$transparent_logo_image =   wpstream_get_option('transparent_header_logo','url');

if ($logo==''){
    $logo=get_template_directory_uri() . '/img/logo.png';
}
if ($stikcy_logo_image==''){
    $stikcy_logo_image=get_template_directory_uri() . '/img/logo.png';
}

if(trim($is_transparent)=='transparent_header'){
    if ($transparent_logo_image==''){
        $logo=get_template_directory_uri() . '/img/logo_transparent.png';
    }else{
        $logo=$transparent_logo_image;
    }
}

$page_class .=$is_transparent;
if (wpstream_show_top_bar() && !is_page_template( 'splash_page.php' )) {
    $page_class.=' has_top_bar ';
}
?>    
    

    
<div id="page" class="site <?php echo $page_class; ?> ">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'wpstream-wordpresstheme' ); ?></a>       
        <?php
        if (wpstream_show_top_bar()) {
          get_template_part('templates/top_bar');
        }
        ?>

        <?php get_template_part('templates/mobile_menu_header'); ?>   
        
	<header id="masthead" class="site-header" data-logo="<?php print $logo;?>" data-sticky-logo="<?php print $stikcy_logo_image; ?>">
            
            <div class="header_wrapper">
		<div class="site-branding">
                    <a href="<?php echo home_url('/','login'); ?>" class="custom-logo-link" xxx rel="home" itemprop="url">
			<?php
                            print '<img  id="logo_image" src="' . $logo . '" class="custom-logo"  alt="logo"/>';
                        ?>
                </a>
		</div><!-- .site-branding -->
                <?php if ($header_type==2) { 
                 print '<div class="header2_menu_wrapper"><div class="header2_container_wrapper">';
                }?>
                    <nav id="site-navigation" class="main-navigation">
                            <?php
                            wp_nav_menu( array(
                                    'theme_location' => 'primary',
                                    'menu_id'        => 'primary-menu',
                            ) );
                            ?>
                    </nav><!-- #site-navigation -->

                    <?php wpstream_header_shoping_cart(); ?>
                <?php if ($header_type==2) { 
                print '</div></div>';
                }?>
                
            </div><!-- #header wrapper -->   
            
	</header><!-- #masthead -->

        <?php    get_template_part('header_media');?>
        
        
	<div id="content" class="site-content">
