<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input type="text" class="form-control search_form_wpstream" name="s" id="s" placeholder="<?php esc_html_e( 'Search', 'wpstream-wordpresstheme' ); ?>" />
    <button class="search_form_but"> <i class="fas fa-search"></i> </button>

</form>
