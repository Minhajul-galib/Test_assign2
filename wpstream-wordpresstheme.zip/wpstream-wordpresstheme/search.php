<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WpStream WordpressTheme
 */

get_header();
?>

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title">
					<?php
					/* translators: %s: search query. */
					printf( esc_html__( 'Search Results for: %s', 'wpstream-wordpresstheme' ), '<span>' . get_search_query() . '</span>' );
					?>
				</h1>
			</header><!-- .page-header -->

			<?php
			/* Start the Loop */
                        global $count;
                        $count = 0;?>
                        <div class=" columns-2 search_res_wrapper">
                            <ul class="products columns-2" >
                                <?php 
                                    while ( have_posts() ) :
                                            the_post();


                                            if( get_post_type()=='product' ){
                                                wc_get_template_part( 'content', 'product' );
                                            }else if(get_post_type()=='wpstream_product'){
                                                get_template_part('templates/free_product_unit');
                                            }else{
                                                get_template_part('templates/blog_unit');
                                            }
                                            $count++;

                                    endwhile;
                                ?>
                            </ul>   
                        </div>
                        <?php
			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_sidebar();
get_footer();
