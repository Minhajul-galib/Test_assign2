<?php
global $backimage;
$post_id        =   $post->ID;
if(function_exists('wc_get_product')){
    $product        =   wc_get_product( $post_id );
}
$return_string  =   '';    
$thumb_id       =   get_post_thumbnail_id($post_id);


if($backimage==''){
    $preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
    $backimage      =   $preview[0];
    if($preview[0]==''){
        $backimage= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
    }
}


$link                   =   get_permalink();
$title                  =   get_the_title();
if( function_exists('wc_get_product_category_list')){
    $categories             =   wc_get_product_category_list($post_id);
}
$rating                 =   '';
$page_custom_video      =   get_post_meta($post_id, 'item_video_preview', true);
$content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),170).' ...';
$wpstream_actors        =   get_the_term_list($post_id,'wpstream_actors',' ',', ',' ');
$wpstream_category      =   get_the_term_list($post_id,'wpstream_category',' ',', ',' ');
$wpstream_movie_rating  =   get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ');
$currency='';
if(function_exists('get_woocommerce_currency_symbol')){
    $currency               =   get_woocommerce_currency_symbol();        
}
$price                  =   get_post_meta( $post_id, '_regular_price', true);
$sale                   =   get_post_meta( $post_id, '_sale_price', true); 
$show_price             =   '';//use this one to show price

if(!wpstream_is_global_subscription() && function_exists('wc_price')){
    if($sale) : 
        $show_price= '<p class="wpstream_featured_product-price-tickr"><del>'.wc_price($price).'</del> '.wc_price($sale).'</p>';
    elseif($price) :
        $show_price= '<p class="wpstream_product-price-tickr">'.wc_price($price).'</p>';    
    endif;
}

 if($price ==0){
    $show_price=__( 'Watch Now', 'wpstream-wordpresstheme' );
} else{
    $show_price=__( 'Buy Now', 'wpstream-wordpresstheme' );
}
 

$return_string.=    '<div class="featured_product featured_product_type2"  >';
$return_string.=    '<div class="product_slider_image_back"  style="background-image:url('.$backimage.');"></div>';
$return_string.=    '<div class="product_new_details_back"></div>';
$return_string.=    '<div class="featured_details_wrapper">';
$return_string.=    '<a href="'.$link.'" class="featured_title">'.$title.'</a>';
$return_string.=    '<div class="featured_content">'.$content.'</div>';
$return_string.=    '<a href="'.$link.'" class="featured_button wpstream_button_effect">'.$show_price.'</a>';
$return_string.=    '</div>';
$return_string.=    wpstream_product_play_video($post_id);
$return_string.=    '</div>';

print $return_string;