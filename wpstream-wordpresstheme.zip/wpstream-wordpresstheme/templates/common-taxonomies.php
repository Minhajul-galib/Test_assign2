<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WpStream WordpressTheme
 */

get_header();
?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<div class="archive-description">', '</div>' );
				?>
			</header><!-- .page-header -->
                        
            <div class=" columns-2">
                <?php
                /* Start the Loop */
                global $count;
                global $wpstream_row_number;
                global $wpstream_product_counter;
                global $wpstream_computed_last;
                $count=0;
                
                
                $wpstream_product_counter=0;
                $wpstream_row_number=3;
                $design_type = wpstream_get_option('wpstream_unit_card');
           
                if($design_type==2){
                    $wpstream_row_number=wpstream_get_option('wpstream_unit2_per_row');
                    if($wpstream_row_number >3){
                        $wpstream_row_number=$wpstream_row_number-1;
                    }
                   
                }
                
                if($design_type==1){
                    $wpstream_row_number=2;
                }
                
                $wpstream_computed_last=$wpstream_row_number;
    
                ?>
                <ul class="products allcomul columns-<?php echo $wpstream_row_number;?>" >
                    <?php   
                        while ( have_posts() ) :the_post();
                            if( get_post_type()=='product' ){
                                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
                                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per_taxonomy',1 );

                                wc_get_template_part( 'content', 'product' );

                                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per_taxonomy',1 );
                                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
                                $wpstream_product_counter++;
                            }else if(get_post_type()=='wpstream_product'){
                                get_template_part('templates/free_product_unit');
                            }else{
                                get_template_part('templates/blog_unit');
                            }
                            $count++;
                         

			endwhile;
                        wp_reset_query();
			the_posts_navigation();
                        wpstream_pagination('', $range = 2);         
                        ?>
                </ul> 
                <?php   
		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
            </div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
