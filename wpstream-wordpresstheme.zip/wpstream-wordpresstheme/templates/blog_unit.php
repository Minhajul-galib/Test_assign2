<?php
global $count;
global $wpstream_layout;
global $wpstream_row_number;
global $redux_builder_wpstream;
$title                                  =   get_the_title();
$preview                                =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstream_blog_unit');       
$categories_list                        =   get_the_category_list( esc_html__( ', ', 'wpstream-wordpresstheme' ) );
$wpstream_wordpresstheme_comment_count  =   get_comments_number();

?>


<li class="blog_unit_container columns-<?php print $wpstream_row_number;wpstream_show_unit_last_class();?>">
    
    <div class="blog_unit_wrapper" data-link="<?php echo esc_url(get_permalink());?>">

        <?php
       if( has_post_thumbnail($post->ID) ){
           print '<div class="blog_unit-img">
                    <div class="blog_image" style="background-image:url('.$preview[0].');"></div>
                      <span class="wpstream_button_effect">'.$categories_list.'</span>
                        <div class="product_new_details_back"></div>
                   </div>';


       }?>

        <div class="blog-unit-content">
            <h4 class="blog_unit-title">
               <a href="<?php echo esc_url(get_permalink()); ?>" class="blog_unit-title-link">
                   <?php 
                       echo $title;
                   ?>
               </a>
            </h4>

            <div class="blog-unit-excerpt">
               <?php echo wp_trim_words( get_the_content(), 28, '...' );?> 
           </div>

            <div class="blog_unit_button">
               <a href="<?php echo esc_url(get_permalink()); ?>" class="read_more"> <?php print esc_html__( 'CONTINUE READING', 'wpstream-wordpresstheme' );?> </a>
            </div>

        </div><!--blog-unit-content-->

    </div> <!--blog_unit_wrapper-->
</li>