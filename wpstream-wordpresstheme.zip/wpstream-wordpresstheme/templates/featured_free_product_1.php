<?php
global $sale_line;
    
$post_id        =   $post->ID;
$product = wc_get_product( $post_id );


$return_string  =   '';    
$thumb_id       =   get_post_thumbnail_id($post_id);
$preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstrem_product_featured');
if($preview[0]==''){
    $preview[0]= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
}
$link                   =   get_permalink();
$title                  =   get_the_title();
$categories             =   get_the_term_list($post_id,'wpstream_category','',', ');;
$rating                 =   '';
$page_custom_video      =   get_post_meta($post_id, 'item_video_preview', true);
$content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),20).' ...';
$wpstream_actors        =   get_the_term_list($post_id,'wpstream_actors',' ',', ',' ');
$wpstream_category      =   get_the_term_list($post_id,'wpstream_category',' ',', ',' ');
$wpstream_movie_rating  =   get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ');
$currency               =   get_woocommerce_currency_symbol();        
$show_price             =   esc_html_e('Free','wpstream-wordpresstheme');//use this one to show price






$return_string.=    '<div class="featured_free_product featured_free_product_type1"  style="background-image:url('.$preview[0] .')">';
$return_string.=    '<div class="featured_gradient"></div>';
$return_string.=    '<div class="featured_details_wrapper">';
$return_string.=    '<a href="'.$link.'" class="featured_title">Title '.$title.'</a>';
$return_string.=    $rating;
$return_string.=    $content;
$return_string.=    $categories;
$return_string.=    '</div>';
if( !wpstream_is_global_subscription() ){
    $return_string.=    '<p class="wpstream_featured_product-price-tickr">'.__( 'Free', 'wpstream-wordpresstheme' ).'</p>';
}
$return_string.=    '</div>';

print $return_string;