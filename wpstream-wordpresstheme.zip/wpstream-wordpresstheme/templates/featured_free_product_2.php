<?php
global $sale_line;
global $backimage;
 
$post_id        =   $post->ID;
$product = wc_get_product( $post_id );


$return_string  =   '';    
if($backimage==''){
    $preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstrem_product_featured');
    $backimage      =   $preview[0];
    if($preview[0]==''){
        $backimage= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
    }
}

$link                   =   get_permalink();
$title                  =   get_the_title();
$categories             =   get_the_term_list($post_id,'wpstream_category','',', ');;
$rating                 =   '';
$page_custom_video      =   get_post_meta($post_id, 'item_video_preview', true);
$content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),170).' ...';
$wpstream_actors        =   get_the_term_list($post_id,'wpstream_actors',' ',', ',' ');
$wpstream_category      =   get_the_term_list($post_id,'wpstream_category',' ',', ',' ');
$wpstream_movie_rating  =   get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ');




$return_string.=    '<div class="featured_free_product featured_free_product_type2"  style="background-image:url('.$backimage .')">';
$return_string.=    '<div class="product_new_details_back"></div>';
$return_string.=    '<div class="featured_details_wrapper">';
$return_string.=    '<a href="'.$link.'" class="featured_title">Title '.$title.'</a>';
$return_string.=    '<div class="featured_content">'.$content.'</div>';
$return_string.=    '<a href="'.$link.'" class="featured_button wpstream_button_effect">'.__( 'Watch Now', 'wpstream-wordpresstheme' ).'</a>';
$return_string.=    '</div>';
$return_string.=    '</div>';

print $return_string;