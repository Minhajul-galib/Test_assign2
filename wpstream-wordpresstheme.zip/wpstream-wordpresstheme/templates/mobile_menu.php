<div class="mobilewrapper">
    <div class="snap-drawers">
        <!-- Left Sidebar-->
        <div class="snap-drawer snap-drawer-left">
            <div class="mobilemenu-close"><i class="fas fa-times"></i></div>           
            <?php  wp_nav_menu( array( 
                    'theme_location' => 'mobile',
                    'container' => false,
                    'menu_class'      => 'mobilex-menu',
                ) );?>
           
        </div>  
  </div>
</div>  
<?php global $wpestate_social_login;?>

<div class="mobilewrapper-user">
    <div class="snap-drawers">
   
    <!-- Right Sidebar-->
        <div class="snap-drawer snap-drawer-right">
    
        <div class="mobilemenu-close-user"><i class="fas fa-times"></i></div>
        <?php
        
        print '
            <div class="login_sidebar_mobile">
            '.wpstream_get_user_menu().'
            </div>';
    
        ?>
  
        </div>  
    </div>              
</div>
      