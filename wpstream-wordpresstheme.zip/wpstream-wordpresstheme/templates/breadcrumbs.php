<nav class="wpstream-breadcrumb">
    <a href="'.home_url().'"><?php esc_html_e('Home','wpstream-wordpresstheme');?></a>/
    <?php 
    echo get_the_term_list($post->ID,'wpstream_category','',', ');
    ?> / 
    <?php the_title();?>
</nav>