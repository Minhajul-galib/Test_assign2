<?php  
global $count;
global $wpstream_layout;
global $wpstream_row_number;
$design_type    =   intval ( wpstream_get_option('wpstream_unit_card') );
 

if($design_type==1){
?>
<li class="wpstream_product_list post-<?php echo $post->ID.' '.$count; ; ?> wpstream_free_product_card wpstream_unit_1 product type-product status-publish 
    <?php 
    wpstream_show_unit_last_class();
    ?> 
    ">
	
    <a href="<?php echo get_permalink($post->ID); ?>" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
        <div class="wpstream_thumb_wrapper thumb_is_here3">
            <?php 
            
            print get_the_post_thumbnail( $post->ID , 'wpstream_video_preview' );
            
            if( !wpstream_is_global_subscription() ){
               print '<p class="wpstream_product-price-unit for_type1">'.esc_html__('Free','wpstream-wordpresstheme').'</p>';    
            }
            
            
            
            $page_custom_video  =   get_post_meta($post->ID, 'item_video_preview', true);
            if($page_custom_video!=''){
                print '<video muted  id="videoplay'.$post->ID.'" class="wpstream_thumb_video"  width="100%" height="100%" style="display:none">
                    <source src="'.$page_custom_video.'" type="video/mp4" />
                </video>';
            }  
            ?>
        </div>
        
        <h2 class="woocommerce-loop-product__title"><?php the_title();?></h2>
    </a>
    
    <?php
    $movie_type='';
    if(function_exists('wc_get_product_category_list') ){
        $movie_type= wc_get_product_category_list($post->ID); 
    }
    $movie_type2= get_the_term_list($post->ID,'wpstream_category',' ',', ',' ');

    if($movie_type!='' && $movie_type2!=''){
        $movie_type.=', ';
    }
   
    $movie_type.=$movie_type2;
    
    ?>
    
    <div class="wpstream_posted_in"><?php  echo $movie_type;  ?></div>
  

    
    
</li>
<?php
}else if($design_type==2){
    get_template_part('templates/free_product_unit2');
}
?>