<?php
global $backimage;
global $featured_unit_hight;
$post_id        =   $post->ID;
if (function_exists('wc_get_product')){
    $product = wc_get_product( $post_id );
}


$return_string  =   '';    
$thumb_id       =   get_post_thumbnail_id($post_id);

if($backimage==''){
    $preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstrem_product_featured');
    $backimage      =   $preview[0];
    if($preview[0]==''){
        $backimage= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
    }
}


$link                   =   get_permalink();
$title                  =   get_the_title();
if(function_exists('wc_get_product_category_list')){
    $categories             =   wc_get_product_category_list($post_id);
}
$page_custom_video      =   get_post_meta($post_id, 'item_video_preview', true);
$content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),20).' ...';
$wpstream_actors        =   get_the_term_list($post_id,'wpstream_actors',' ',', ',' ');
$wpstream_category      =   get_the_term_list($post_id,'wpstream_category',' ',', ',' ');
$wpstream_movie_rating  =   get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ');
$show_price             =   '';//use this one to show price
if( !wpstream_is_global_subscription() ){
    $currency='';
    if(function_exists('get_woocommerce_currency_symbol')){
        $currency               =   get_woocommerce_currency_symbol();
    }
    $price                  =   get_post_meta( $post_id, '_regular_price', true);
    $sale                   =   get_post_meta( $post_id, '_sale_price', true); 

    if(function_exists('wc_price')){
        if($sale) : 
            $show_price= '<p class="wpstream_featured_product-price-tickr"><del>'.wc_price($price).'</del> '.wc_price($sale).'</p>';
        elseif($price) :
            $show_price= '<p class="wpstream_featured_product-price-tickr">'.wc_price($price).'</p>';    
        endif;
    }
 }




$theid=$post_id;
$return_string.=    '<div class="featured_product featured_product_type1"   style="height:'.$featured_unit_hight.'px;">';
$return_string.=    '<div class="product_slider_image_back"  style="background-image:url('.$backimage.');"></div>';
$return_string.=    '<div class="product_new_details_back"></div>';
$return_string.=    '<div class="featured_details_wrapper">';
$return_string.=    '<div class="featured_product_category_wrapper ">'.$wpstream_category.'</div>';
$return_string.=    '<a href="'.$link.'" class="featured_title">'.$title.'</a>';
$return_string.=    '<a href="'.$link.'" class="featured_button_round ">'.$show_price.'</a>';
$return_string.=    '</div>';
$return_string.=    wpstream_product_play_video($post_id);


$return_string.=    '</div>';

print $return_string;