<?php
global $sale_line;
    
$post_id        =   $post->ID;
$return_string  =   '';    
$thumb_id       =   get_post_thumbnail_id($post_id);
$preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstrem_product_featured');
if($preview[0]==''){
    $preview[0]= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
}
$link                   =   get_permalink();
$title                  =   get_the_title();
$categories             =   get_the_category_list( esc_html__( ', ', 'wpstream-wordpresstheme' ) );
$content                =   get_the_excerpt();
$date                   =   get_the_date('F j, Y');
$comments_number        =   get_comments_number();


    
$return_string.=    '<div class="featured_article featured_article_type1">';
$return_string.=        '<div class="featured_article_image"  style="background-image:url('.$preview[0] .')">';
$return_string.=            '<div class="featured_gradient"></div>';
$return_string.=        '</div>';
$return_string.=        '<div class="featured_article_details_wrapper">';
$return_string.=            '<a href="'.$link.'" class="featured_article_title">Title '.$title.'</a>';
$return_string.=            '<div class="featured_article_list_details">';
$return_string.=                '<div class="article_categories">'.$categories.',  ';
$return_string.=                    $comments_number.__( ' Comments', 'wpstream-wordpresstheme' ).',  ' ;
$return_string.=                    esc_html__( 'Added: ', 'wpstream-wordpresstheme' ).$date.' ';
$return_string.=                        wpstream_post_play_video($post_id);
$return_string.=            '</div></div>';
$return_string.=        '</div>';
$return_string.=    '</div>';

print $return_string;