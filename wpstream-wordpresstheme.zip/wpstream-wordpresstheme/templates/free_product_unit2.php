<?php  
global $count;
global $wpstream_layout;
global $wpstream_row_number;
?>
<li class="wpstream_product_list wpstream_unit_2 post-<?php echo $post->ID  ?> wpstream_free_product_card product type-product status-publish 
    <?php 
    wpstream_show_unit_last_class();
    ?>
    ">

    <div class="wpstream_thumb_wrapper thumb_is_here4">
        <a href="<?php echo get_permalink($post->ID );?>"> <div class="product_new_details_back"></div></a>
        
        <?php echo get_the_post_thumbnail($post->ID , 'wpstream_video_preview_type2');?>
        
        <p class="wpstream_product-price-unit"><?php esc_html_e('Free','wpstream-wordpresstheme')?></p>
        <div class="wpstream_add_to_cart_unit2">
            <a class="button" href="<?php echo get_permalink($post->ID);?>"><?php esc_html_e('Watch Now','wpstream-wordpresstheme')?></a>
        </div>
    </div>
    <?php
    
    $movie_type='';
    if(function_exists('wc_get_product_category_list')){
        $movie_type= wc_get_product_category_list($post->ID); 
    }
    $movie_type2= get_the_term_list($post->ID,'wpstream_category',' ',', ',' ');

    if($movie_type!='' && $movie_type2!=''){
        $movie_type.=', ';
    }
   
    $movie_type.=$movie_type2;
    
    ?>  
    
     <h2 class="woocommerce-loop-product__title"><?php the_title();?></h2>
    <div class="wpstream_posted_in"><?php    echo $movie_type; ?></div>     
   
    
</li>
