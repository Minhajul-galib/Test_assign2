<?php
global $sale_line;
$post_id        =   $post->ID;

$return_string  =   '';    
$thumb_id       =   get_post_thumbnail_id($post_id);
$preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'full');
if($preview[0]==''){
    $preview[0]= get_theme_file_uri('/img/defaults/default_property_featured.jpg');
}
$link                   =   get_permalink();
$title                  =   get_the_title();
$categories             =   get_the_category_list( esc_html__( ', ', 'wpstream-wordpresstheme' ) );
$content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),170).' ...';




$return_string.=    '<div class="featured_article featured_article_type2"  style="background-image:url('.$preview[0] .')">';
$return_string.=    '<div class="product_new_details_back"></div>';
$return_string.=    '<div class="featured_details_wrapper">';
$return_string.=    '<a href="'.$link.'" class="featured_title">'.$title.'</a>';
$return_string.=    '<div class="featured_content">'.$content.'</div>';
$return_string.=    '<a href="'.$link.'" class="featured_button wpstream_button_effect">'.__( 'Read Now', 'wpstream-wordpresstheme' ).'</a>';
$return_string.=    '</div>';
$return_string.=    '</div>';

print $return_string;