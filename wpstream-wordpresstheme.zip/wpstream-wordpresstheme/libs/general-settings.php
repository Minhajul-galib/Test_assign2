<?php


function wpstream_get_live_event_for_user_nonadmin(){
    $current_user       =   wp_get_current_user();
    $allowded_html      =   array();
    $userID             =   $current_user->ID;
    $return_uri         =   '';
   
    $event_data         =   wpstream_request_live_stream_for_user($userID);
    return $event_data;
}










///////////////////////////////////////////////////////////////////////////////////////////
/////// Define thumb sizes
///////////////////////////////////////////////////////////////////////////////////////////
if( !function_exists('wpstream_image_size') ):
    function wpstream_image_size(){
    //1.77 ratio for video
        add_image_size('wpstream_blog_widget',          300,300,true); 
        add_image_size('wpstream_blog_widget_small',    60,60,true); 
        add_image_size('wpstream_blog_unit',            400,200,true);               
        add_image_size('wpstream_video_preview',        380,214,true); 
        add_image_size('wpstream_video_preview_type2',  400,600,true); 
        add_image_size('wpstrem_product_image',         758,445,true);    
        add_image_size('wpstrem_product_featured',      900,600,true);    
            
//        add_image_size('wpestate_slider_thumb'        , 143,  83, true); //
//        add_image_size('wpestate_property_listings'   , 400, 314, true); // 1.6 590, 362, 1.27 386, 302
//        add_image_size('wpestate_property_featured'   , 1170, 921, true); // 1.27
//        add_image_size('wpestate_property_listings_page'   , 240, 160, true); // 1.6 590, 362, 1.27 386, 302
//        add_image_size('wpestate_property_places'   , 600, 456, true);//1.315
//        add_image_size('wpestate_property_full_map'   , 1920, 790, true);//2.4
//        add_image_size('wpestate_user_thumb'          , 60, 60, true);
//        set_post_thumbnail_size(  250, 220, true);
    }
endif;

