<?php

/*----------------------------------------------
#WP_Widget_Recent_Posts
------------------------------------------------*/

Class My_Recent_Posts_Widget extends WP_Widget_Recent_Posts {
	function widget($args, $instance) {
		extract( $args );	
		$title = apply_filters('widget_title', empty($instance['title']) ? __('Recent Posts') : $instance['title'], $instance, $this->id_base);		
		if( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) )
			$number = 10;			
		$r = new WP_Query( apply_filters( 'widget_posts_args', 
                                                array( 'posts_per_page' => $number, 
                                                       'no_found_rows' => true, 
                                                       'post_status' => 'publish', 
                                                       'ignore_sticky_posts' => true 
                                                    ) 
                                                ) 
                                  );
		if( $r->have_posts() ) :
			echo $before_widget;
			if( $title ) echo $before_title . $title . $after_title; ?>
			<ul>
                            <?php while( $r->have_posts() ) : $r->the_post(); ?>				
                            <li>
                                <div class="post-thumbnail_widget">
                                    <?php  
                                        if ( is_active_sidebar( 'first-footer-widget-area') && is_active_sidebar('second-footer-widget-area') && is_active_sidebar('third-footer-widget-area') ) {
                                            $preview     =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstream_blog_widget_small');
                                        }else {  
                                            $preview     =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstream_blog_widget');
                                        }
                                    ?>      
                                    <?php if( $preview[0]!=''){?>
                                        <div class="widget_thumbnail_img" style="background-image: url('<?php print $preview[0];  ?>')" ></div> 
                                    <?php } ?>
                                
                                </div>
                                
                                <a href="<?php the_permalink(); ?>" class="recent_entries_title" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                                <div class="recent_entries_date"><?php the_time( 'F j, Y '); ?></div>  
                            </li>
                            <?php endwhile; ?>
			</ul>
			 
			<?php
			echo $after_widget;
		
		wp_reset_postdata();    
            endif;
	}
}

function wpstream_recent_widget_registration() {
    unregister_widget('WP_Widget_Recent_Posts');
    register_widget('My_Recent_Posts_Widget');
    
}

add_action('widgets_init', 'wpstream_recent_widget_registration');

/*--------------------------------------------------------------------
 #WP_Widget_Categories
 ----------------------------------------------------------------------*/

Class My_Post_Categories extends WP_Widget_Categories {
    function widget($args, $instance) { 
            extract( $args );
            $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Categories' );
            $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
            if ( $title ) {
                    echo $args['before_title'] . $title . $args['after_title'];
                    }
            $c = ! empty( $instance['count'] ) ? '1' : '0';
            $h = ! empty( $instance['hierarchical'] ) ? '1' : '0';
            $d = ! empty( $instance['dropdown'] ) ? '1' : '0';
            
            $cat_args = array(
                            'orderby'      => 'name',
                            'show_count'   => $c,
                            'hierarchical' => $h,
                    );
            

    }     
}





class Login_widget extends WP_Widget {
        
	function __construct(){
	//function Login_widget(){
		$widget_ops = array('classname' => 'loginwd_sidebar boxed_widget', 'description' => 'Put the login & register form on sidebar');
		$control_ops = array('id_base' => 'login_widget');
		//$this->WP_Widget('login_widget', 'Wp Estate: Login & Register', $widget_ops, $control_ops);
                parent::__construct('login_widget', 'Wpstream: Login & Register', $widget_ops, $control_ops);
	}
	
	function form($instance){
		$defaults = array();
		$instance = wp_parse_args((array) $instance, $defaults);
		$display='';
		print $display;
	}


	function update($new_instance, $old_instance){
		$instance = $old_instance;
		return $instance;
	}



	function widget($args, $instance){
		extract($args);
                $display='';
		global $post;
                global $wpestate_login_register;
		print $before_widget;
		$mess='';
		
                
                $current_user = wp_get_current_user();
                $userID                 =   $current_user->ID;
                $user_login             =   $current_user->user_login;
                $user_email             =   get_the_author_meta( 'user_email' , $userID );
                $home_url               =   home_url();
                $user_agent_id          =   intval( get_user_meta($current_user->ID,'user_agent_id',true));
                
                $dashboardpage         =   get_permalink('user_dashboard_add_agent.php');
                
                $logged_display='
                    <h2 class="widget-title" >'.esc_html__('Hello ','wpstream-wordpresstheme'). ' '. $user_login .'  </h2>
                    <ul class="wd_user_menu">';       
                        $logged_display.='<li>'.wpstream_get_user_menu().'</li> </ul>';
                
               if ( is_user_logged_in() ) {                   
                  print $logged_display;
               }else{
                  print $wpestate_login_register->compose_form('sidebar'); 
               }
               print $after_widget;
	}

}

add_action( 'widgets_init', function(){
	register_widget('Login_widget');
});
