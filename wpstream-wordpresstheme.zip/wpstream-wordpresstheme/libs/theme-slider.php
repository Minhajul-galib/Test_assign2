<?php

if( !function_exists('wpestate_present_theme_slider') ):
    function wpestate_present_theme_slider(){

        $theme_slider   =   wpstream_get_option( 'wp_estate_theme_slider', ''); 

        if(empty($theme_slider)){
            return; // no listings in slider - just return
        }

        $counter    =   0;
        $slides     =   '';
        $indicators =   '';
        $args = array(  
                    'post_type'        =>   array( 'product','wpstream_product' ),
                    'post_status'      =>   'publish',
                    'post__in'         =>   $theme_slider,
                    'posts_per_page'   =>   -1
                  );
       
        $recent_product = new WP_Query($args);
        $slider_cycle   =   wpstream_get_option( 'wp_estate_slider_cycle'); 
        if($slider_cycle == 0){
         
        }
        $theme_slider_height   =   wpstream_get_option( 'wp_estate_theme_slider_height');
        if($theme_slider_height==0){
            $theme_slider_height=900;
        }
        
        print '<div class="theme_slider_wrapper theme_slider  " data-auto="'.$slider_cycle.'" style="height:'.$theme_slider_height.'px;">';

        while ($recent_product->have_posts()): $recent_product->the_post();
               $theid=get_the_ID();
           
                $preview        =    get_post_meta($theid, 'item_poster_preview', true);


               if($counter==0){
                    $active=" active ";
                }else{
                    $active=" ";
                }
                
                $currency='';
                if(function_exists('get_woocommerce_currency_symbol')){
                    $currency = get_woocommerce_currency_symbol();
                }
                
                $price = get_post_meta( $theid, '_regular_price', true);
     
                $product_price='';
                if(function_exists('wc_price')){
                    $product_price=wc_price($price);
                }
                
                if($price ==0 || wpstream_is_global_subscription() ){
                    $show_price=esc_html__( 'Watch Now', 'wpstream-wordpresstheme' );
                } else{
                    $show_price=esc_html__( 'Buy Now', 'wpstream-wordpresstheme' );
                }

                $content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),100).' ...';
                $wpstream_actors        =   get_the_term_list($theid,'wpstream_actors',' ',', ',' ');
                $movie_rating           =   get_the_term_list($theid,'wpstream_movie_rating',' ',', ',' ');
                $wpstream_category      =   get_the_term_list($theid,'wpstream_category',' ',', ',' ');
                $product_date           =   get_the_date('F j, Y',$theid)    ;
                $page_custom_video      =   get_post_meta($theid, 'item_video_preview', true);
                $item_image_preview     =   get_post_meta($theid, 'item_image_preview', true);
                
                
                if($item_image_preview!=''){
                    $title_item =  '<img class="wpstream_video_preview_image" src="'.$item_image_preview.' ">';
                }else{
                    $title_item =   get_the_title();
                }
                
                $id_code=wpstream_generateRandomString_for_theme();
            
                $slides.= '
                <div class="product_slider_type1 '.$active.'" style="height:'.$theme_slider_height.'px;"  >

                    <div class="product_slider_image_back" style="background-image:url('.esc_url($preview).');height:'.$theme_slider_height.'px;" ></div>
                
                     
                        <div class="product_new_details" data-href="'.get_permalink().'">  
                            <h3><a href="'.get_permalink().'">'.$title_item.'</a> </h3>
                            <div class="product_new_details_info">
                                <div class="theme_slider_list_details">
                                    <div class="theme_slider_category"><strong>'.esc_html('Category','wpstream-wordpresstheme').':</strong> '.$wpstream_category.'</div>
                                    <div class="theme_slider_actors"><strong>'.esc_html('Actors','wpstream-wordpresstheme').':</strong> '.$wpstream_actors.'</div>  
                                    <div class="theme_slider_actors"><strong>'.esc_html__('Rating','wpstream-wordpresstheme').':</strong>'.$movie_rating.'</div>
                            
                                    '.wpstream_product_play_video($theid,'1').'
                                </div>
                        
                                
                            </div>
                           
                        </div>
                        
                        
                </div>';
  
               $counter++;
        endwhile;
        wp_reset_query();
        print $slides.'
            </div>';
    } 
endif;



if( !function_exists('wpestate_present_theme_slider2') ):
    function wpestate_present_theme_slider2(){

        $theme_slider   =   wpstream_get_option( 'wp_estate_theme_slider', ''); 

        if(empty($theme_slider)){
            return; // no listings in slider - just return
        }

        $counter    =   0;
        $slides     =   '';
        $indicators =   '';
        $args = array(  
                    'post_type'        =>   array( 'product','wpstream_product' ),
                    'post_status'      =>   'publish',
                    'post__in'         =>   $theme_slider,
                    'posts_per_page'   =>   -1
                  );
       
        $recent_product = new WP_Query($args);
        $slider_cycle   =   wpstream_get_option( 'wp_estate_slider_cycle'); 
        if($slider_cycle == 0){
         
        }
        $theme_slider_height   =   wpstream_get_option( 'wp_estate_theme_slider_height');
        if($theme_slider_height==0){
            $theme_slider_height=900;
        }
        
        print '<div class="theme_slider_wrapper theme_slider_2  " data-auto="'.$slider_cycle.'" style="height:'.$theme_slider_height.'px;">';

        while ($recent_product->have_posts()): $recent_product->the_post();
               $theid=get_the_ID();
           
                $preview        =   wp_get_attachment_image_src(get_post_thumbnail_id(), 'wpstrem_product_featured');


               if($counter==0){
                    $active=" active ";
                }else{
                    $active=" ";
                }

                $currency = get_woocommerce_currency_symbol();
                
                $price = get_post_meta( $theid, '_regular_price', true);
     
                $product_price=wc_price($price);
                 if($price ==0 || wpstream_is_global_subscription() ){
                    $show_price=__( 'Watch Now', 'wpstream-wordpresstheme' );
                } else{
                    $show_price=__( 'Buy Now', 'wpstream-wordpresstheme' );
                }

                $content                =   wpstream_shortens_text_but_doesnt_cutoff_words( get_the_excerpt(),100).' ...';
                $wpstream_actors        =   get_the_term_list($theid,'wpstream_actors',' ',', ',' ');
                $wpstream_category      =   get_the_term_list($theid,'wpstream_category',' ',', ',' ');
                $product_date           =    get_the_date('F j, Y',$theid)    ;
                $page_custom_video      =   get_post_meta($theid, 'item_video_preview', true);

          
                $id_code=wpstream_generateRandomString_for_theme();
                
                $slides.= '
                <div class="product_slider_type2 '.$active.'" style="height:'.$theme_slider_height.'px;"  >

                    <div class="product_slider_image_back" style="background-image:url('.$preview[0].');height:'.$theme_slider_height.'px;" ></div>
                
                        <div class="product_new_details_back"></div>
                        <div class="product_new_details" data-href="'.get_permalink().'">  
                            <h3><a href="'.get_permalink().'">'.get_the_title().'</a> </h3>
                            <div class="product_new_details_info">
                                <div class="theme_slider_list_details">
                                     '.$wpstream_category.'
                                       
                                </div>
                                <div class="theme_slider_content">'.$content.'</div>
                                
                            </div>
                            <a href="'.get_permalink().'" class="theme_slider_button">'.$show_price.'</a>
                        </div>
                    
                </div>';
//<div class="featured_product_play" data-player-code="'.$id_code.'"> <i class="fa fa-play fa-3x" aria-hidden="true"></i> </div>
//                    <video  id="'.$id_code.'" class="featured_product_type2_video" poster="" width="100%" height="100%" controls >
//                        <source src="'.$page_custom_video.'" type="video/mp4" />
//                    </video>
            
               $counter++;
        endwhile;
        wp_reset_query();
        print $slides.'
            </div>';
    } 
endif;
