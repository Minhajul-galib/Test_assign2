<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function wpstream_wordpresstheme_scripts() {
    global $post;
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    // load the css files
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    wp_enqueue_style( 'font-awesome5.min',  trailingslashit( get_template_directory_uri() ) . '/css/fontawesome/css/all.css' );   
    wp_enqueue_style( 'fontello',  get_theme_file_uri('/css/fontello/fontello.css') );  
    wp_enqueue_style( 'bootstrap',get_template_directory_uri().'/css/bootstrap.min.css', array(), '1.0', 'all');
    wp_enqueue_style( 'wpstream-wordpresstheme-style', get_stylesheet_uri() );
    wp_enqueue_style( 'wpstream_media',get_template_directory_uri().'/css/my_media.css',array() , '1.0', 'all'); 
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    // load the js files
    /////////////////////////////////////////////////////////////////////////////////////////////////////////

    wp_enqueue_script( 'wpstream-wordpresstheme-navigation', get_template_directory_uri() . '/js/navigation.js', array(),  true );
    wp_enqueue_script( 'wpstream-wordpresstheme-control', get_template_directory_uri() . '/js/control.js', array('lity.min','jquery'), true );
    
    wp_enqueue_script( 'wpstream-fileup', get_template_directory_uri() . '/js/fileupload.js', array(), true );
    wp_localize_script( 'wpstream-fileup', 'fileup_vars',
            array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

    
    $scroll_trigger= intval ( wpstream_get_option('wp_estate_header_height','') );  
    if($scroll_trigger==0){
        $scroll_trigger=100;
    }
      
    wp_localize_script('wpstream-wordpresstheme-control', 'control_vars', 
             array(         
                'scroll_trigger'        =>  $scroll_trigger,
                'ajaxurl'               =>  admin_url('admin-ajax.php'),
                'terms_cond'            =>  esc_html__( 'You must to agree with terms and conditions!','wpstream-wordpresstheme'),
                'login_redirect'        =>  get_permalink( get_option('woocommerce_myaccount_page_id') ),
                'login_loading'         =>  esc_html__('Sending user info, please wait...','wpstream-wordpresstheme'), 
                 'use_retina'           => floatval( wpstream_get_option('wpstream_use_retina','') )
                )
    );

    
    
    wp_enqueue_script( 'wpstream-wordpresstheme-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(),  true );
    wp_enqueue_script( 'wpstream-wordpresstheme_popper', trailingslashit( get_template_directory_uri() ).'js/popper.min.js',array('jquery'), '1.0', false);
    wp_enqueue_script( 'bootstrap.min', trailingslashit( get_template_directory_uri() ).'js/bootstrap.min.js',array('jquery'), '1.0', false);
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }   
    wp_enqueue_script('all_external', get_theme_file_uri('/js/all_external.min.js'),array(), '1.0', false); 
    wp_enqueue_style( 'wpstream-roboto', "https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" );
    
    
    wp_enqueue_script('all_external', get_theme_file_uri('/js/all_external.min.js'),array(), '1.0', false); 
    wp_enqueue_style('lity', get_theme_file_uri ('/css/lity.css') );
    wp_enqueue_script('lity.min', get_template_directory_uri().'/js/lity.min.js',array(), '1.0', true); 
    
    wp_enqueue_script("jquery-ui-slider");
    wp_enqueue_script("jquery-ui-datepicker"); 
    wp_enqueue_script('jquery.fileupload',   get_template_directory_uri().'/js/jquery.fileupload.js',array(), '1.0', true); 
    wp_localize_script('jquery.fileupload', 'file_upload_vars', 
        array( 
            'nonimage'             => get_theme_file_uri('/img/nonimage.png'),
        )
    );
    
    
//    
//    $wpstream_use_chat_live_stream = wpstream_get_option('wpstream_use_chat_live_stream','');
//    if ($wpstream_use_chat_live_stream==1 && is_single() ){
//        $live_event_array       =   get_post_meta($post->ID,'live_event_uri',true);
//        $variable = substr($live_event_array, 0, strpos($live_event_array, "live.streamer.wpstream.net/wpstream/"));
//        $variable= str_replace('rtmp://', '', $variable);
//        $variable.='live.streamer.wpstream.net:10110/';
//        
//       
//        
//        wp_enqueue_script( 'jquery-ui-autocomplete' );
//        wp_enqueue_script( 'sockjs-0.3.min', get_template_directory_uri() . '/chat_lib/sockjs-0.3.min.js', array('jquery'), true );
//        wp_enqueue_script( 'emojione.min.js',get_template_directory_uri(). '/chat_lib/emojione.min.js', array('jquery'), true );
//        wp_enqueue_script( "jquery-effects-core");
//        wp_enqueue_script( 'jquery.linkify.min.js', get_template_directory_uri() . '/chat_lib/jquery.linkify.min.js', array('jquery'), true );
//        wp_enqueue_script( 'ripples.min.js', get_template_directory_uri() . '/chat_lib/ripples.min.js', array('jquery'), true );
//        wp_enqueue_script( 'material.min.js"', get_template_directory_uri() . '/chat_lib/material.min.js', array('jquery'), true );
//        wp_enqueue_script( 'chat.js', get_template_directory_uri() . '/chat_lib/chat.js', array('jquery'), true );
//        wp_localize_script('chat.js', 'chat_vars', 
//            array( 
//                'link'=>esc_html(get_post_meta($post->ID,'chatUrl',true))
//            )
//        );
//
//
//        wp_enqueue_style( 'chat.css',get_template_directory_uri().'/chat_lib/css/chat.css', array(), '1.0', 'all');
//        wp_enqueue_style( 'ripples.css',get_template_directory_uri().'/chat_lib/css/ripples.css', array(), '1.0', 'all');
//        wp_enqueue_style( 'emojione.min.css',get_template_directory_uri().'/chat_lib/css/emojione.min.css', array(), '1.0', 'all');
//    }
    
    

   
    if(function_exists('wpstream_request_stream_files') && intval(wpstream_get_option('allow_streaming_regular_users',''))==1 ){
    
        wpstream_request_stream_files();
        wp_localize_script('wpstream-admin-control', 'wpstream_admin_control_vars2', 
            array( 
                'allow_streaming_regular_users'             => 1,
            ));
    }

}
add_action( 'wp_enqueue_scripts', 'wpstream_wordpresstheme_scripts' );

function wpstream_request_stream_files(){
    wp_enqueue_style ('admin-css',                WPSTREAM_PLUGIN_DIR_URL.'/admin/css/wpstream-admin.css', array(), '1.0', 'all'); 
    wp_enqueue_script('wpstream-admin-control',   WPSTREAM_PLUGIN_DIR_URL.'/admin/js/admin_control.js',array(), '1.0', true);  
    wp_localize_script('wpstream-admin-control', 'wpstream_admin_control_vars', 
        array( 
            'admin_url'             =>  get_admin_url(),
            'loading_url'           =>  WPSTREAM_PLUGIN_DIR_URL.'/img/loading.gif',
            'download_mess'         =>  esc_html__('Click to download! The url will work for the next 20 minutes! Refresh page if you need to generate the link again!','wpstream-wordpresstheme'),
            'uploading'             =>  esc_html('We are uploading your file.Do not close this window!','wpstream-wordpresstheme'),
            'upload_complete2'      =>  esc_html('Upload Complete! You can upload another file!','wpstream-wordpresstheme'),
            'not_accepted'          =>  esc_html('The file is not an accepted video format','wpstream-wordpresstheme'),
            'upload_complete'       =>  esc_html('Upload Complete!','wpstream-wordpresstheme'),
            'no_band'               =>  esc_html('Not enough bandwidth.','wpstream-wordpresstheme'),
            'no_band_no_store'      =>  esc_html('Not enough bandwidth or storage.','wpstream-wordpresstheme')
            
        ));
}









if( !function_exists('wpestate_admin') ):

    function wpestate_admin($hook_suffix) {	
        global $post;            
        global $pagenow;
        global $typenow;
        wp_enqueue_script('media-upload');
        wp_enqueue_script('thickbox');
        wp_enqueue_script('my-upload'); 
        wp_enqueue_style('thickbox');
    
    
        wp_enqueue_style('adminstyle', get_theme_file_uri('/css/admin.css') );

        wp_enqueue_script('admin_control', get_theme_file_uri('/js/admin.js'),array('jquery'), '1.0', true); 
        wp_localize_script('admin_control', 'admin_control_vars', 
            array( 
                    'ajaxurl'           =>  admin_url('admin-ajax.php'),
                    'admin_url'         =>  get_admin_url(),
                )
            );

    }
endif;
add_action('admin_enqueue_scripts', 'wpestate_admin');