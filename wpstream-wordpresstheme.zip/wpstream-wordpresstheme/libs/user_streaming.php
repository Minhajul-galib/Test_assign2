<?php


add_action('wpstream_show_client_broadcast_control_action', 'wpstream_show_client_broadcast_control');
if( !function_exists('wpstream_show_client_broadcast_control') ):
    function wpstream_show_client_broadcast_control(){
        global $live_event_for_user;
        global $post;
        global $wpstream_plugin;
        $current_user   =   wp_get_current_user();
        $userID         =   $current_user->ID;
        print '<div class="user_broadcast_area">';
            $ajax_nonce = wp_create_nonce( "wpstream_start_event_nonce" );
            print '<input type="hidden" id="wpstream_start_event_nonce" value="'.$ajax_nonce.'">';
            global $wpstream_plugin;
            $live_event_for_user    =   $wpstream_plugin->wpstream_live_connection->wpstream_request_live_stream_for_user($userID);
            $event_id               =   wpstream_get_current_event_per_author();
            if($event_id!=0){
                $wpstream_plugin->admin->wpstream_live_stream_unit($event_id);
            }
       
        
    }
endif;



add_action('wpstream_upload_item', 'wpstream_upload_item_function');
function wpstream_get_current_event_per_author(){
    $current_user   =   wp_get_current_user();
    $userID         =   $current_user->ID;
  
    $args = array(
        'post_type'         =>  'wpstream_product',
        'author'            =>  $userID,
        'posts_per_page'    =>  1,
        'fields'            =>  'ids'
    );
    $author_posts = new WP_Query( $args );
    if( $author_posts->have_posts() ) {
        $author_posts->the_post();
        return get_the_ID();
    }else{
        return 0;
    }
    
}


if( !function_exists('wpstream_upload_item_function') ):
function wpstream_upload_item_function() {
 
    $current_user   =   wp_get_current_user();
    $userID         =   $current_user->ID;
        
  
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      
        $stream_title               =   sanitize_text_field($_POST['stream_title']);
        $stream_desc                =   sanitize_text_field($_POST['stream_desc']);
        $wpstream_category          =   sanitize_text_field($_POST['wpstream_category']);
        $wpstream_movie_rating      =   sanitize_text_field($_POST['wpstream_movie_rating']);
        $post_id                    =   wpstream_get_current_event_per_author();
        
        
        if(  $post_id == 0 ){
            // we have insert
            $post = array(
                'post_title'	=>  $stream_title,
                'post_content'	=>  $stream_desc,
                'post_type'     =>  'wpstream_product' ,
                'post_author'   =>  $userID,
                'post_status'   =>  'publish',
            );
            $post_id =  wp_insert_post($post );  
        }else{
            $post = array(
                'ID'            => $post_id,
                'post_title'	=> $stream_title,
                'post_content'	=> $stream_desc,
                'post_type'     => 'wpstream_product' ,
                
            );
            wp_update_post($post );  
        } 
        
        // global options
        update_post_meta ($post_id, 'page_layout',0);
        update_post_meta ($post_id, 'header_transparent', 'global');
        update_post_meta ($post_id, 'page_header_type', 0);
        update_post_meta ($post_id, 'sidebar_select', 'user-event-area');
        update_post_meta ($post_id, 'wpstream_product_type',1);
        
        
        // featured image
        if(intval($_POST['featured_image_submit'])==0){
            delete_post_thumbnail($post_id);
        }else{
            set_post_thumbnail($post_id,intval($_POST['featured_image_submit']));
        }
        
        
        //media logo
        if(intval($_POST['media_logo_submit'])==0){
            update_post_meta($post_id, 'item_image_preview', '');
        }else{
            $url = wp_get_attachment_url(   intval($_POST['media_logo_submit']) );
            update_post_meta($post_id, 'item_image_preview', $url); 
            update_post_meta($post_id, 'item_image_preview_id', intval($_POST['media_logo_submit']) ); 
        }
        
        // media postr
        if(intval($_POST['movie_poster_submit'])==0){
            update_post_meta($post_id, 'item_poster_preview', '');
        }else{
            $url = wp_get_attachment_url(   intval($_POST['movie_poster_submit'])  );
            update_post_meta($post_id, 'item_poster_preview', $url); 
            update_post_meta($post_id, 'item_poster_preview_id', intval($_POST['movie_poster_submit']) ); 
        }
        
        
        //video preview
         if(intval($_POST['video_preview_submit'])==0){
            update_post_meta($post_id, 'item_video_preview', '');
        }else{
            $url = wp_get_attachment_url(   intval($_POST['video_preview_submit'])  );
            update_post_meta($post_id, 'item_video_preview', $url); 
            update_post_meta($post_id, 'item_video_preview_id', intval($_POST['video_preview_submit']) ); 
        }
        
        
        
        
        
        if( isset($wpstream_category) && $wpstream_category!='none' ){
            $wpstream_category                  =   get_term( $wpstream_category, 'wpstream_category');
            if( isset($wpstream_category->name) ){
                wp_set_object_terms($post_id,$wpstream_category->name,'wpstream_category'); 
            }
        }  
        if( isset($wpstream_movie_rating) && $wpstream_movie_rating!='none' ){
            $wpstream_movie_rating                  =   get_term( $wpstream_movie_rating, 'wpstream_movie_rating');
            if( isset($wpstream_movie_rating->name) ){
                wp_set_object_terms($post_id,$wpstream_movie_rating->name,'wpstream_movie_rating'); 
            }
        }  


        if( isset( $_POST['wpstream_actors'] )  ){
            $actors_to_add=array();
            foreach( $_POST['wpstream_actors'] as $key=>$value ){
                $value  =   intval($value);
                $actor  =   get_term( $value, 'wpstream_actors');

                if(isset($actor->name)){
                   $actors_to_add[]=$actor->name;
                }
                wp_set_object_terms($post_id,$actors_to_add,'wpstream_actors'); 
            }

        }  
        header('Location: '.$_SERVER['REQUEST_URI']);  exit();
        
    }
    
    
    
 

}
endif;




add_action('wpstream_show_broadcast_button_action', 'wpstream_show_broadcast_button_action_function');
if( !function_exists('wpstream_show_broadcast_button_action_function') ):
function wpstream_show_broadcast_button_action_function(){
   
    add_filter( 'wp_dropdown_cats', 'wpstream_dropdown_cats_multiple', 10, 2 );
        
    $event_id                       =   wpstream_get_current_event_per_author();
    $title                          =   '';
    $content                        =   '';
    $wpstream_category_selected     =   '';
    $wpstream_actors_selected       =   array();
    $wpstream_movie_rating_selected =   '';
    $page_custom_video              =   '';
    $item_image_preview             =   '';
    $item_poster_preview            =   '';
    $page_custom_video_id           =   '';
    $item_image_preview_id          =   '';
    $item_poster_preview_id         =   '';
    
    if($event_id!=0){
        $title              =   get_the_title($event_id);
        $content            =   get_the_content($event_id);
        $wpstream_category  =   get_the_terms( $event_id, 'wpstream_category');
      
        if( isset($wpstream_category[0]->term_id) ){
            $wpstream_category_selected =   $wpstream_category[0]->term_id;
        }
        
        $wpstream_actors  =   get_the_terms( $event_id, 'wpstream_actors');
        foreach($wpstream_actors as $key => $value ){
            $wpstream_act   =    get_term( $value, 'wpstream_actors');
            if(isset($wpstream_act->term_id)){
                $wpstream_actors_selected[]=$wpstream_act->term_id;
            }
        }
        
        
        $wpstream_movie_rating =   get_the_terms( $event_id, 'wpstream_movie_rating');
        if(isset($wpstream_movie_rating[0]->term_id)){
            $wpstream_movie_rating_selected =   $wpstream_movie_rating[0]->term_id;
        }
        
        $page_custom_video                  =   get_post_meta($event_id, 'item_video_preview', true);
        $item_image_preview                 =   get_post_meta($event_id, 'item_image_preview', true);
        $item_poster_preview                =   get_post_meta($event_id, 'item_poster_preview', true);
        $page_custom_video_id               =   get_post_meta($event_id, 'item_video_preview_id', true);
        $item_image_preview_id              =   get_post_meta($event_id, 'item_image_preview_id', true);
        $item_poster_preview_id             =   get_post_meta($event_id, 'item_poster_preview_id', true);
    }
        

        
    ?>    
    <form action="" class="wpstream_submit_event"
        method="POST"
        enctype="multipart/form-data"
        class="direct-upload">
        
        
        <h4><?php esc_html_e('Your Event Details','wpstream-wordpresstheme');?></h4>
        <div class="submit_item">
            <label for="stream_title"><?php esc_html_e('Channel Name','wpstream-wordpresstheme')?></label>
            <input type="text" name="stream_title" id="stream_title" class="form-controlx" value="<?php echo esc_html($title);?>">
        </div>
        
        <div class="submit_item">
            <label for="stream_desc"><?php esc_html_e('Channel Description','wpstream-wordpresstheme')?></label>
            <textarea name="stream_desc" id="stream_desc" class=""><?php echo esc_html($content);?></textarea>
        </div>
        
        <div class="submit_item">
            <label for="stream_desc"><?php esc_html_e('Channel Category','wpstream-wordpresstheme')?></label>
            <?php 

            
                $args=array(
                        'class'       => 'select-submit2',
                        'hide_empty'  => false,
                        'selected'    => $wpstream_category_selected,
                        'name'        => 'wpstream_category',
                        'id'          => 'wpstream_category',
                        'orderby'     => 'NAME',
                        'order'       => 'ASC',
                        'show_option_none'   => esc_html__('None','wpstream-wordpresstheme'),
                        'taxonomy'    => 'wpstream_category',
                        'hierarchical'=> true,
                      
                    );
                wp_dropdown_categories( $args ); ?>
        </div>
        
              
        <div class="submit_item">
            <label for="stream_desc"><?php esc_html_e('Actors','wpstream-wordpresstheme')?></label>
            <?php 
          
    
                if(is_array($wpstream_actors_selected)){
                    $wpstream_actors_selected_string= implode(',', $wpstream_actors_selected);
                }
            
                $args=array(
                        'class'       => 'select-submit2',
                        'hide_empty'  => false,
                        'selected'    => $wpstream_actors_selected_string,
                        'name'        => 'wpstream_actors',
                        'id'          => 'wpstream_actors',
                        'orderby'     => 'NAME',
                        'order'       => 'ASC',
                        'show_option_none'   => esc_html__('None','wpstream-wordpresstheme'),
                        'taxonomy'    => 'wpstream_actors',
                        'hierarchical'=> true,
                      'multiple'=> true,
                    );
                
      
                wp_dropdown_categories( $args ); 
             
            ?>
        </div>
        
                      
        <div class="submit_item">
            <label for="stream_desc"><?php esc_html_e('Channel Rating','wpstream-wordpresstheme')?></label>
            <?php 
      
                $args=array(
                        'class'       => 'select-submit2',
                        'hide_empty'  => false,
                        'selected'    => $wpstream_movie_rating_selected,
                        'name'        => 'wpstream_movie_rating',
                        'id'          => 'wpstream_movie_rating',
                        'orderby'     => 'NAME',
                        'order'       => 'ASC',
                        'show_option_none'   => esc_html__('None','wpstream-wordpresstheme'),
                        'taxonomy'    => 'wpstream_movie_rating',
                        'hierarchical'=> true
                    );
                wp_dropdown_categories( $args ); ?>
        </div>
            
            
        <?php wp_nonce_field( 'wpstream_file_upload' ); ?>
            
        <div class="submit_item">
           <?php wpstream_media_uploader_form('featured_image',$event_id,esc_html__('Featured Image','wpstream-wordpresstheme'),''); ?>
        </div>   
       
        <div class="submit_item">
           <?php wpstream_media_uploader_form('media_logo',$event_id,esc_html__('Media Logo','wpstream-wordpresstheme'),$item_image_preview_id); ?>
        </div>   
            
            
        <div class="submit_item">
           <?php wpstream_media_uploader_form('movie_poster',$event_id,esc_html__('Movie Poster','wpstream-wordpresstheme'),$item_poster_preview_id); ?>
        </div>   
            
        <div class="submit_item">
           <?php wpstream_media_uploader_form('video_preview',$event_id,esc_html__('Video Preview','wpstream-wordpresstheme'),$page_custom_video_id); ?>
        </div>  
            
            
        
    <div class="submit_item">
        <input type="hidden" name="eventid" value="<?php echo $event_id; ?>">    
        <input type="submit" class=" submit_wpstream_button  wpstream_button_effect" value="<?php esc_html_e('SAVE','wpstream-wordpresstheme');?>">
    </div>
        
    </form>
    
        
    <?php
}
endif;



if( !function_exists('wpstream_media_uploader_form') ):
function wpstream_media_uploader_form($name,$post_id,$label,$value){
    
    $image='';
    $attachment_id='';
    
    if(intval($post_id)!=0){
        if($name=='featured_image'){
            $image              = get_the_post_thumbnail($post_id);
            $attachment_id      = get_post_thumbnail_id($post_id);
        }else if($name=='video_preview'){
            if($value!=''){
                $image          =   '<img src="'.get_theme_file_uri('/img/nonimage.png').'" >';
            }else{
                $image ='';
            }
            $attachment_id  =   $value;
        }else{
            $url            =   wp_get_attachment_url($value);
            $image          =   wp_get_attachment_image($value);
            $attachment_id  =   $value;
        }
    }    

    print'  <label for="'.$name.'">'.$label.'</label>
        <div id="'.$name.'_file_upload_preview" class="file-upload file-preview" >
            <input type="hidden" class="wpstream_submit"  name="'.$name.'_submit"  value="'.$attachment_id.'">
            <div class="wpstream_upload_mess">'.esc_html__('please wait while we uploading...','wpstream-wordpresstheme').'</div>
            <div class="'.$name.'_file_preview wpstream_file_preview">';
            if($image!=''){
                print $image;
            }
    
    print '
        <div id="'.$name.'_file_upload" class="file-upload file-upload-pointer">
            <input type="file" id="'.$name.'_file_input"  />
            <p class="wpstream_file_upload_text  submit_wpstream_button  wpstream_button_effect">'. esc_html__('Upload your file', 'wpstream-wordpresstheme' ).'</p>
        </div>';

    print'  </div>';
  
    print'<button data-fileurl="'.$attachment_id.'" class="wpstream_file_delete"  ';
    if($image==''){ 
        print 'style=" display:none" ';
    }  
        
    print ' >
    '.esc_html__( 'delete', 'wpstream-wordpresstheme' ).
    '</button>';

    print' </div>';
    
    
}
endif;


if( !function_exists('wpstream_dropdown_cats_multiple') ):
function wpstream_dropdown_cats_multiple( $output, $r ) {

    if( isset( $r['multiple'] ) && $r['multiple'] ) {

        $output = preg_replace( '/^<select/i', '<select multiple data-live-search="true" data-style="btn-info"', $output );
        $output = str_replace( "name='{$r['name']}'", "name='{$r['name']}[]'", $output );
        $selected = is_array($r['selected']) ? $r['selected'] : explode( ",", $r['selected'] );
        foreach ( array_map( 'trim', $selected ) as $value ){
            $output = str_replace( "value=\"{$value}\"", "value=\"{$value}\" selected", $output );
        }
    }

    return $output;
}
endif;



