<?php



add_action( 'admin_post_wpstream_purge_cache', 'wpstream_purge_cache' );

function wpstream_purge_cache(){
    if ( isset( $_GET['action'], $_GET['_wpnonce'] ) ) {

            if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'theme_purge_cache' ) ) {
                    wp_nonce_ays( '' );
            }
  
            wpstream_delete_cache();
            wp_redirect( wp_get_referer() );
            die();
	}
}


if( !function_exists('wpestate_delete_cache') ):
function wpstream_delete_cache(){
 
    global $wpdb;
    $sql = "SELECT `option_name` AS `name`, `option_value` AS `value`
            FROM  $wpdb->options
            WHERE `option_name` LIKE '%transient_%'
            ORDER BY `option_name`";

    $results = $wpdb->get_results( $sql );
    $transients = array();

    foreach ( $results as $result ){
        if ( 0 === strpos( $result->name, '_transient_wpstream' ) ){
            $transient_name = str_replace('_transient_', '', $result->name);
            delete_transient($transient_name);
        }
    }
}
endif;