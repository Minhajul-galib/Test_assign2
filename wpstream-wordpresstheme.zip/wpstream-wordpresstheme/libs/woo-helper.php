<?php
if (!function_exists('wpstream_header_shoping_cart')):
    function wpstream_header_shoping_cart(){
        print '<div class="wpstream_header_shoping_cart">';
            print '<div class="wpstream_header_search_icon"><i class="fas fa-search"></i></div>';
        
            if( wpstream_get_option('show_top_bar_cart_icon') && class_exists( 'WooCommerce' )  ){
                print '<div class="wpstream_header_shoping_cart_icon"><i class="fas fa-shopping-cart"></i><span class="wpestream_cart_counter_header">'.WC()->cart->get_cart_contents_count().'</span></div>';
            }

            if( wpstream_get_option('show_login_in_header','')=='yes' ) {
                print '<div class="wpstream_header_user_menu_icon"><i class="far fa-user-circle"></i></div>'; 
            }
            
            print '<div class="wpstream_header_shoping_cart_search wpstream_menu_trigger">'.wpstream_get_search().'</div>';
            
            if( wpstream_get_option('show_top_bar_cart_icon')  && class_exists( 'WooCommerce' ) ){
                print '<div class="wpstream_header_shoping_cart_container wpstream_menu_trigger">'.wpstream_get_cart_contents().'</div>';
            }
            print '<div class="wpstream_header_user_menu_container wpstream_menu_trigger">'.wpstream_get_user_menu().'</div>';
        print'</div>';
    }
endif;

if (!function_exists('wpstream_get_search')):
    function wpstream_get_search(){
        $return_string=get_search_form(false);
        return $return_string;
    }
endif;




function woocommerce_template_loop_product_thumbnail(){
    global $woocommerce;
    $output         =   '';
    $post_id        =   get_the_ID();
    $design_type    =   intval ( wpstream_get_option('wpstream_unit_card') );
    $product        =   wc_get_product( $post_id );
      
    if ( has_post_thumbnail() ) {
        
        if($design_type!==2){
            $output             .=  '<div class="wpstream_thumb_wrapper thumb_is_here">'.get_the_post_thumbnail( $post_id, 'wpstream_video_preview' );
            if( !wpstream_is_global_subscription() ){
                $currency = get_woocommerce_currency_symbol();
                $price = get_post_meta( $post_id, '_regular_price', true);
                $sale = get_post_meta( $post_id, '_sale_price', true);
                $output.='<div class="product_card_type1_gradiend"></div>';
                if($sale) : 
                    $output.=  '<p class="wpstream_product-price-unit for_type1">'.wc_price($sale).'</p>';    
                elseif($price) :
                    $output.=  '<p class="wpstream_product-price-unit for_type1">'.wc_price($price).'</p>';    
                endif;
            }
            
            
            $page_custom_video   =  get_post_meta($post_id, 'item_video_preview', true);
            if($page_custom_video!=''){
                $output .= '<video id="videoplay'.$post_id.'" class="wpstream_thumb_video"  width="100%" height="100%" style="display:none">
                    <source src="'.$page_custom_video.'" type="video/mp4" />
                </video>';
            }
            $output .= '</div>';
        }else{
          
            $output.=  '<div class="wpstream_thumb_wrapper thumb_is_here2">';
            if( !wpstream_is_global_subscription() ){
                $currency = get_woocommerce_currency_symbol();
                $price = get_post_meta( $post_id, '_regular_price', true);
                $sale = get_post_meta( $post_id, '_sale_price', true);
                if($sale) : 
                    $output.=  '<p class="wpstream_product-price-unit">'.wc_price($sale).'</p>';    
                elseif($price) :
                    $output.=  '<p class="wpstream_product-price-unit">'.wc_price($price).'</p>';    
                endif;
            }
            
            $current_user = wp_get_current_user();
            
         
            
            
            if(  is_user_logged_in() ){
                
                if(wpstream_is_global_subscription() ){
                    if(wpstream_check_global_subscription_model()){
                        $output.= '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.get_permalink($post_id).'">'.esc_html__('Watch Now','wpstream-wordpresstheme').'</div></a>';
          
                    }else{
                        $main_subscription  =   wpstream_get_option('subscription_global_array');
                        $product_id         =   intval($main_subscription[0]);
                        $output             .=  '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.wc_get_cart_url().'?add-to-cart='.$product_id.'">'.esc_html__('join now','wpstream-wordpresstheme').'</div></a>';

                    }
                }else{
                    if( wc_customer_bought_product( $current_user->user_email, $current_user->ID, $product->get_id()  )){
                    
                        $output.= '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.get_permalink($post_id).'">'.esc_html__('Watch Now','wpstream-wordpresstheme').'</div></a>';
                    
                    }else{
                    
                        $output.= '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.wc_get_cart_url().'?add-to-cart='.$post_id.'">'.esc_html__('Add to Cart','wpstream-wordpresstheme').'</div></a>';
         
                    }
                }
                
            }else{
                
                if(wpstream_is_global_subscription() ){
                    
                    $main_subscription  =   wpstream_get_option('subscription_global_array');
                    $product_id         =   intval($main_subscription[0]);
                    $output             .=  '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.wc_get_cart_url().'?add-to-cart='.$product_id.'">'.esc_html__('join now','wpstream-wordpresstheme').'</div></a>';
                
                }else{
                    $output.= '<div class="wpstream_add_to_cart_unit2"><a class="button" href="'.wc_get_cart_url().'?add-to-cart='.$post_id.'">'.esc_html__('Add to Cart','wpstream-wordpresstheme').'</div></a>';
                }
            }

            $output.= ' <a href="'.get_permalink($post_id).'"><div class="product_new_details_back"></div></a>'.get_the_post_thumbnail( $post_id, 'wpstream_video_preview_type2' );
            $output .= '</div>';
        }
    } else {
        $output .= '<img src="'. wc_placeholder_img_src() .'" alt="Placeholder"  />';
    }
    print $output;
}


function woocommerce_template_loop_add_to_cart(){
    
}


function woocommerce_template_loop_product_title(){
    $post_id        =   get_the_ID();
    $product        =   wc_get_product( $post_id );
    $design_type    =   intval ( wpstream_get_option('wpstream_unit_card') );
    $output         =   '';
   
    $movie_type= wc_get_product_category_list($post_id); 
   
    $movie_type2= get_the_term_list($post_id,'wpstream_category',' ',', ',' ');

    if($movie_type!='' && $movie_type2!=''){
        $movie_type.=', ';
    }
   
    $movie_type.=$movie_type2;

    
    if($design_type==1){
        $output.='<h2 class="woocommerce-loop-product__title">'.get_the_title($post_id).'</h2>';
        $output.= '<div class="wpstream_posted_in">'.$movie_type.'</div>';
         
        
    }else if($design_type==2){
      
        $output.='<a href="'.get_permalink($post_id).'"><h2 class="woocommerce-loop-product__title">'.get_the_title($post_id).'</h2></a>';
        $output.= '<div class="wpstream_posted_in">'.$movie_type.'</div>';
    }


    print $output;
}

function woocommerce_template_loop_price(){
   
}





function wpstream_shortens_text_but_doesnt_cutoff_words($text, $length){
    if(strlen($text) > $length) {
        $text = substr($text, 0, strpos($text, ' ', $length));
    }

    return $text;
}




function woocommerce_template_loop_rating(){
    
}

add_filter( 'woocommerce_gallery_image_size', function( $size ) {
    return 'wpstrem_product_image';
} );



function wpstream_add_custom_fields(){ 
    $post_id    =   get_the_ID();
    print '<div class="wpstream_custom_info">';
        $wpstream_actors        =   get_the_term_list($post_id,'wpstream_actors',' ',', ',' ');
        $wpstream_category      =   get_the_term_list($post_id,'wpstream_category',' ',', ',' ');
        
        if($wpstream_category!=''){
            $wpstream_category.=', ';
        }
        if(function_exists('wc_get_product_category_list')){
            $wpstream_category.= wc_get_product_category_list($post_id); 
        }
        $wpstream_movie_rating  =   get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ');
        
        if($wpstream_actors!=''){
            print '<div class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('cast_label').':</span> '.get_the_term_list($post_id,'wpstream_actors',' ',', ',' ').'</div>';
        }
        if($wpstream_category!=''){
            print '<div xxx class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('movie_type_label').':</span> '.$wpstream_category.'</div>';
        }
        if($wpstream_movie_rating!=''){
            print '<div class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('rating_label').':</span> '.get_the_term_list($post_id,'wpstream_movie_rating',' ',', ',' ').'</div>';   
        }
    print '</div>';
}
add_action( 'woocommerce_single_product_summary', 'wpstream_add_custom_fields', 21 );





remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
function wpstream_add_title_product(){
    $post_id    =   get_the_ID();
    $product    =   wc_get_product( $post_id );
    print   '<div class="wpstream_title_wrapper"><h1 class="product_title entry-title">'.get_the_title($post_id).'</h1>';
    print   wc_get_rating_html( $product->get_average_rating() );

    if(!wpstream_is_global_subscription()){
        $currency = get_woocommerce_currency_symbol();
        $price = get_post_meta( get_the_ID(), '_regular_price', true);
        $sale = get_post_meta( get_the_ID(), '_sale_price', true);
        if($sale) : 
            print '<p class="wpstream_product-price-tickr"><del>'.wc_price($price).'</del> '.wc_price($sale).'</p>';    
        elseif($price) :
            print '<p class="wpstream_product-price-tickr">'.wc_price($price).'</p>';    
        endif;
    }
    print   '</div>';
}

add_action( 'woocommerce_before_single_product', 'wpstream_add_title_product', 1 );


add_filter( 'woocommerce_output_related_products_args', 'wpstream_change_number_related_products', 9999 );
 


function wpstream_change_number_related_products( $args ) {

    $design_type = intval( wpstream_get_option('wpstream_unit_card'));
    if($design_type==2){
        $args['posts_per_page'] = 3; // # of related products
        $args['columns'] = 3; // # of columns per row
    }else{
        $args['posts_per_page'] = 2; // # of related products
        $args['columns'] = 2; // # of columns per row
    }
    

    return $args;
}








if (!function_exists('wpstream_get_user_menu')):
    function wpstream_get_user_menu(){
        global $wpestate_login_register;
        $return_string='';
        if ( !is_user_logged_in() ) {   
            $return_string.=    $wpestate_login_register->compose_form('topbar');
        } else{
            if(  class_exists( 'WooCommerce' ) ){
                $items =wc_get_account_menu_items();
                foreach ($items as $slug => $title) {
                    $return_string.='<a href="'.wc_get_account_endpoint_url($slug) .'" class="wpstream-icon-'.$slug.' wpstream-woo-link">'.$title.'</a>';
                }
            }else{
            }
          
        }
        return $return_string;
    }
endif;




if (!function_exists('wpstream_get_cart_contents')):
    function wpstream_get_cart_contents(){
        $return_string='';
        
        $cart_content =  WC()->cart->get_cart_contents();
   
        foreach ($cart_content as $key => $product) {
            $product_id =   $product['product_id'];
            $quantity   =   $product['quantity'];
            $price      =   $product['line_total'];
            $product    =   wc_get_product( $product_id );
            $link       =   get_permalink($product_id);
            $title      =   get_the_title($product_id);
            $thumb      =   wp_get_attachment_image_src(get_post_thumbnail_id($product_id),'woocommerce_gallery_thumbnail');
        
            
            
            $return_string .=   '<div class="wpstream_in_cart_item">';
            $return_string .=   '<div class="wpstream_in_cart_image"><a href="'.$link.'" target="_blank"><img src="'.$thumb[0].'" alt="'.$title.'"/></a></div>';
            $return_string .=   '<div class="wpstream_in_cart_title"><a href="'.$link.'" target="_blank">'.$title.'</a></div>';
            $return_string .=   '<div class="wpstream_in_cart_price">'.$quantity.' x '.wc_price($price).'</div>';
            $return_string .=   '<div class="wpstream_in_cart_remove" data-productid="'.$product_id.'"><i class="far fa-times-circle"></i></div>';
            $return_string .=   '</div>';
        }
        
        $return_string .=  '<div class="wpstream_header_shoping_cart_total">'.esc_html__('Total:','wpstream-wordpresstheme').' '. WC()->cart->get_cart_total().'</div>';
       
        $return_string .=   '<a class="wpstream_header_view_cart " href="'.wc_get_cart_url().'">'.esc_html__('View Cart','wpstream-wordpresstheme').'</a>';
        $return_string .=   '<a class="wpstream_header_view_checkout" href="'.wc_get_checkout_url().'">'.esc_html__('Checkout','wpstream-wordpresstheme').'</a>';
       return $return_string;
    }
endif;




add_action( 'wp_ajax_nopriv_wpstream_in_cart_remove', 'wpstream_in_cart_remove' );  
add_action( 'wp_ajax_wpstream_in_cart_remove', 'wpstream_in_cart_remove' );  
if( !function_exists('wpstream_in_cart_remove') ):
    function wpstream_in_cart_remove(){
    
        $product_to_remove  =   intval($_POST['product_id']);
        $cartId             =   WC()->cart->generate_cart_id( $product_to_remove );
        $cartItemKey        =   WC()->cart->find_product_in_cart( $cartId );
        WC()->cart->remove_cart_item( $cartItemKey );
        print WC()->cart->get_cart_contents_count();
        die();

    }
endif;


//remove featured image from gallery
add_filter('woocommerce_single_product_image_thumbnail_html', 'wpstream_remove_featured_image', 10, 2);
function wpstream_remove_featured_image($html, $attachment_id ) {
    global $post, $product;

    $featured_image = get_post_thumbnail_id( $post->ID );

    if ( $attachment_id == $featured_image )
        $html = '';

    return $html;
}





add_action( 'woocommerce_widget_product_item_end', 'add_excerpt_to_widget_products', 10, 1 );
function add_excerpt_to_widget_products( $args ) {
    global $product;
   
        $subscription_model = intval( wpstream_get_option('subscription_model')) ;
        if($subscription_model==1){
            echo '<div class="wpstream_widget_product_global_subscription">'.get_the_date().'</div>';
        }
}