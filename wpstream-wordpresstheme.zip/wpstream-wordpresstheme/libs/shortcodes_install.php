<?php


function wpstream_theme_shortcodes(){
    wpestream_register_shortcodes();
    wpstream_tiny_shortcodes_register_theme();
    add_filter('widget_text', 'do_shortcode');
}


function wpstream_tiny_shortcodes_register_theme() {
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }
    
    if (get_user_option('rich_editing') == 'true') {
        add_filter('mce_external_plugins', 'wpstream_add_shortcodes_theme');
        add_filter('mce_buttons_3', 'wpstream_register_button_theme');    
    }

}


function wpstream_register_button_theme($buttons) {
    array_push($buttons, "|", "slider_recent_items");     
    array_push($buttons, "|", "recent_items");  
    array_push($buttons, "|", "featured_free_product"); 
    array_push($buttons, "|", "featured_article");
    array_push($buttons, "|", "featured_product");
    array_push($buttons, "|", "list_items_by_id"); 
    array_push($buttons, "|", "login_form"); 
    array_push($buttons, "|", "register_form");	
    array_push($buttons, "|", "categories_slider");  
    array_push($buttons, "|", "category_list");
    array_push($buttons, "|", "membership_packages"); 
    return $buttons;
}


function wpstream_add_shortcodes_theme($plugin_array) {   
    $plugin_array['slider_recent_items']        = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['recent_items']               = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['featured_free_product']      = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['featured_article']           = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['featured_product']           = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['list_items_by_id']           = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['login_form']                 = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['register_form']              = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['categories_slider']          = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['category_list']              = get_template_directory_uri() . '/js/shortcodes.js';
    $plugin_array['membership_packages']        = get_template_directory_uri() . '/js/shortcodes.js';
    return $plugin_array;
}

///////////////////////////////////////////////////////////////////////////////////////////
/////// register shortcodes
///////////////////////////////////////////////////////////////////////////////////////////


function wpestream_register_shortcodes() {
  
    add_shortcode('slider_recent_items', 'wpstream_slider_recent_posts_pictures');      
    add_shortcode('recent_items', 'wpstream_recent_posts_pictures_new');
    add_shortcode('featured_article', 'wpstream_featured_article');
    add_shortcode('featured_product', 'wpstream_featured_product');
    add_shortcode('list_items_by_id', 'wpstream_list_items_by_id_function');
    add_shortcode('login_form', 'wpstream_login_form_function');
    add_shortcode('categories_slider','wpstream_categories_slider');
    add_shortcode('category_list', 'wpstream_category_list_function');
    add_shortcode('register_form', 'wpstream_register_form_function');
   // add_shortcode('membership_packages','wpstream_membership_packages_function');
}


add_action( 'init', 'wprentals_autocomplete_populate');

function wprentals_autocomplete_populate () {
     wpstream_generate_woo_category_values_shortcode();
}




add_action( 'vc_before_init', 'wpstream_vc_shortcodes',999 );
if( function_exists('vc_map') ):
    
    if( !function_exists('wpstream_vc_shortcodes')):
        function wpstream_vc_shortcodes(){   
                      
            $places                             =   array();    
            $all_places                         =   array();
            $city_array                         =   array();
            $area_array                         =   array();
            $category_array                     =   array();
            $action_array                       =   array();
            $global_categories                  =   array();
            $membership_packages                =   array();			
            $agency_developers_array            =   array();
            $agent_array                        =   array();
            $article_array                      =   array();
            // fixed tax arrays
            $item_actors_values                 =   array();
            $item_movie_rating                  =   array();
            $property_county_state_values       =   array();
            $item_category_values               =   array();
            $item_movie_category_values         =   array();
            $random_pick                        =   array('no','yes');
            $article_array                      =   wpstream_return_article_array();
       	
            
            
            
            $item_category_values           =   get_transient('wpstream_woo_category_values');                   
            $item_movie_category_values     =   get_transient('wpstream_woo_movie_category_values');
            $item_actors_values             =   get_transient('wpstream_woo_actors_category_values');
            $item_movie_rating              =   get_transient('wpstream_woo_movie_rating_category_values');
            $all_tax = array_merge($item_category_values,$item_movie_category_values,$item_actors_values,$item_movie_rating);

     
            $featured_listings=array('no','yes');
            $items_type=array('products','free products','articles');
            vc_map(
                array(
                    "name" => esc_html__('Recent Items Slider','wpstream-wordpresstheme'),//done
                    "base" => "slider_recent_items",
                    "class" => "",
                    "category" => esc_html__('Content','wpstream-wordpresstheme'),
                    'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
                    'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
                    'weight'=>100,
                    'icon'   =>'wpstream_vc_logo',
                    'description'=>esc_html__('Recent Items Slider Shortcode','wpstream-wordpresstheme'),
                    "params" => array(
                        array(
                            "type" => "textfield",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Title","wpstream-wordpresstheme"),
                            "param_name" => "title",
                            "value" => "",
                            "description" => esc_html__("Section Title","wpstream-wordpresstheme")
                       ),
                        array(
                            "type" => "dropdown",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("What type of items","wpstream-wordpresstheme"),
                            "param_name" => "type",
                            "value" => $items_type,
                            "description" => esc_html__("products,free products or articles","wpstream-wordpresstheme")
                        ),

                        array(
                            "type" => "autocomplete",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Category Id's","wpstream-wordpresstheme"),
                            "param_name" => "category_ids",
                            "value" => "",
                            "description" => esc_html__("list of category id's sepearated by comma (*only for WooComerce products)","wpstream-wordpresstheme"),
                                                            "dependency" => array(
                                                                    "element" => "type",
                                                                    "value" => "products"
                                                            ),
                                                     'settings' => array(
                                'multiple' => true,
                                'sortable' => true,
                                'min_length' => 1,
                                'no_hide' => true, 
                                'groups' => false, 
                                'unique_values' => true, 
                                'display_inline' => true, 
                                'values' => $item_category_values,

                            )  ,
                        ),
                        array(
                            "type" => "autocomplete",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Media Category Id's","wpstream-wordpresstheme"),
                            "param_name" => "movie_categ_ids",
                            "value" => "",
                            "description" => esc_html__("list of movie categories separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                                                    "dependency" => array(
                                                    "element"   => "type",
                                                    "value"     => array('products','free products')
                                            ),
                                                     'settings' => array(
                                'multiple' => true,
                                'sortable' => true,
                                'min_length' => 1,
                                'no_hide' => true, 
                                'groups' => false, 
                                'unique_values' => true, 
                                'display_inline' => true, 
                                'values' => $item_movie_category_values,

                                                    ),
                        ), 
                        array(
                            "type" => "autocomplete",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Actors Id's ","wpstream-wordpresstheme"),
                            "param_name" => "actors_ids",
                            "value" => "",
                            "description" => esc_html__("list of actors  separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                                                            "dependency" => array(
                                                                    "element" => "type",
                                                                    "value" => array('products','free products')
                                                            ),
                                                    'settings' => array(
                                'multiple' => true,
                                'sortable' => true,
                                'min_length' => 1,
                                'no_hide' => true, 
                                'groups' => false, 
                                'unique_values' => true, 
                                'display_inline' => true, 
                                'values' => $item_actors_values,

                                                    ),
                        ),
                        array(
                           "type" => "autocomplete",
                           "holder" => "div",
                           "class" => "",
                           "heading" => esc_html__("Rating Terms Id's","wpstream-wordpresstheme"),
                           "param_name" => "ratings_ids",
                           "value" => "",
                           "description" => esc_html__("list of move rating ids separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                                                    "dependency"    => array(
                                                    "element"       => "type",
                                                    "value"         => array('products','free products')
                                            ),
                            'settings' => array(
                                'multiple' => true,
                                'sortable' => true,
                                'min_length' => 1,
                                'no_hide' => true, 
                                'groups' => false, 
                                'unique_values' => true, 
                                'display_inline' => true, 
                                'values' => $item_movie_rating,
                            ),
                        ),

                        array(
                           "type" => "textfield",
                           "holder" => "div",
                           "class" => "",
                           "heading" => esc_html__("No of items","wpstream-wordpresstheme"),
                           "param_name" => "number",
                           "value" => 4,
                           "description" => esc_html__("how many items","wpstream-wordpresstheme")
                        ), 


                        array(
                           "type" => "textfield",
                           "holder" => "div",
                           "class" => "",
                           "heading" => esc_html__("Auto scroll period","wpstream-wordpresstheme"),
                           "param_name" => "autoscroll",
                           "value" => "0",
                           "description" => esc_html__("Auto scroll period in seconds - 0 for manual scroll, 1000 for 1 second, 2000 for 2 seconds and so on.","wpstream-wordpresstheme")
                        )  


                    )
                )
            );



            vc_map(
            array(
              "name" => esc_html__("Recent Items","wpstream-wordpresstheme"),//done
               "base" => "recent_items",
               "class" => "",
               "category" => esc_html__('Content','wpstream-wordpresstheme'),
               'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
               'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
               'weight'=>100,
               'icon'   =>'wpstream_vc_logo',
               'description'=>esc_html__('Recent Items Shortcode','wpstream-wordpresstheme'),
               "params" => array(
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("Title","wpstream-wordpresstheme"),
                    "param_name" => "title",
                    "value" => "",
                    "description" => esc_html__("Section Title","wpstream-wordpresstheme")
                  ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("What type of items","wpstream-wordpresstheme"),
                    "param_name" => "type",
                    "value" => $items_type,
                    "description" => esc_html__("products,free products or articles","wpstream-wordpresstheme")
                ),
               
                array(
                    "type" => "autocomplete",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("Type Category names","wpstream-wordpresstheme"),
                    "param_name" => "category_ids",
                    "value" => "",
                    "description" => esc_html__("list of Woocomerce Product Category id's sepearated by comma (*only for products)","wpstream-wordpresstheme")   ,
                    "dependency" => array(
                                        "element" => "type",
                                        "value" => "products"
                                                               ),
                    'settings' => array(
                           'multiple' => true,
                           'sortable' => true,
                           'min_length' => 1,
                           'no_hide' => true, // In UI after select doesn't hide an select list
                           'groups' => false, // In UI show results grouped by groups
                           'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                           'display_inline' => true, // In UI show results inline view
                           'values' => $item_category_values,
                      
                        )  ,
                  ),
                     
                array(
                    "type" => "autocomplete",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("Movie Categories names","wpstream-wordpresstheme"),
                    "param_name" => "movie_categ_ids",
                    "value" => "",
                    "description" => esc_html__("list of movie categories ids separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                    "dependency" => array(
                                    "element" => "type",
                                    "value" => array("products","free products")
                            ),
                    'settings' => array(
                            'multiple' => true,
                            'sortable' => true,
                            'min_length' => 1,
                            'no_hide' => true, // In UI after select doesn't hide an select list
                            'groups' => false, // In UI show results grouped by groups
                            'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                            'display_inline' => true, // In UI show results inline view
                            'values' => $item_movie_category_values,
                      
                    ),
                  ), 
                   array(
                    "type" => "autocomplete",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__("Type Actors names","wpstream-wordpresstheme"),
                    "param_name" => "actors_ids",
                    "value" => "",
                    "description" => esc_html__("list of actirs ids separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                    "dependency" => array(
                                    "element" => "type",
                                    "value" => array("products"," free products")
                            ),
                    'settings' => array(
                            'multiple' => true,
                            'sortable' => true,
                            'min_length' => 1,
                            'no_hide' => true, // In UI after select doesn't hide an select list
                            'groups' => false, // In UI show results grouped by groups
                            'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                            'display_inline' => true, // In UI show results inline view
                            'values' => $item_actors_values,
                      
                       ),
                    ),
                    array(
                        "type" => "autocomplete",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Type Movie Ratings","wpstream-wordpresstheme"),
                        "param_name" => "ratings_ids",
                        "value" => "",
                        "description" => esc_html__("list of movie ratings ids separated by comma (*only for products and free products)","wpstream-wordpresstheme"),
                        "dependency" => array(
                                        "element"   => "type",
                                        "value"     =>  array("products","free products") 
                                ),
                        'settings' => array(
                                'multiple' => true,
                                'sortable' => true,
                                'min_length' => 1,
                                'no_hide' => true, // In UI after select doesn't hide an select list
                                'groups' => false, // In UI show results grouped by groups
                                'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                                'display_inline' => true, // In UI show results inline view
                                'values' => $item_movie_rating,

                        ),
                    ),
                   
                 
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("No of items","wpstream-wordpresstheme"),
                        "param_name" => "number",
                        "value" => 4,
                        "description" => esc_html__("how many items","wpstream-wordpresstheme")
                    ) , 
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("No of items per row","wpstream-wordpresstheme"),
                        "param_name" => "rownumber",
                        "value" => 4,
                        "description" => esc_html__("The number of items per row","wpstream-wordpresstheme")
                    ) , 
                   
                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Random Pick (yes/no) ","wpstream-wordpresstheme"),
                        "param_name" => "random_pick",
                        "value" => $random_pick,
                        "description" => esc_html__("Will deactivate theme cache and increase loading time. (*only for products)","wpstream-wordpresstheme")
                    ) ,
                   
                  
               )
            )
            );
            
             
            $featured_prop_type=array(1,2,3);
            vc_map(
            array(
               "name" => esc_html__("Featured Product","wpstream-wordpresstheme"),
               "base" => "featured_product",
               "class" => "",
               "category" => esc_html__('Content','wpstream-wordpresstheme'),
               'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
               'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
               'weight'=>100,
               'icon'   =>'wpstream_vc_logo',
               'description'=>esc_html__('Featured Product Shortcode','wpstream-wordpresstheme'),
               "params" => array(
                    array(
                       "type" => "textfield",
                       "holder" => "div",
                       "class" => "",
                       "heading" => esc_html__("Product id","wpstream-wordpresstheme"),
                       "param_name" => "id",
                       "value" => "",
                       "description" => esc_html__("Product id","wpstream-wordpresstheme")
                    ),
                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Design Type","wpstream-wordpresstheme"),
                        "param_name" => "design_type",
                        "value" =>  $featured_prop_type,
                        "description" => esc_html__("type 1 or 2","wpstream-wordpresstheme")
                    ),
                    array(
                            "type" => "attach_image",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Image","wpstream-wordpresstheme"),
                            "param_name" => "backimage",
                            "value" => "",
                            "description" => esc_html__("Please select the image.","wpstream-wordpresstheme")
                    ) ,
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Height in px","wpstream-wordpresstheme"),
                        "param_name" => "featured_unit_hight",
                        "value" => "",
                        "description" => esc_html__("Numeric field. Works only for Design type 1.","wpstream-wordpresstheme")
                    ),
                  
                )
            )
            );
            
            $featured_art_type=array(1,2);
            vc_map(
               array(
               "name" => esc_html__("Featured Article","wpstream-wordpresstheme"),
               "base" => "featured_article",
               "class" => "",
               "category" => esc_html__('Content','wpstream-wordpresstheme'),
               'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
               'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
               'weight'=>100,
               'icon'   =>'wpstream_vc_logo',
               'description'=>esc_html__('Featured Article Shortcode','wpstream-wordpresstheme'),
               "params" => array(
                    array(
                     "type" => "autocomplete",
                     "holder" => "div",
                     "class" => "",
                     "heading" => esc_html__("Type article name","wpstream-wordpresstheme"),
                     "param_name" => "id",
                     "value" => "",
                     "description" => esc_html__("Select one article","wpstream-wordpresstheme"),
					 'settings' => array(
						'multiple' => false,
						'sortable' => true,
						'min_length' => 1,
						'no_hide' => true, 
						'groups' => false, 
						'unique_values' => true, 
						'display_inline' => true, 
						'values' => $article_array,
						  
					),
                  ),
                   

                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Design Type","wpstream-wordpresstheme"),
                        "param_name" => "design_type",
                        "value" =>  $featured_art_type,
                        "description" => esc_html__("type 1 or 2","wpstream-wordpresstheme")
                  )    
               )
            )
            );

            
            
            
            
            
            vc_map( array(
                "name" => esc_html__("List items by ID","wpstream-wordpresstheme"),//done
                "base" => "list_items_by_id",
                "class" => "",
                "category" => esc_html__('Content','wpstream-wordpresstheme'),
                'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
                'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
                'weight'=>100,
                'icon'   =>'wpstream_vc_logo',
                'description'=>esc_html__('List Items by ID Shortcode','wpstream-wordpresstheme'),
                "params" => array(
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Title","wpstream-wordpresstheme"),
                        "param_name" => "title",
                        "value" => "",
                        "description" => esc_html__("Section Title","wpstream-wordpresstheme")
                      ),
                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("What type of items","wpstream-wordpresstheme"),
                        "param_name" => "type",
                        "value" => $items_type,
                        "description" => esc_html__("List products,free products or articles","wpstream-wordpresstheme")
                    ),
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Items IDs","wpstream-wordpresstheme"),
                        "param_name" => "ids",
                        "value" => "",
                        "description" => esc_html__("List of IDs separated by comma","wpstream-wordpresstheme")
                   ),
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("No of items","wpstream-wordpresstheme"),
                        "param_name" => "number",
                        "value" => "3",
                        "description" => esc_html__("How many items do you want to show ?","wpstream-wordpresstheme")
                    ) ,

                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("No of items per row","wpstream-wordpresstheme"),
                        "param_name" => "rownumber",
                        "value" => 4,
                        "description" => esc_html__("The number of items per row","wpstream-wordpresstheme")
                    ) , 
                  
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Link to global listing","wpstream-wordpresstheme"),
                        "param_name" => "link",
                        "value" => "#",
                        "description" => esc_html__("link to global listing with http","wpstream-wordpresstheme")
                  )
               )
            ) );    

			
            vc_map( array(
                "name" => esc_html__( "Category Slider","wpstream-wordpresstheme"),//done
                "base" => "categories_slider",
                "class" => "",
                "category" => esc_html__( 'Content','wpstream-wordpresstheme'),
                'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
                'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
                'weight'=>100,
                'icon'   =>'wpstream_vc_logo',
                'description'=>esc_html__( 'Category Slider','wpstream-wordpresstheme'),  
                "params" => array(
				             
                    array(
                        "type" => "autocomplete",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__( "Type Categories,Movie Categories,Actors or Ratings you want to show","wpstream-wordpresstheme"),
                        "param_name" => "place_list",
                        "value" => "",
                        "description" => esc_html__( "Type Categories,Movie Categories,Actors or Ratings  you want to show","wpstream-wordpresstheme"),
                        'settings' => array(
                            'multiple' => true,
                            'sortable' => true,
                            'min_length' => 1,
                            'no_hide' => true, // In UI after select doesn't hide an select list
                            'groups' => false, // In UI show results grouped by groups
                            'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                            'display_inline' => true, // In UI show results inline view
                            'values' => $all_tax,
                      
                        )  ,
                    )  ,
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__( "Items per row","wpstream-wordpresstheme"),
                        "param_name" => "place_per_row",
                        "value" => "3",
                        "description" => esc_html__( "How many items listed per row?","wpstream-wordpresstheme")
                    ),
	 

                )    
            ) 
            );
            
            
            $list_cities_or_areas=array(1,2);
            vc_map( array(
                "name" => esc_html__( "Display Categories","wpstream-wordpresstheme"),//done
                "base" => "category_list",
                "class" => "",
                "category" => esc_html__( 'Content','wpstream-wordpresstheme'),
                'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
                'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
                'weight'=>100,
                'icon'   =>'wpstream_vc_logo',
                'description'=>esc_html__( 'Display Categories','wpstream-wordpresstheme'),  
                "params" => array(
                    array(
                        "type" => "autocomplete",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__( "Type Categories,Movie Categories,Actors or Ratings  you want to show","wpstream-wordpresstheme"),
                        "param_name" => "place_list",
                        "value" => "",
                        "description" => esc_html__( "Type Categories,Movie Categories,Actors or Ratings  you want to show","wpstream-wordpresstheme"),
                        'settings' => array(
                            'multiple' => true,
                            'sortable' => true,
                            'min_length' => 1,
                            'no_hide' => true, // In UI after select doesn't hide an select list
                            'groups' => false, // In UI show results grouped by groups
                            'unique_values' => true, // In UI show results except selected. NB! You should manually check values in backend
                            'display_inline' => true, // In UI show results inline view
                            'values' => $all_tax,
                      
                        )  ,
                    )  ,
                    array(
                            "type" => "textfield",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Status Text Label","wpstream-wordpresstheme"),
                            "param_name" => "status",
                            "value" => "",
                            "description" => esc_html__("Status Text Label","wpstream-wordpresstheme")
                    ),
                    array(
                        "type" => "dropdown",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__( "Type","wpstream-wordpresstheme"),
                        "param_name" => "place_type",
                        "value" => $list_cities_or_areas,
                        "description" => esc_html__( "Select Item Type 1/2?","wpstream-wordpresstheme")
                    ),
                    
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => esc_html__("Height in px","wpstream-wordpresstheme"),
                        "param_name" => "featured_unit_hight",
                        "value" => "",
                        "description" => esc_html__("Numeric field. Works only for Design type 1.","wpstream-wordpresstheme")
                    ),

                   
                )    
            ) 
            );   
            
            
            
            
            
            
            
            
            
            
            
            

            
            
          
            



            vc_map(array(
               "name" => esc_html__("Login Form","wpstream-wordpresstheme"),
               "base" => "login_form",
               "class" => "",
               "category" => esc_html__('Content','wpstream-wordpresstheme'),
               'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
               'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
               'weight'=>100,
               'icon'   =>'wpstream_vc_logo',
               'description'=>esc_html__('Login Form Shortcode','wpstream-wordpresstheme'),  
               "params" => array( array(
                     "type" => "textfield",
                     "holder" => "div",
                     "class" => "",
                     "heading" => esc_html__("Register link text","wpstream-wordpresstheme"),
                     "param_name" => "register_label",
                     "value" => "",
                     "description" => esc_html__("Register link text","wpstream-wordpresstheme")
                    )     , 
                    array(
                     "type" => "textfield",
                     "holder" => "div",
                     "class" => "",
                     "heading" => esc_html__("Register page url","wpstream-wordpresstheme"),
                     "param_name" => "register_url",
                     "value" => "",
                     "description" => esc_html__("Register page url","wpstream-wordpresstheme")
                  )      )
            )
            );


            vc_map(
             array(
               "name" => esc_html__("Register Form","wpstream-wordpresstheme"),
               "base" => "register_form",
               "class" => "",
               "category" => esc_html__('Content','wpstream-wordpresstheme'),
               'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
               'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
               'weight'=>100,
               'icon'   =>'wpstream_vc_logo',
               'description'=>esc_html__('Register Form Shortcode','wpstream-wordpresstheme'),    
               "params" => array()
            )

            );
            
            $featured_pack_sh=array('no','yes');
              vc_map(
                   array(
                   "name" => esc_html__("Membership Package","wpstream-wordpresstheme"),
                   "base" => "membership_packages",
				   
                   "class" => "",
                   "category" => esc_html__('Content','wpstream-wordpresstheme'),
                    'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
                    'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
                   'weight'=>102,
                   'icon'   =>'wpestate_vc_logo',
                   'description'=>esc_html__('Membership Package','wpstream-wordpresstheme'),
                   "params" => array(
                       array(
                            "type" => "autocomplete",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Type Package name","wpstream-wordpresstheme"),
                            "param_name" => 'package_id',
                            "value" => "",
                            "description" => esc_html__("Select only one Package","wpstream-wordpresstheme"),
							'settings' => array(
								'multiple' => false,
								'sortable' => true,
								'min_length' => 1,
								'no_hide' => true, 
								'groups' => false, 
								'unique_values' => true, 
								'display_inline' => true, 
								'values' => $membership_packages,
						  
							)  ,
                           ),
						   
                        array(
                            "type" => "textfield",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Content of the package box","wpstream-wordpresstheme"),
                            "param_name" => "package_content",
                            "value" => "",
                            "description" => esc_html__("Add content for the package","wpstream-wordpresstheme")
                       ),
                       array(
                            "type" => "dropdown",
                            "holder" => "div",
                            "class" => "",
                            "heading" => esc_html__("Make package featured","wpstream-wordpresstheme"),
                            "param_name" => "pack_featured_sh",
                            "value" => $featured_pack_sh,
                            "description" => esc_html__("Make package featured (no/yes)","wpstream-wordpresstheme")
                        ),
                   )
                )   
            );
              

//

			
			
        }
    endif;    
    
endif;
    
    



?>