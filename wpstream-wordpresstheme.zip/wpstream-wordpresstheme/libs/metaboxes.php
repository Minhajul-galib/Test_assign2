<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

add_action('add_meta_boxes',    'wpstream_sidebar_meta');
add_action('save_post',         'wpstream_save_postdata', 1, 2);


if( !function_exists('wpstream_sidebar_meta') ):
    function wpstream_sidebar_meta() {
        global $post;
        add_meta_box('wpstream-sidebar-post',       esc_html__( 'Page Settings',  'wpstream-wordpresstheme'), 'wpstream_sidebar_box', 'post');
        add_meta_box('wpstream-sidebar-page',       esc_html__( 'Page Settings',  'wpstream-wordpresstheme'), 'wpstream_sidebar_box', 'page');
        add_meta_box('wpstream-sidebar-product',    esc_html__( 'Page Settings',  'wpstream-wordpresstheme'), 'wpstream_sidebar_box', 'wpstream_product');
        add_meta_box('wpstream-sidebar-page',       esc_html__( 'Page Settings',  'wpstream-wordpresstheme'), 'wpstream_sidebar_box', 'product');
    
    
        add_meta_box('wpestate-header',             esc_html__('Appearance Options','wpstream-wordpresstheme'), 'wpstream_header_function', 'page', 'normal', 'low');
        add_meta_box('wpestate-header',             esc_html__('Appearance Options','wpstream-wordpresstheme'), 'wpstream_header_function', 'post', 'normal', 'low');
        add_meta_box('wpestate-header',             esc_html__('Appearance Options','wpstream-wordpresstheme'), 'wpstream_header_function', 'wpstream_product', 'normal', 'low');
        //add_meta_box('wpestate-header',             esc_html__('Appearance Options','wpstream_product'), 'wpstream_header_function', 'product', 'normal', 'low');
        
        add_meta_box('wpestate-heade-previewr',             esc_html__('Video Preview','wpstream-wordpresstheme'), 'wpstream_video_preview_function', 'product', 'normal', 'low');
        add_meta_box('wpestate-heade-previewr',             esc_html__('Video Preview','wpstream-wordpresstheme'), 'wpstream_video_preview_function', 'wpstream_product', 'normal', 'low');
   
    }
endif; 


function wpstream_video_preview_function(){
    global $post;
    
    $page_custom_video                  =   get_post_meta($post->ID, 'item_video_preview', true);
    $item_image_preview                 =   get_post_meta($post->ID, 'item_image_preview', true);
    $item_poster_preview                =   get_post_meta($post->ID, 'item_poster_preview', true);
        
    $cache_array                =   array('global','no','yes');
    $header_transparent         =   get_post_meta ( $post->ID, 'header_transparent', true);
    $header_transparent_select  =   '';
    
    foreach($cache_array as $key=>$value){
       $header_transparent_select.='<option value="'.$value.'" ';
       if($value==$header_transparent){
           $header_transparent_select.=' selected="selected" ';
       }
       $header_transparent_select.='>'.$value.'</option>'; 
    }
    
    print ' 
    <div class="header_admin_options2 ">
        <p class="meta-options pblank">
            <h3 class="pblankh">'.esc_html__('Product page Header Settings','wpstream-wordpresstheme').'</h3>
        </p>
      
        <p class="meta-options ">
         <label for="header_transparent">'.esc_html__('Use transparent header','wpstream-wordpresstheme').'</label><br />
            <select name="header_transparent">
            '.$header_transparent_select.'
            </select>
        </p>

        <p class="meta-options ">
            <label for="page_custom_image">'.esc_html__('Preview Video','wpstream-wordpresstheme').'</label><br />
            <input id="item_video_preview" type="text" size="36" name="item_video_preview" value="'.$page_custom_video.'" />
            <input id="item_video_preview_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Video','wpstream-wordpresstheme').'" />
        </p>
        

        <p class="meta-options ">
            <label for="page_custom_image">'.esc_html__('Media Logo - will be placed over trailer(recommended size 400x300px)','wpstream-wordpresstheme').'</label><br />
            <input id="item_image_preview" type="text" size="36" name="item_image_preview" value="'.$item_image_preview.'" />
            <input id="item_image_preview_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Image','wpstream-wordpresstheme').'" />
        </p>
        

        
        <p class="meta-options ">
            <label for="page_custom_image">'.esc_html__('Movie Poster(*use a big image) - will be shown after the trailer ends and on theme slider.','wpstream-wordpresstheme').'</label><br />
            <input id="item_poster_preview" type="text" size="36" name="item_poster_preview" value="'.$item_poster_preview.'" />
            <input id="item_poster_preview_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Image','wpstream-wordpresstheme').'" />
        </p>
    </div>';
    
}









if( !function_exists('wpstream_header_function') ):
function wpstream_header_function(){
    global $post;
    
  
    
    
    
    
    
    
    $header_array   =   array(
                            0   =>  'global',
                            1   =>  'none',
                            2   =>  'Image',
                            3   =>  'Revolution Slider',
                            4   =>  'Theme slider',
                            5   =>  'Video',
                            11  =>  'Simple Title'
                          );
    
    $header_type    =   get_post_meta ( $post->ID, 'media_header_type', true);
    $header_select  =   '';
 
    
    
    foreach($header_array as $key=>$value){
       $header_select.='<option value="'.$key.'" ';
       if($key==$header_type){
           $header_select.=' selected="selected" ';
       }
       $header_select.='>'.$value.'</option>'; 
    }
    ////////// search form
    $cache_array                        =   array('global','no','yes');
    $use_float_search_form_local_select =   '';
    $search_float_type                  =   get_post_meta ( $post->ID, 'use_float_search_form_local_set', true);
    foreach($cache_array as $key=>$value){
       $use_float_search_form_local_select.='<option value="'.$key.'" ';
       if($key==$search_float_type){
           $use_float_search_form_local_select.=' selected="selected" ';
       }
       $use_float_search_form_local_select.='>'.$value.'</option>'; 
    }
    
    
    ////////// end logo header
    $cache_array                =   array('global','no','yes');
    $header_transparent         =   get_post_meta ( $post->ID, 'header_transparent', true);
    $header_transparent_select  =   '';
    
    foreach($cache_array as $key=>$value){
       $header_transparent_select.='<option value="'.$value.'" ';
       if($value==$header_transparent){
           $header_transparent_select.=' selected="selected" ';
       }
       $header_transparent_select.='>'.$value.'</option>'; 
    }
  
    
    print'
    <h3 class="pblankh">'.esc_html__('Use transparent header','wpstream-wordpresstheme').'</h3>
    <select name="header_transparent">
        '.$header_transparent_select.'
    </select>';
    
    $cache_array_rev=array('global','yes','no');
   
    
    print'
    <h3 class="pblankh">'.esc_html__('Select header type','wpstream-wordpresstheme').'</h3>
    <select id="page_header_type" name="media_header_type">
        '.$header_select.'
    </select>';
    
    wpstream_blog_post_video_box($post);
    wpstream_page_map_box($post);
    wpstream_page_slider_box($post);
    wpstream_page_video_box($post);
 
    }
    
endif;


if( !function_exists('wpstream_page_map_box') ): 
function wpstream_page_map_box($post) {
    global $post;
          

      $page_custom_image  = get_post_meta($post->ID, 'page_custom_image', true);
    
    $cache_array        =   array('yes','no');
    $cache_array_rev    =   array('no','yes');
    $cache_array_fix    =   array('cover','contain');
    $img_full_screen                    = wpwpstream_dropdowns_theme_admin_option_core($post->ID,$cache_array_rev,'page_header_image_full_screen');
    $img_full_back_type                 = wpwpstream_dropdowns_theme_admin_option_core($post->ID,$cache_array_fix,'page_header_image_back_type');   
    $page_header_title_over_image       = stripslashes ( esc_html ( get_post_meta($post->ID, 'page_header_title_over_image', true) ) );
    $page_header_subtitle_over_image    = stripslashes ( esc_html ( get_post_meta($post->ID, 'page_header_subtitle_over_image', true) ) );
    $page_header_image_height           = esc_html ( get_post_meta($post->ID, 'page_header_image_height', true) );
    $page_header_overlay_val            = esc_html ( get_post_meta($post->ID, 'page_header_overlay_val', true) );
    $page_header_overlay_color          = esc_html ( get_post_meta($post->ID, 'page_header_overlay_color', true) );
    
    print '   
        <div class="header_admin_options image_header">
        <p class="meta-options pblank">
            <h3 class="pblankh">'.esc_html__('Options for Static Image  (if Header Type "image" is selected)','wpstream-wordpresstheme').'</h3>
        </p>
     
        <p class="meta-options ">
            <label for="page_custom_image">'.esc_html__('Header Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_custom_image" type="text" size="36" name="page_custom_image" value="'.$page_custom_image.'" />
            <input id="page_custom_image_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Image','wpstream-wordpresstheme').'" />
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_image_full_screen">'.esc_html__('Full Screen?','wpstream-wordpresstheme').'</label><br />
            <select id="page_header_image_full_screen" name="page_header_image_full_screen">
                '.$img_full_screen.'
            </select>
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_image_full_screen">'.esc_html__('Full Screen Background Type?','wpstream-wordpresstheme').'</label><br />
            <select id="page_header_image_back_type" name="page_header_image_back_type">
                '.$img_full_back_type.'
            </select>
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_title_over_image">'.esc_html__('Title Over Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_title_over_image" type="text" size="36" name="page_header_title_over_image" value="'.$page_header_title_over_image.'" />
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_subtitle_over_image">'.esc_html__('SubTitle Over Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_subtitle_over_image" type="text" size="36" name="page_header_subtitle_over_image" value="'.$page_header_subtitle_over_image.'" />
        </p>

        <p class="meta-options third-meta-options">
            <label for="page_header_image_height">'.esc_html__('Image Height(Ex:700, Default:580px)','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_image_height" type="text" size="36" name="page_header_image_height" value="'.$page_header_image_height.'" />
        </p>    

        <div class="meta-options third-meta-options">
            <label for="page_header_overlay_color">'.esc_html__('Overlay Color','wpstream-wordpresstheme').'</label><br />
          
            <div id="page_header_overlay_color" class="colorpickerHolder"><div class="sqcolor" style="background-color:#'.$page_header_overlay_color.';"  ></div></div>  <input type="text" name="page_header_overlay_color" maxlength="7" class="inptxt " value="'.$page_header_overlay_color.'"/>
        </div>

        <p class="meta-options third-meta-options">
            <label for="page_header_overlay_val">'.esc_html__('Overlay Opacity(betwen 0 and 1 , Ex:0.5, default 0.6)','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_overlay_val" type="text" size="36" name="page_header_overlay_val" value="'.$page_header_overlay_val.'" />
        </p>


        <p class="meta-options pblank">
        </p></div>';
}
endif; // end   wpstream_page_map_box 



















if( !function_exists('wpstream_page_slider_box') ):
function wpstream_page_slider_box($post) {
    global $post;
    $rev_slider           = get_post_meta($post->ID, 'rev_slider', true);
    print ' 
    <div class="header_admin_options revolution_slider">
        <p class="meta-options pblank">
            <h3 class="pblankh">'.esc_html__('Options for Revolution Slider (if Header Type "revolution slider" is selected)','wpstream-wordpresstheme').'</h3>
        </p>
        <p class="meta-options">	
            <label for="page_custom_lat">'.esc_html__('Revolution Slider Name','wpstream-wordpresstheme').'</label><br />
            <input type="text" id="rev_slider" name="rev_slider" size="40" value="'.$rev_slider.'">
        </p>
    </div>
    ';
}
endif; // end   wpstream_page_slider_box  





if( !function_exists('wpstream_blog_post_video_box') ):
function wpstream_blog_post_video_box($post) {
    $post_local_video               =   get_post_meta($post->ID, 'post_local_video', true);
    $post_external_video            =   get_post_meta($post->ID, 'post_external_video', true);
    $post_external_video_id         =   get_post_meta($post->ID, 'post_external_video_id', true);
    $external_video_options         =   array('vimeo'=>'vimeo',
                                                'youtube'=>'youtube');
            
    if( isset($post->ID) && get_post_type($post->ID)=='post' ){
        print '<div class="">
            <p class="meta-options pblank">
                <h3 class="pblankh">'.esc_html__('Video for post','wpstream-wordpresstheme').'</h3>
            </p>

            <p class="meta-options ">
                <label for="post_local_video">'.esc_html__('Local Video','wpstream-wordpresstheme').'</label><br />
                <input id="post_local_video" type="text" size="36" name="post_local_video" value="'.$post_local_video.'" />
                <input id="post_local_video_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Video','wpstream-wordpresstheme').'" />
            </p>
            <p class="meta-options ">or</p>
             
            <p class="meta-options ">
                <label for="post_external_video">'.esc_html__('External Video','wpstream-wordpresstheme').'</label><br />
                <select id="post_external_video" name="post_external_video"  />';
                foreach($external_video_options as $key=>$value){
                    
                    print '<option value="'.$key.'"'; 
                        if($key==$post_external_video){
                            print ' selected ';
                        }
                    print'>'.$value.'</option>';
                }
        
                print'</select>
             
            </p>
            
            <p class="meta-options ">
                <label for="post_external_video_id">'.esc_html__('External Video Id','wpstream-wordpresstheme').'</label><br />
                <input id="post_external_video_id" type="text" size="36" name="post_external_video_id" value="'.$post_external_video_id.'" />
            </p>
             
        </div>';
      
    }else{
      
        return;
    }
    
    
}
endif;




if( !function_exists('wpstream_page_video_box') ):
function wpstream_page_video_box($post) {
    global $post;
    //page_custom_video


    $cache_array                        =   array('yes','no');
    $cache_array_reverse                =   array('no','yes');
    $cache_array_fix                    =   array('screen','auto');
    $page_custom_video                  =   get_post_meta($post->ID, 'page_custom_video', true);
    $page_custom_video_webbm            =   get_post_meta($post->ID, 'page_custom_video_webbm', true);
    $page_custom_video_ogv              =   get_post_meta($post->ID, 'page_custom_video_ogv', true);
    $page_custom_video_cover_image      =   get_post_meta($post->ID, 'page_custom_video_cover_image', true);
    $img_full_screen                    =   wpwpstream_dropdowns_theme_admin_option_core($post->ID,$cache_array_reverse,'page_header_video_full_screen');
    $page_header_title_over_video       =   stripslashes ( esc_html ( get_post_meta($post->ID, 'page_header_title_over_video', true) ) );
    $page_header_subtitle_over_video    =   stripslashes ( esc_html ( get_post_meta($post->ID, 'page_header_subtitle_over_video', true) ) );
    $page_header_video_height           =   esc_html ( get_post_meta($post->ID, 'page_header_video_height', true) );
    $page_header_overlay_color_video    =   esc_html ( get_post_meta($post->ID, 'page_header_overlay_color_video', true) );
    $page_header_overlay_val_video      =   esc_html ( get_post_meta($post->ID, 'page_header_overlay_val_video', true) );
    
    
    print ' 
    <div class="header_admin_options video_header">
        <p class="meta-options pblank">
            <h3 class="pblankh">'.esc_html__('Options for Video Header','wpstream-wordpresstheme').'</h3>
        </p>
      
 
   
        <p class="meta-options ">
            <label for="page_custom_image">'.esc_html__('Video MP4 version','wpstream-wordpresstheme').'</label><br />
            <input id="page_custom_video" type="text" size="36" name="page_custom_video" value="'.$page_custom_video.'" />
            <input id="page_custom_video_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Video','wpstream-wordpresstheme').'" />
        </p>
        
        
        
        <p class="meta-options ">
            <label for="page_custom_video_cover_image">'.esc_html__('Cover Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_custom_video_cover_image" type="text" size="36" name="page_custom_video_cover_image" value="'.$page_custom_video_cover_image.'" />
            <input id="page_custom_video_cover_image_button" type="button"   size="40" class="upload_button button" value="'.esc_html__('Upload Image','wpstream-wordpresstheme').'" />
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_video_full_screen">'.esc_html__('Full Screen?','wpstream-wordpresstheme').'</label><br />
            <select id="page_header_video_full_screen" name="page_header_video_full_screen">
                '.$img_full_screen.'
            </select>
        </p>
        
       
        
        <p class="meta-options third-meta-options">
            <label for="page_header_title_over_video">'.esc_html__('Title Over Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_title_over_video" type="text" size="36" name="page_header_title_over_video" value="'.$page_header_title_over_video.'" />
        </p>
        
        <p class="meta-options third-meta-options">
            <label for="page_header_subtitle_over_video">'.esc_html__('SubTitle Over Image','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_subtitle_over_video" type="text" size="36" name="page_header_subtitle_over_video" value="'.$page_header_subtitle_over_video.'" />
        </p>

        <p class="meta-options third-meta-options">
            <label for="page_header_video_height">'.esc_html__('Video Height(Ex:700, Default:580px)','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_video_height" type="text" size="36" name="page_header_video_height" value="'.$page_header_video_height.'" />
        </p>    

        <div class="meta-options third-meta-options">
            <label for="page_header_overlay_color_video">'.esc_html__('Overlay Color','wpstream-wordpresstheme').'</label><br />
          
            <div id="page_header_overlay_color_video" class="colorpickerHolder"><div class="sqcolor" style="background-color:#'.$page_header_overlay_color_video.';"  ></div></div>  <input type="text" name="page_header_overlay_color_video" maxlength="7" class="inptxt " value="'.$page_header_overlay_color_video.'"/>
        </div>

        <p class="meta-options third-meta-options">
            <label for="page_header_overlay_val_video">'.esc_html__('Overlay Opacity(betwen 0 and 1 , Ex:0.5, default 0.6)','wpstream-wordpresstheme').'</label><br />
            <input id="page_header_overlay_val_video" type="text" size="36" name="page_header_overlay_val_video" value="'.$page_header_overlay_val_video.'" />
        </p>


        <p class="meta-options pblank">
        </p></div>';
   
}
endif; // end   wpstream_page_slider_box  


if( !function_exists('wpstream_sidebar_box') ):
    function wpstream_sidebar_box($post) {
        // Use nonce for verification
        wp_nonce_field(plugin_basename(__FILE__), 'wpwpstream_sidebar_noncename');
        global $post;
        global $wp_registered_sidebars ;
        
        
        $sidebar_name   = get_post_meta($post->ID, 'sidebar_select', true);
        $sidebar_option = get_post_meta($post->ID, 'page_layout', true);

        $sidebar_values = array(   
            0=>esc_html__( 'Select Option','wpstream-wordpresstheme'), 
            1=>esc_html__( 'Left Sidebar','wpstream-wordpresstheme'), 
            2=>esc_html__( 'Right Sidebar','wpstream-wordpresstheme'), 
            3=>esc_html__( 'Full Layout','wpstream-wordpresstheme'), 
            4=>esc_html__( 'Full Widht Layout','wpstream-wordpresstheme'), 
        );

        // page laypout 
        $option         = '';
        foreach ($sidebar_values as $key=>$value) {
            $option.='<option value="' . $key . '"';
            if ($key == $sidebar_option) {
                $option.=' selected="selected"';
            }
            $option.='>' . $value . '</option>';
        }

        print '   
        <p class="meta-options"><label for="sidebar_option">'.esc_html__( 'Page Layout: ','wpstream-wordpresstheme').' </label><br />
            <select id="page_layout" name="page_layout" style="width: 200px;">
            ' . $option . '
            </select>
        </p>';


        
        
        // sidebar 
        print'
        <p class="meta-options"><label for="sidebar_select">'.esc_html__( 'Select the sidebar: ','wpstream-wordpresstheme').'</label><br />                  
            <select name="sidebar_select" id="sidebar_select" style="width: 200px;">';
            foreach ($GLOBALS['wp_registered_sidebars'] as $sidebar) {
                print'<option value="' . ($sidebar['id'] ) . '"';
                if ($sidebar_name == $sidebar['id']) {
                    print' selected="selected"';
                }
                print' >' . ucwords($sidebar['name']) . '</option>';
            }
            print '
            </select>
        </p>';
            
           
            
            
            
            
         // show title   
        if(get_post_type($post->ID)!='product'){
            
            $option = '';
            $title_values = array('yes', 'no');
            $post_title = get_post_meta($post->ID, 'post_show_title', true);
            foreach ($title_values as $value) {
                $option.='<option value="' . $value . '"';
                if ($value == $post_title) {
                    $option.='selected="selected"';
                }
                $option.='>' . $value . '</option>';
            }

            print   '<p class="meta-options">	
                    <label for="post_show_title">'.esc_html__( 'Show Title:','wpstream-wordpresstheme').' </label><br />
                    <select id="post_show_title" name="post_show_title" style="width: 200px;">
                            ' . $option . '
                    </select><br />
                </p>';
        }
            
            
            
    }
endif; // end   wpstream_sidebar_box  




if( !function_exists('wpstream_save_postdata') ):
function wpstream_save_postdata($post_id) {
    global $post;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }
    
    ///////////////////////////////////// Check permissions   
    if(isset($_POST['post_type'])){       
        if ('page' == $_POST['post_type'] or 'post' == $_POST['post_type'] or 'wpstream_product' == $_POST['post_type'] or 'product' == $_POST['post_type']) {
            if (!current_user_can('edit_page', $post_id))
                return;
        }
        else {
            if (!current_user_can('edit_post', $post_id))
                return;
        }
    }
 
    $allowed_keys=array(
        'post_external_video_id',
        'post_external_video',
        'post_local_video',
        'item_poster_preview',
        'item_image_preview',
        'item_video_preview',
        'media_header_type',
        'page_layout',
        'sidebar_select',
        'post_show_title',
        'header_transparent',
        'header_type',
        'page_header_type',
        'page_custom_image',
        'page_header_image_full_screen',
        'page_header_image_back_type',
        'page_header_title_over_image',
        'page_header_subtitle_over_image',
        'page_header_image_height',
        'page_header_overlay_color',
        'page_header_overlay_va',
        'rev_slider',
        'page_custom_video',
        'page_custom_video_webbm',
        'page_custom_video_ogv',
        'page_custom_video_cover_image',
        'page_header_overlay_val_video',
        'page_header_overlay_color_video',
        'page_header_video_height',
        'page_header_subtitle_over_video',
        'page_header_video_full_screen',
        'page_header_title_over_video',
        'page_custom_video',
        'page_header_image_back_type',
        'page_header_title_over_image',
        'page_header_subtitle_over_image',
        'page_header_image_height',
        'page_header_overlay_val',
        'page_header_overlay_color',
        'page_header_image_full_screen',
        );
  
    foreach ($_POST as $key => $value) {
        if (in_array ($key, $allowed_keys)) {
            $postmeta = sanitize_text_field( $value ); 
            update_post_meta($post_id, sanitize_key($key), $postmeta );
        }
    }
 

}
endif; 


if( !function_exists('wpwpstream_dropdowns_theme_admin') ):
    function wpwpstream_dropdowns_theme_admin_option_core($post_id,$array_values,$option_name,$pre=''){
        
        $dropdown_return    =   '';
        $option_value       =   esc_html ( get_post_meta($post_id, $option_name, true) );
        foreach($array_values as $value){
            $dropdown_return.='<option value="'.$value.'"';
              if ( $option_value == $value ){
                $dropdown_return.='selected="selected"';
            }
            $dropdown_return.='>'.$pre.$value.'</option>';
        }
        
        return $dropdown_return;
        
    }
endif;
