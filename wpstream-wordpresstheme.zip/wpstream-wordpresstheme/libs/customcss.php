<?php
global $redux_builder_wpstream;

if(  wpstream_is_global_subscription() ){
    print '.woocommerce-Price-amount,.subscription-details,.single_add_to_cart_button {display:none;}';
 
}
/*---------------------------
 #Header title Clor
---------------------------*/

if( wpstream_get_option('header_title_back_color') !='' ){
    print '.wpstream_title_header_wrapper{background-color:'.$redux_builder_wpstream['header_title_back_color'].';}';
}
if( wpstream_get_option('header_title_font_color') !='' ){
    print '.wpstream_title_header_wrapper h3{color:'.$redux_builder_wpstream['header_title_font_color'].';}';
}


/*---------------------------
 #Header Height
---------------------------*/

if( wpstream_get_option('header-height')  !=''){
    print '.site-header,.header_type_2 .site-header{height:'.$redux_builder_wpstream['header-height'].'px;}';
    print '.main-navigation a, .main-navigation .menu-item-has-children a:after{line-height:'.$redux_builder_wpstream['header-height'].'px;}';
    print '.transparent_header .header_media{
        min-height:'.$redux_builder_wpstream['header-height'].'px;
    }';
}

/*---------------------------
 #Sticky Header Height
---------------------------*/

if(  wpstream_get_option('sticky-header-height')  !=''){
    print '.site-header.master_header_sticky,.header_type_2 .site-header.master_header_sticky{height:'.$redux_builder_wpstream['sticky-header-height'].'px;}';
    print '.master_header_sticky .main-navigation a, .master_header_sticky .main-navigation .menu-item-has-children a:after{line-height:'.$redux_builder_wpstream['sticky-header-height'].'px;}';
}


/*---------------------------
 #Top Bar Background Color 
 ----------------------------*/

if( wpstream_get_option('top_bar_back') !=''){
    print '.top_bar_wrapper{background-color:'.$redux_builder_wpstream['top_bar_back'].';}';
}

/*---------------------------
 #Header Background Color 
 ----------------------------*/

if(  wpstream_get_option('header_color')   !=''){
    print '.site-header{background-color:'.$redux_builder_wpstream['header_color'].';}';
}

/*---------------------------
#Sticky Menu Background Color
---------------------------*/
if(  wpstream_get_option('sticky_header_color')   !=''){
    print '.transparent_header .master_header_sticky, .master_header_sticky{background:none;background-color:'.$redux_builder_wpstream['sticky_header_color'].';}';
}
    
/*---------------------------
 #Stiky menu font color
 ----------------------------*/

if(  wpstream_get_option('sticky_menu_font_color')   !=''){
    print '.master_header_sticky .main-navigation a,
      .master_header_sticky .wpstream_header_search_icon,
      .master_header_sticky .wpstream_header_shoping_cart_icon,
      .master_header_sticky .wpstream_header_user_menu_icon
      {color:'.$redux_builder_wpstream['sticky_menu_font_color'].'!important;}';
}

/*---------------------------
 #Top Menu Font Color
 ----------------------------*/

if( wpstream_get_option('menu_font_color') !=''){
    print '.main-navigation a,.wpstream_header_search_icon, .wpstream_header_shoping_cart_icon, .wpstream_header_user_menu_icon{color:'.$redux_builder_wpstream['menu_font_color'].';}';
}

/*---------------------------
 #Top Menu Hover Font Color
 ----------------------------*/

if(  wpstream_get_option('top_menu_hover_font_color') !=''){
    print '.main-navigation a:hover, 
           .main-navigation .sub-menu li a:hover,
           .wpstream_header_search_icon:hover, 
           .wpstream_header_shoping_cart_icon:hover, 
           .wpstream_header_user_menu_icon:hover{
                color:'.$redux_builder_wpstream['top_menu_hover_font_color'].';
            }';
}

/*---------------------------
 #Transparent Header - Top Menu Font Color
 ----------------------------*/

if($redux_builder_wpstream['transparent_menu_font_color']!=''){
    print ' .transparent_header .wpstream_header_search_icon, 
            .transparent_header .wpstream_header_shoping_cart_icon, 
            .transparent_header .wpstream_header_user_menu_icon,
            .transparent_header #primary-menu>li>a{
                color:'.$redux_builder_wpstream['transparent_menu_font_color'].';
            }';
}

/*---------------------------
 #Transparent Header - Top Menu Hover Color
 ----------------------------*/

if($redux_builder_wpstream['transparent_menu_hover_font_color']!=''){
    print '
        .transparent_header .wpstream_header_search_icon:hover, 
        .transparent_header .wpstream_header_shoping_cart_icon:hover, 
        .transparent_header .wpstream_header_user_menu_icon:hover,
        .transparent_header #primary-menu>li>a:hover{
                color:'.$redux_builder_wpstream['transparent_menu_hover_font_color'].'!important;
        }';
}


/*---------------------------
#Menu Item Color
* ----------------------------*/
 
if($redux_builder_wpstream['menu_items_color']!=''){
    print '.main-navigation .sub-menu li a{
                color:'.$redux_builder_wpstream['menu_items_color'].'!important;
            }';
}

/*---------------------------
#Menu Item hover font color
* ----------------------------*/

if($redux_builder_wpstream['menu_hover_font_color']!=''){
    print '.main-navigation .sub-menu li a:hover{
                color:'.$redux_builder_wpstream['menu_hover_font_color'].';
            }';
}

/*---------------------------
#Menu Item Back Color
----------------------------*/

if($redux_builder_wpstream['menu_item_back_color']!=''){
    print '.main-navigation ul .sub-menu{
                background-color:'.$redux_builder_wpstream['menu_item_back_color'].';
            }';
}

/*---------------------------
#Menu Item Hover Back Color
----------------------------*/

if($redux_builder_wpstream['menu_hover_back_color']!=''){
    print '.main-navigation .sub-menu li:hover{
                background-color:'.$redux_builder_wpstream['menu_hover_back_color'].';
            }';
}

/*---------------------------
#Menu Item Border Top Color
----------------------------*/

if($redux_builder_wpstream['menu_border_top_color']!=''){
    print '.main-navigation ul .sub-menu{
                    border-top: 2px solid '.$redux_builder_wpstream['menu_border_top_color'].';
            }
            .main-navigation ul .sub-menu:after {
                border-bottom: 7px solid '.$redux_builder_wpstream['menu_border_top_color'].';
            }';
}

/*---------------------------
#Top Bar Font Color
----------------------------*/

if($redux_builder_wpstream['top_bar_font']!=''){
    print '.top_bar a, 
           .top_bar p{
                color:'.$redux_builder_wpstream['top_bar_font'].';
            }';
}

/*-------------------------------------------
#Menu Font Family & Weight & Style & Size
-------------------------------------*/

if( !empty( $redux_builder_wpstream['typo-menu']) ){
    print '.main-navigation a{
                font-family:'.$redux_builder_wpstream['typo-menu']['font-family'].';
                font-weight:'.$redux_builder_wpstream['typo-menu']['font-weight'].';
                text-transform:'.$redux_builder_wpstream['typo-menu']['text-transform'].';
                font-size:'.$redux_builder_wpstream['typo-menu']['font-size'].';
            }';
    
}

/*---------------------------------------
#Menu  Items Font Family & Weight & Style & Size
-------------------------------------*/

if( !empty( $redux_builder_wpstream['typo-menu-items']) ){
    print '.main-navigation .sub-menu li a{
                font-family:'.$redux_builder_wpstream['typo-menu-items']['font-family'].';
                font-weight:'.$redux_builder_wpstream['typo-menu-items']['font-weight'].';
                text-transform:'.$redux_builder_wpstream['typo-menu-items']['text-transform'].';
                font-size:'.$redux_builder_wpstream['typo-menu-items']['font-size'].';
            }';
    
}

/*---------------------------------
#Content Width (In Percent)
-----------------------------------*/

if($redux_builder_wpstream['content_width']!=''){
    print '.content-area{
                width:'.$redux_builder_wpstream['content_width'].'%;
            }
            .widget-area {
                width: calc(100% - '.$redux_builder_wpstream['content_width'].'% );
            }';
}

/*--------------------------------
 #Footer Background Color
 ----------------------------------*/

if($redux_builder_wpstream['footer_background']!=''){
    print '.site-footer{
                background-color:'.$redux_builder_wpstream['footer_background'].';
            }';
}
/*--------------------------------
 #Footer Title Font Color
 ----------------------------------*

 */
if($redux_builder_wpstream['footer_widget_title_color']!=''){
    print '
        #colophon .widget-title-footer{
            color:'.$redux_builder_wpstream['footer_widget_title_color'].'!important;
        }';
}


/*--------------------------------
 #Footer Font Color
 ----------------------------------*/

if($redux_builder_wpstream['footer_font_color']!=''){
    print '
        #colophon .widget_recent_comments .recentcomments a,
        #colophon .widget_recent_comments li a:before,
        #colophon .product_list_widget .subscription-details,
        #colophon .product_list_widget .product-title,
        #colophon .product_list_widget .amount,
        #colophon .widget_recent_entries .recent_entries_date,
        .footer_widget-area li,
        .footer_widget-area li a,
        #colophon .widget_recent_entries .recent_entries_title{
            color:'.$redux_builder_wpstream['footer_font_color'].';
        }';
}


/*--------------------------------
 #Sub Footer Background Color
 ----------------------------------*/

if($redux_builder_wpstream['subfooter_background']!=''){
    print '.site-info{
                background-color:'.$redux_builder_wpstream['subfooter_background'].';
            }';
}

/*--------------------------------
 #Sub Footer Font Color
 ----------------------------------*/

if($redux_builder_wpstream['subfooter_copyright_font_color']!=''){
    print '.copyright,#colophon .menu li,.menu-footer-container a,.copyright a{
                color:'.$redux_builder_wpstream['subfooter_copyright_font_color'].';
            }';
}

/*--------------------------------
#Main Color
----------------------------------*/

if($redux_builder_wpstream['main_color']!=''){
    print ' 
            .theme_slider_wrapper.theme_slider_2 .featured_product_play:hover, .featured_product_play:hover,
            .star-rating span:before,
            .widget_search .search_form_but:hover,
            .post .entry-footer .tags-text,
            .comment_name,
            .blog_unit_second-row{
                color:'.$redux_builder_wpstream['main_color'].';
            }
            blockquote{
                border-left: 5px solid '.$redux_builder_wpstream['main_color'].';
            }
            .featured_product_play:hover{
                color:'.$redux_builder_wpstream['main_color'].'!important;
            }
            
            .wpstream_header_view_cart:hover,
            #reply-title:before, .comments-title:before, .product .related>h2:before, #wpstream_product_wrap_no_buy .related>h2:before, #wpstream_product_wrap .related>h2:before, .shortcode_title:before,
            #wpstream_product_wrap_no_buy .related>h2:before, #wpstream_product_wrap .related>h2:before, .shortcode_title:before,
            .featured_article_type3 .featured_article_details_wrapper:before ,         
            .widget-title:before,
            .woocommerce .button, .wpstream_header_view_cart, .wpstream_header_view_checkout, .wpstream_button, .featured_free_product.featured_free_product_type2 a.featured_button, .featured_article.featured_article_type2 a.featured_button, .featured_product.featured_product_type2 a.featured_button, .featured_product.featured_product_type1 a.featured_button, .theme_slider_button,
            blockquote:before,
            .widget_recent_entries .post-thumbnail_widget,
            .blog_unit-img,
            .wpstream_button,
            .wpstream_product_list .button,
            .wpstream_product_list .onsale,
            .blog_social_share i:hover{
                background-color: '.$redux_builder_wpstream['main_color'].';
            }
            #wrapper_author-info{
                border-left: 5px solid '.$redux_builder_wpstream['main_color'].';
            }
            .main-navigation .sub-menu li a:hover{
                border-bottom-color: '.$redux_builder_wpstream['main_color'].';
            }
            .woocommerce-tabs ul.tabs li.active {
                border-top: 3px solid '.$redux_builder_wpstream['main_color'].';
            }
            .wpstream_button_effect{
                border-color: '.$redux_builder_wpstream['main_color'].';
            }
    ';
}

/*-------------------------
 #Background Color
 -------------------------*/


if($redux_builder_wpstream['background_color']!=''){
    print '
        body{
            background-color: '.$redux_builder_wpstream['background_color'].';
        }
    ';
}

/*-------------------------
 #Product page tab backgorund color
 -------------------------*/

if($redux_builder_wpstream['product_page_background_color']!=''){
    print '
        .woocommerce-Tabs-panel,
        .woocommerce-tabs ul.tabs{
            background-color: '.$redux_builder_wpstream['product_page_background_color'].';
        }
    ';
}

/*-------------------------
 #Product page tab font color
 -------------------------*/

if($redux_builder_wpstream['product_page_font_color']!=''){
    print '
        #reply-title, 
        .comments-title,
        .woocommerce-Tabs-panel,
        p.stars a:before{
            color: '.$redux_builder_wpstream['product_page_font_color'].';
        }
        
        .woocommerce-tabs ul.tabs{
            border-top: 1px solid  '.$redux_builder_wpstream['product_page_font_color'].';
        }
    ';
}

/*-------------------------
 #Product page selected tab Back color
 -------------------------*/


if($redux_builder_wpstream['product_page_selected_tab_back_color']!=''){
    print '
        .woocommerce-tabs ul.tabs li.active{
            background-color: '.$redux_builder_wpstream['product_page_selected_tab_back_color'].';
        }
        
       
    ';
}

/*-------------------------
 #Product page selected tab Font color
 -------------------------*/


if($redux_builder_wpstream['product_page_selected_tab_font_color']!=''){
    print '
        .woocommerce-tabs ul.tabs li.active a{
            color: '.$redux_builder_wpstream['product_page_selected_tab_font_color'].';
        }
        
       
    ';
}



/*-------------------------
#Breadcrumbs, Meta and Second Line Font Color
-------------------------*/

if($redux_builder_wpstream['meta_font_color']!=''){
    print '  .post .entry-meta a,
            .woocommerce-breadcrumb,
            .woocommerce-breadcrumb a,
            .post .byline, 
            .post .posted-on, 
            .post .post_comments,
            .post .cat-links,
            #secondary .recent_entries_date{
                color: '.$redux_builder_wpstream['meta_font_color'].';
            }
    ';
}

/*-----------------------
#Font Color
--------------------------*/

if($redux_builder_wpstream['font_color']!=''){
    //#secondary .widget_recent_entries li p,
    print 'body,
            .woocommerce-cart .cart_item .product-name a,
            .wpstream_custom_info_field_title,
            .blog-unit-excerpt,
           .post p,
            p{
                color: '.$redux_builder_wpstream['font_color'].';
            }
        .cart_totals h2{
            color: '.$redux_builder_wpstream['font_color'].'!important;
        }
    ';
}

/*-----------------------
#Link Color
--------------------------*/

if($redux_builder_wpstream['link_color']!=''){
    print '
            a,
            .post .tags-links a:hover,
            a:hover, 
            a:focus,
            a:active,
            .widget_categories a:hover, 
            .widget_archive li a:hover,
            .widget_recent_comments .recentcomments a,
            .blog_unit_button .read_more,
            .blog_unit-title a:hover{
                color: '.$redux_builder_wpstream['link_color'].';
            }
            
            .blog_unit_button:before,
            #colophon .tagcloud a:hover, 
            .tagcloud a:hover{
                background: '.$redux_builder_wpstream['link_color'].';
            }
            
            
    ';
}

/*-----------------------
#Headings Color
--------------------------*/

if($redux_builder_wpstream['heading_color']!=''){
    print '.widget-title,
            .blog_unit-title a,
            h1, h2, h3, h4, h5, h6{
                color: '.$redux_builder_wpstream['heading_color'].'!important;
            }
    ';
}


/*-----------------------
#Hover Button Color
--------------------------*/
if($redux_builder_wpstream['default_button_color']!=''){
    print '
        .featured_product_category_wrapper a,
        .blog_unit-img span,
        button, input[type="button"], input[type="reset"], input[type="submit"],
        .categories_slider_type_1_listings_no,
        button,
        input[type="button"],
        input[type="reset"],
        input[type="submit"],
        .wpstream_button,
        .woocommerce .button, 
        .wpstream_header_view_cart, 
        .wpstream_header_view_checkout, 
        .wpstream_button, 
        .featured_free_product.featured_free_product_type2 a.featured_button, 
        .featured_article.featured_article_type2 a.featured_button, 
        .featured_product.featured_product_type2 a.featured_button, 
        .featured_product.featured_product_type1 a.featured_button, 
        .theme_slider_button{
            background: '.$redux_builder_wpstream['default_button_color'].';
        }
        
        .wpstream_categories_slider button.slick-prev.slick-arrow:before,
        .wpstream_categories_slider button.slick-next.slick-arrow:before{
            color: '.$redux_builder_wpstream['default_button_color'].';
        
        }
    ';
}


if($redux_builder_wpstream['default_button_color_text']!=''){
     print '
         .blog_unit-img span a,
        .featured_product_category_wrapper a,
        .blog_unit-img span,
        button, input[type="button"], input[type="reset"], input[type="submit"],
        .categories_slider_type_1_listings_no,
        button,
        input[type="button"],
        input[type="reset"],
        input[type="submit"],
        .wpstream_button,
        .woocommerce .button, 
        .wpstream_header_view_cart, 
        .wpstream_header_view_checkout, 
        .wpstream_button, 
        .featured_free_product.featured_free_product_type2 a.featured_button, 
        .featured_article.featured_article_type2 a.featured_button, 
        .featured_product.featured_product_type2 a.featured_button, 
        .featured_product.featured_product_type1 a.featured_button, 
        .theme_slider_button{
            color: '.$redux_builder_wpstream['default_button_color_text'].';
        }';
}


if($redux_builder_wpstream['hover_button_color']!=''){
    print ' button:hover,
        input[type="button"]:hover,
        input[type="reset"]:hover,
        input[type="submit"]:hover,
        .wpstream_button:hover,
        .woocommerce .button:hover, 
        .wpstream_header_view_cart:hover, 
        .wpstream_header_view_checkout:hover, 
        .wpstream_button:hover, 
        .featured_free_product.featured_free_product_type2 a.featured_button:hover, 
        .featured_article.featured_article_type2 a.featured_button:hover, 
        .featured_product.featured_product_type2 a.featured_button:hover, 
        .featured_product.featured_product_type1 a.featured_button:hover, 
        .theme_slider_button:hover{
            background: '.$redux_builder_wpstream['hover_button_color'].'!important;
            opacity:0.9;
        }
            
    .wpstream_categories_slider button.slick-prev.slick-arrow:hover:before,
    .wpstream_categories_slider button.slick-next.slick-arrow:hover:before{
        color: '.$redux_builder_wpstream['hover_button_color'].';
        opacity:0.9;
    }
    
    .wpstream_categories_slider button.slick-next.slick-arrow:hover,
    .wpstream_categories_slider button.slick-prev.slick-arrow:hover{
        background:transparent!important;
    }
    
    ';
}

/*-----------------------
#Sidebar  Heading Color
--------------------------*/
if($redux_builder_wpstream['sidebar_heading_color']!=''){
    print '
        #secondary .widget-title{
              color: '.$redux_builder_wpstream['sidebar_heading_color'].'!important;
        }
    
    ';

}

/*-----------------------
#Sidebar  Font Color
--------------------------*/
if($redux_builder_wpstream['sidebar_font_color']!=''){
    print '
        #secondary,
        #secondary a,
        #secondary p,
        #secondary li,   
        #secondary li a,
        #secondary .recent_entries_title,
        #secondary .recent_entries_date,
        #secondary .widget_recent_comments li a:before,
        #secondary caption{
            color:'.$redux_builder_wpstream['sidebar_font_color'].'!important;
        }
    ';

}