<?php



if( !function_exists('wpstream_product_play_video') ):
function wpstream_product_play_video($post_id,$icon=''){
    $theid                  =   $post_id;
    $id_code                =   wpstream_generateRandomString_for_theme();
    $page_custom_video      =   get_post_meta($theid, 'item_video_preview', true);
    $theid                  .=  $id_code;
    $return_string          =   ''; 
     
    if($icon=='1'){
        $return_string.='<a href="#inline'.$theid.'" class="lity-hide-trigger play_slider_trailer wpstream_button_effect" data-lity>'.esc_html__('trailer','wpstream-wordpresstheme').'<i class="fa fa-play" aria-hidden="true"></i></a>';
    }else{
        $return_string.='<a href="#inline'.$theid.'" class="featured_product_play  wpstream_button_effect lity-hide-trigger" data-lity  data-player-code="'.$id_code.'"> <i class="fa fa-play" aria-hidden="true"></i> </a>';
    }
    
    $return_string.= '<div id="inline'.$theid.'" class="lity-hide"  class="lity-hide">
            <video  id="inline'.$theid.'video" class="litty_video" poster="" width="100%" height="100%" controls >
                <source src="'.$page_custom_video.'" type="video/mp4" />
            </video>
        </div>';
    
    return $return_string;
}
endif;






if( !function_exists('wpstream_post_play_video') ):
function wpstream_post_play_video($post_id){
    $return_string='';
    $post_local_video               =   get_post_meta($post_id, 'post_local_video', true);
    $post_external_video            =   get_post_meta($post_id, 'post_external_video', true);
    $post_external_video_id         =   get_post_meta($post_id, 'post_external_video_id', true);


    if($post_local_video!='' || $post_external_video_id!=''){
        $theid=$post_id;
        $id_code=wpstream_generateRandomString_for_theme();
        
        $theid.=$id_code;
        
        if($post_local_video!==''){
            $return_string.=    '<a href="#inline'.$theid.'" class="featured_product_play lity-hide-trigger" data-lity  data-player-code="'.$id_code.'"> <i class="fa fa-play" aria-hidden="true"></i> </a>';
            $return_string.=    '<div id="inline'.$theid.'" class="lity-hide" >
                                <video  id="inline'.$theid.'video"  class="litty_video" poster="" width="100%" height="100%" controls >
                                    <source src="'.$post_local_video.'" type="video/mp4" />
                                </video>
                            </div>';
        }
        else if($post_external_video_id){
            $link_external='';
            if($post_external_video=='vimeo'){
                $link_external='https://vimeo.com/'.$post_external_video_id;
            }else if($post_external_video=='youtube'){
                $link_external='https://www.youtube.com/watch?v='.$post_external_video_id; 
            }

            $return_string.= '<a href="'.$link_external.'" class="featured_product_play lity-hide-trigger" data-lity> <i class="fa fa-play" aria-hidden="true"></i> </a>';

        }   
        
    } 
    return $return_string;
}
endif;








function wpstream_get_transient($transient_name){
    
    $cache =  intval( wpstream_get_option('enable_cache')) ;
    
    if($cache==1){
        return get_transient( $transient_name );
    }else{
        return false;
    }
}



function wpstream_set_transient($transient_name,$transient_value,$expiration){
    
    $cache =  intval( wpstream_get_option('enable_cache')) ;
    if($cache==1){
         set_transient( $transient_name, $transient_value, $expiration);
    }
    
    
}



if( !function_exists('wpstream_show_unit_last_class') ):
function  wpstream_show_unit_last_class(){
    global $count;
    global $wpstream_layout;
    global $wpstream_row_number;//for shortcode
    $wpstream_layout    =   intval($wpstream_layout);
    $design_type        =   intval( wpstream_get_option('wpstream_unit_card') );
    
    if( $design_type == 2 ){
        if ( isset($wpstream_row_number) ){ // if shortcode amd free
            if( ($count+1) % $wpstream_row_number == 0 && $count>0 ) {
                echo ' x last';
                return;
            }
        }else{
            if( isset($wpstream_layout) ){
                if($wpstream_layout==3 ){
                    if ($count % 3 == 2) {
                        echo ' last ';
                    }
                }else{
                    if ($count % 2 !== 0) {
                        echo ' last ';
                    }
                }
            } else if ($count % 2 !== 0) {
                echo ' last ';
            }
        }
    }else{
        if( isset($wpstream_layout) ){
            if($wpstream_layout==3 ){
                if ( ($count+1) % 3 == 0 ) {
                    echo ' lay'.$wpstream_layout.'. last 1';
                }
            }else{
                if (($count+1) % 2 == 0) {
                    echo ' lay'.$wpstream_layout.' last 2';
                }
            }
        } else if (($count+1) % 2 == 0) {
            echo ' last 3';
        }
    }
}
endif;




add_filter( 'pre_get_posts', 'wpstream_add_cpt_search' );
/**
 * This function modifies the main WordPress query to include an array of 
 * post types instead of the default 'post' post type.
 *
 * @param object $query  The original query.
 * @return object $query The amended query.
 */
if( !function_exists('wpstream_add_cpt_search') ):
    function wpstream_add_cpt_search( $query ) {

        if ( $query->is_search ) {
            $query->set( 'post_type', array( 'post', 'product', 'wpstream_product' ) );
        }

        return $query;

    }
endif;










if( !function_exists('wpstream_pagination') ):

function wpstream_pagination($pages = '', $range = 2){  
 
    $showitems = ($range * 2)+1;  
    global $paged;
    if(empty($paged)) $paged = 1;


    if($pages == ''){
        global $wp_query;
        $pages = $wp_query->max_num_pages;
        if(!$pages)
        {
            $pages = 1;
        }
    }   

    if(1 != $pages){
        print '<nav class="woocommerce-pagination"><ul class="pagination pagination_nojax page-numbers">';
        print "<li class=\"roundleft\"><a href='".get_pagenum_link($paged - 1)."'></a></li>";

        for ($i=1; $i <= $pages; $i++)
        {
            if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
            {
                if ($paged == $i){
                   print '<li class="page-numbers current"><a href="'.get_pagenum_link($i).'" >'.$i.'</a><li>';
                }else{
                   print '<li class="page-numbers"><a href="'.get_pagenum_link($i).'" >'.$i.'</a><li>';
                }
            }
        }

        $prev_page= get_pagenum_link($paged + 1);
        if ( ($paged +1) > $pages){
           $prev_page= get_pagenum_link($paged );
        }else{
            $prev_page= get_pagenum_link($paged + 1);
        }


        print "<li class=\"roundright\"><a href='".$prev_page."'></a><li></ul></nav>";
    }
}
endif; // end   







if ( ! function_exists( 'wpstream_get_option' ) ) {
    function wpstream_get_option( $theme_option,  $option = false ,$in_case_not = false) {

        global $redux_builder_wpstream;

        $theme_option=trim($theme_option);
        if( isset( $redux_builder_wpstream[$theme_option]) && $redux_builder_wpstream[$theme_option]!='' ){
            $return=$redux_builder_wpstream[$theme_option];
            if($option){
                $return = $redux_builder_wpstream[$theme_option][$option];
            }
        }else{
            $return=$in_case_not;
        }

        return $return;

    }
}





if( !function_exists('wpstream_show_top_bar') ):
    function  wpstream_show_top_bar(){
        global $post;
        global $redux_builder_wpstream;
        $is_top_bar= get_option('wp_estate_show_top_bar_user_menu','');
       
        if( $redux_builder_wpstream['show_top_bar_user_menu'] ==1 ){
             return true;
        }else{
            return false;
        }
        
    }
endif;






if(!function_exists('wpstream_header_image')):
function wpstream_header_image($image){
    global $post;
    $paralax_header = wpstream_get_option('wp_estate_paralax_header','');
    if( isset($post->ID) || is_tax() || is_category()  ){
        
        if( is_page_template( 'splash_page.php' ) ){
            $header_type=20;
            $image =esc_html( wpstream_get_option('wp_estate_splash_image','') );
            $img_full_screen                    =  'no';
            $img_full_back_type                 =   '';
            $page_header_title_over_image       =   stripslashes( esc_html ( get_option('wp_estate_splash_page_title','') ) );
            $page_header_subtitle_over_image    =   stripslashes( esc_html ( get_option('wp_estate_splash_page_subtitle','') ) ) ;
            $page_header_image_height           =   600;
            $page_header_overlay_val            =   esc_html ( get_option('wp_estate_splash_overlay_opacity','') );
            $page_header_overlay_color          =   esc_html ( get_option('wp_estate_splash_overlay_color','') );
            $wp_estate_splash_overlay_image     =   esc_html ( get_option('wp_estate_splash_overlay_image','') );
            
        }else{
            $header_type                =   get_post_meta($post->ID,'media_header_type','true');
            
            if($header_type == 0){ 
                    $img_full_screen                    = '';
                    $paralax_header                     =  wpstream_get_option('wp_estate_paralax_header','');
                    $img_full_back_type                 =  esc_html ( wpstream_get_option('global_header_static_image_height_back_type','') );
                   
                    $page_header_image_height           =  wpstream_get_option('global_header_static_image_height','');
                    $page_header_overlay_val            =  wpstream_get_option('global_header_overlay_opacity','');
                    $page_header_overlay_color          =  wpstream_get_option('global_header_overlay_color',''); 
                    $wp_estate_splash_overlay_image     = '';
                    $page_header_title_over_image       =  wpstream_get_option('global_header_title_over_image',''); 
                    $page_header_subtitle_over_image    =  wpstream_get_option('global_header_subtitle_over_image',''); 
                  
                
                if( isset($post->ID) && is_single() ){
                    $img_full_screen                    = '';
                    $paralax_header                     =  wpstream_get_option('blog_header_paralax_header','');
                    $img_full_back_type                 =  esc_html ( wpstream_get_option('blog_header_static_image_height_back_type','') );
                   
                    $page_header_image_height           =  wpstream_get_option('blog_header_static_image_height','');
                    $page_header_overlay_val            =  wpstream_get_option('blog_header_overlay_opacity','');
                    $page_header_overlay_color          =  wpstream_get_option('blog_header_overlay_color',''); 
                    $wp_estate_splash_overlay_image     = '';
                    
                    if( wpstream_get_option('blog_header_use_title','')=='yes' ){
                        $page_header_title_over_image       =  get_the_title($post->ID); 
                        $page_header_subtitle_over_image    =  get_the_date('',$post->ID); 
                    }else{
                        $page_header_title_over_image       =  wpstream_get_option('blog_header_title_over_image',''); 
                        $page_header_subtitle_over_image    =  wpstream_get_option('blog_header_subtitle_over_image',''); 
                    }
                    
                    
                }else if( is_tax() || is_category()  ){
                    $img_full_screen                    = '';
                    $paralax_header                     =  wpstream_get_option('tax_header_paralax_header','');
                    $img_full_back_type                 =  esc_html ( wpstream_get_option('tax_header_static_image_height_back_type','') );
                   
                    $page_header_image_height           =  wpstream_get_option('tax_header_static_image_height','');
                    $page_header_overlay_val            =  wpstream_get_option('tax_header_overlay_opacity','');
                    $page_header_overlay_color          =  wpstream_get_option('tax_header_overlay_color',''); 
                    $wp_estate_splash_overlay_image     = '';
                    
                    if(wpstream_get_option('tax_header_use_title','')=='yes' ){
                     
                        global $wp_query;
                        $tax = $wp_query->get_queried_object();
                 
                        
                        $page_header_title_over_image       =   $tax->name; 
                        $cat_id                             =   $tax->term_id; 
                        $term_meta                          =   get_option( "taxonomy_$cat_id");
                        $category_tagline                   =   $term_meta['category_tagline'] ? $term_meta['category_tagline'] : '';
                        $page_header_subtitle_over_image    =   stripslashes($category_tagline);
            
            
                    }else{
                        $page_header_title_over_image       =  wpstream_get_option('tax_header_title_over_image',''); 
                        $page_header_subtitle_over_image    =  wpstream_get_option('tax_header_subtitle_over_image',''); 
                    }
                }

                
                
                
            }else{
                $img_full_screen                    = esc_html ( get_post_meta($post->ID, 'page_header_image_full_screen', true) );
                $img_full_back_type                 = esc_html ( get_post_meta($post->ID, 'page_header_image_back_type', true) );  
                $page_header_title_over_image       = stripslashes( esc_html ( get_post_meta($post->ID, 'page_header_title_over_image', true) ) );
                $page_header_subtitle_over_image    = stripslashes( esc_html ( get_post_meta($post->ID, 'page_header_subtitle_over_image', true) ) );
                $page_header_image_height           = floatval ( get_post_meta($post->ID, 'page_header_image_height', true) );
                $page_header_overlay_val            = esc_html ( get_post_meta($post->ID, 'page_header_overlay_val', true) );
                $page_header_overlay_color          = esc_html ( get_post_meta($post->ID, 'page_header_overlay_color', true) );
                $wp_estate_splash_overlay_image     =   '';
            }
        }


   
        
        if($page_header_overlay_val==''){
            $page_header_overlay_val=1;
        }
        if($page_header_image_height==0){
            $page_header_image_height=580;
        }
        
        
        $page_header_overlay_color= str_replace('#', '', $page_header_overlay_color);
        
        print '<div class="wpestate_header_image full_screen_'.$img_full_screen.' parallax_effect_'.$paralax_header.'" style="background-image:url('.$image.');'; 
            if($page_header_image_height!=0){
                print ' height:'.$page_header_image_height.'px; ';
            }
            if($img_full_back_type=='contain'){
                print '  background-size: contain; ';
            }
        print '">';

            if($page_header_overlay_color!='' || $wp_estate_splash_overlay_image!=''){
                print '<div class="wpestate_header_image_overlay" style="background-color:#'.$page_header_overlay_color.';opacity:'.$page_header_overlay_val.';background-image:url('.$wp_estate_splash_overlay_image.');"></div>';
            }

            if($page_header_title_over_image!=''){
                print '<div class="heading_over_image_wrapper" >';
                print '<h1 class="heading_over_image">'.$page_header_title_over_image.'</h1>';
                 
                if($page_header_subtitle_over_image!=''){
                    print '<div class="subheading_over_image">'.$page_header_subtitle_over_image.'</div>';
                }
                
                print '</div>';
            }
            
           
        print'</div>';
        
        
        
    }else{
        print '<div class="wpestate_header_image simplsx" style="background-image:url('.$image.')"></div>';
    }
    
  
}
endif;


if(!function_exists('wpstream_video_header')):
function wpstream_video_header(){
  
    global $post;
    $paralax_header = wpstream_get_option('wp_estate_paralax_header','');
    if( isset($post->ID)){
        if( is_page_template( 'splash_page.php' ) ){
            $page_custom_video                  =   esc_html ( wpstream_get_option('wp_estate_splash_video_mp4','') );
            $page_custom_video_cover_image      =   esc_html ( wpstream_get_option('wp_estate_splash_video_cover_img','') );
            $img_full_screen                    =   'no';
            $page_header_title_over_video       =   stripslashes( esc_html ( wpstream_get_option('wp_estate_splash_page_title','') ) );
            $page_header_subtitle_over_video    =   stripslashes( esc_html ( wpstream_get_option('wp_estate_splash_page_subtitle','') ) );
            $page_header_video_height           =   '';
            $page_header_overlay_color_video    =   esc_html ( wpstream_get_option('wp_estate_splash_overlay_color','') );
            $page_header_overlay_val_video      =   esc_html ( wpstream_get_option('wp_estate_splash_overlay_opacity','') );
            $wp_estate_splash_overlay_image     =    esc_html ( wpstream_get_option('wp_estate_splash_overlay_image','') );
        }else{
            $page_custom_video                  =   esc_html ( get_post_meta($post->ID, 'page_custom_video', true) );
            $page_custom_video_cover_image      =   esc_html ( get_post_meta($post->ID, 'page_custom_video_cover_image', true) );
            $img_full_screen                    =   esc_html ( get_post_meta($post->ID, 'page_header_video_full_screen', true) );
            $page_header_title_over_video       =   stripslashes( esc_html ( get_post_meta($post->ID, 'page_header_title_over_video', true) ) ) ;
            $page_header_subtitle_over_video    =   stripslashes( esc_html ( get_post_meta($post->ID, 'page_header_subtitle_over_video', true) ) );
            $page_header_video_height           =   floatval ( get_post_meta($post->ID, 'page_header_video_height', true) );
            $page_header_overlay_color_video    =   esc_html ( get_post_meta($post->ID, 'page_header_overlay_color_video', true) );
            $page_header_overlay_val_video      =   esc_html ( get_post_meta($post->ID, 'page_header_overlay_val_video', true) );
            $wp_estate_splash_overlay_image     =   '';
        }
       
    
        if($page_header_overlay_val_video==''){
            $page_header_overlay_val_video=1;
        }
        if($page_header_video_height==0){
            $page_header_video_height=580;
        }
        $page_header_overlay_color_video= str_replace('#', '', $page_header_overlay_color_video);
        
        print '<div class="wpestate_header_video full_screen_'.$img_full_screen.' parallax_effect_'.$paralax_header.'" style="'; 
        print ' height:'.$page_header_video_height.'px; ';
        print '">';

        
            print '<video id="hero-vid" class="header_video 2" poster="'.$page_custom_video_cover_image.'" width="100%" height="100%" autoplay ';
            if( wp_is_mobile() ){
                print ' controls ';
            }
            //loop
            print'  >
			<source src="'.$page_custom_video.'" type="video/mp4" />
			
    
		</video>';
        
            if($page_header_overlay_color_video!='' || $wp_estate_splash_overlay_image!=''){
                print '<div class="wpestate_header_video_overlay cc1" style="background-color:#'.$page_header_overlay_color_video.';opacity:'.$page_header_overlay_val_video.';background-image:url('.$wp_estate_splash_overlay_image.');"></div>';
            }

            if($page_header_title_over_video!=''){
                print '<div class="heading_over_video_wrapper" >';
                print '<h1 class="heading_over_video">'.$page_header_title_over_video.'</h1>';
                 
                if($page_header_subtitle_over_video!=''){
                    print '<div class="subheading_over_video">'.$page_header_subtitle_over_video.'</div>';
                }
                
                print '</div>';
            }
            
           
        print'</div>';
        
    }
}
endif;



if(!function_exists('wpstream_title_header')):
    function wpstream_title_header($postID){
    
        
     
    global $wp_query;
  
        if( is_shop() ){
            $title  = esc_html__('Our Products','wpstream-wordpresstheme');
        }else if( is_cart() ){
            $title  = esc_html__('Your Cart','wpstream-wordpresstheme');
        }else if( is_wc_endpoint_url( 'order-pay' ) ){
            $title  = esc_html__('Order Pay','wpstream-wordpresstheme');
        }else if( is_wc_endpoint_url( 'orders' ) ){
            $title  = esc_html__('Your Orders','wpstream-wordpresstheme');
        }else if( is_wc_endpoint_url( 'view-order' ) ){
            $title  = esc_html__('View Order','wpstream-wordpresstheme');
        }else if( is_wc_endpoint_url(  'edit-account' ) ){
            $title  = esc_html__('Edit Account','wpstream-wordpresstheme');
        }else if( is_wc_endpoint_url(  'edit-address') ){
            $title  = esc_html__('Edit Adress','wpstream-wordpresstheme');
        }else if(isset( $wp_query->query_vars['video-list'] ) ){
            $title  = esc_html__('Video List','wpstream-wordpresstheme');
        }else if(isset( $wp_query->query_vars['event-list'] ) ){
            $title  = esc_html__('Event List','wpstream-wordpresstheme');
        } else{
            $title  = get_the_title($postID);
      
        }
        
        print '<div class="wpstream_title_header_wrapper"><h3>'.$title.'</<h3></div>';
        
    }
endif;




if(!function_exists('wpstream_video_header_product')):
function wpstream_video_header_product($postID){
        global $wpstream_plugin;
        $current_user                       =   wp_get_current_user();
        $item_image_preview                 =   get_post_meta($postID, 'item_image_preview', true);
        $item_poster_preview                =   get_post_meta($postID, 'item_poster_preview', true);
        $page_custom_video                  =   get_post_meta($postID, 'item_video_preview', true);
        $page_custom_video_cover_image      =   esc_html ( get_post_meta($postID, 'page_custom_video_cover_image', true) );
        $img_full_screen                    =   esc_html ( get_post_meta($postID, 'page_header_video_full_screen', true) );
        $page_header_title_over_video       =   stripslashes( esc_html ( get_post_meta($postID, 'page_header_title_over_video', true) ) ) ;
        $page_header_subtitle_over_video    =   stripslashes( esc_html ( get_post_meta($postID, 'page_header_subtitle_over_video', true) ) );
        $page_header_video_height           =   floatval ( get_post_meta($postID, 'page_header_video_height', true) );
        $page_header_overlay_color_video    =   esc_html ( get_post_meta($postID, 'page_header_overlay_color_video', true) );
        $page_header_overlay_val_video      =   esc_html ( get_post_meta($postID, 'page_header_overlay_val_video', true) );
        $wp_estate_splash_overlay_image     =   '';
        $term_list                          =   wp_get_post_terms($postID, 'product_type');
        $is_subscription_live_event         =   esc_html(get_post_meta($postID,'_subscript_live_event',true));
    
        $background_image= get_the_post_thumbnail_url( $postID, 'full');
    
        if($page_header_overlay_val_video==''){
            $page_header_overlay_val_video=1;
        }
        
        if($page_header_video_height==0){
            $page_header_video_height=807;
        }
        $paralax_header='yes';
        
     
        //video on demand player
        if( (is_singular('wpstream_product')&& get_post_meta($postID, 'wpstream_product_type', true)==2 ) ||
            (is_singular('wpstream_product')&& get_post_meta($postID, 'wpstream_product_type', true)==3 ) ||              
            ( !is_wp_error($term_list) && isset($term_list[0]->name) && $term_list[0]->name=='video_on_demand' )  || 
            ( !is_wp_error($term_list) && isset($term_list[0]->name) && $term_list[0]->name=='subscription' && $is_subscription_live_event=='no' ) ){
               

                wpstream_play_video_trailer($postID);

                if($page_header_overlay_color_video!='' || $wp_estate_splash_overlay_image!=''){
                    print '<div class="wpestate_header_video_overlay cc2" style="background-color:#'.$page_header_overlay_color_video.';opacity:'.$page_header_overlay_val_video.';background-image:url('.$wp_estate_splash_overlay_image.');"></div>';
                }

            
            
                if($page_header_title_over_video!=''){
                    print '<div class="heading_over_video_wrapper" >';
                    print '<h1 class="heading_over_video">'.$page_header_title_over_video.'</h1>';

                    if($page_header_subtitle_over_video!=''){
                        print '<div class="subheading_over_video">'.$page_header_subtitle_over_video.'</div>';
                    }

                    print '</div>';
                }
                
                if (is_singular('wpstream_product')&& ( get_post_meta($postID, 'wpstream_product_type', true)==2 || get_post_meta($postID, 'wpstream_product_type', true)==3) ){
                    print '<div id="second_video_wrapper">';
                        wpstream_video_on_demand_player_for_theme($postID);
                    print '</>';                    
                }else{
                
                    if(is_user_logged_in()){
                        print wpstream_user_logged_in_product_already_bought_from_theme($postID);
                    }else{
                        wpstream_media_not_logged_in();
                    }
                }
                
                
                
        //live streaming player        
        }else if( (is_singular('wpstream_product') && get_post_meta($postID, 'wpstream_product_type', true)==1 ) ||
            $term_list[0]->name=='live_stream' || 
            ($term_list[0]->name=='subscription' && $is_subscription_live_event=='yes' )  ){
       
            print '<div class="wpestate_header_video xxx2 wpstream_live full_screen_'.$img_full_screen.' parallax_effect_'.$paralax_header.'" >';
        
            
            $background_image= get_the_post_thumbnail_url( $postID, 'full');
            print '<div class="wpstrem_header_video_img_back" style="background-image:url('.$background_image.')"></div>';

     
            if( class_exists('Wpstream') && !$wpstream_plugin->main->wpstream_live_connection->wpstream_is_is_live($postID) ){  
         
                //print '<div class="wpstream_we_are_not_live">'.esc_html__('We are not live at this moment. Please check back later.','wpstream-wordpresstheme').'</div>';
                wpstream_play_video_trailer($postID);
            }else  if (   
                !is_singular('wpstream_product') && !wc_customer_bought_product( $current_user->user_email, $current_user->ID, $postID) && 
                ( function_exists('wcs_user_has_subscription') && !wcs_user_has_subscription( $current_user->ID, $postID ,'active') ) ) {
           
                wpstream_play_video_trailer($postID);
            }
                
            if (is_singular('wpstream_product')&& get_post_meta($postID, 'wpstream_product_type', true)==1 ){
                echo '<div class="wpstream_player_wrapper xx3"><div class="wpstream_player_wrapper_sec" >';
                print wpstream_live_event_player_for_theme($postID);
                print'</div></div>';
            }else{
                
                if(is_user_logged_in()){
                    print wpstream_user_logged_in_product_already_bought_from_theme($postID);
                }else{
                    $paralax_header='yes';
                    $item_image_preview                 =   get_post_meta($postID, 'item_image_preview', true);
                    wpstream_media_not_logged_in();
                }
            }
            
            if( class_exists('Wpstream') && $wpstream_plugin->main->wpstream_live_connection->wpstream_is_is_live($postID) ){  
                get_template_part( 'templates/chat_template' );
            }
        }
        
      
        print'</div>';
        
    
}
endif;


if(!function_exists('wpstream_media_not_logged_in')):
function wpstream_media_not_logged_in(){
    print '<div class="wpstream_media_not_logged_in">'.esc_html__('You need to login if you want to watch!').'</div>';
}
endif;



if(!function_exists('wpstream_play_video_trailer')):
function wpstream_play_video_trailer($postID){
    $wpstream_product_type              =   intval ( get_post_meta($postID, 'wpstream_product_type', true) );
    $current_user                       =   wp_get_current_user();
    $item_image_preview                 =   get_post_meta($postID, 'item_image_preview', true);
    $item_poster_preview                =   get_post_meta($postID, 'item_poster_preview', true);
    $page_custom_video                  =   get_post_meta($postID, 'item_video_preview', true);
    $page_custom_video_cover_image      =   esc_html ( get_post_meta($postID, 'page_custom_video_cover_image', true) );
    $img_full_screen                    =   esc_html ( get_post_meta($postID, 'page_header_video_full_screen', true) );
    $page_header_title_over_video       =   stripslashes( esc_html ( get_post_meta($postID, 'page_header_title_over_video', true) ) ) ;
    $page_header_subtitle_over_video    =   stripslashes( esc_html ( get_post_meta($postID, 'page_header_subtitle_over_video', true) ) );
    $page_header_video_height           =   floatval ( get_post_meta($postID, 'page_header_video_height', true) );
    $page_header_overlay_color_video    =   esc_html ( get_post_meta($postID, 'page_header_overlay_color_video', true) );
    $page_header_overlay_val_video      =   esc_html ( get_post_meta($postID, 'page_header_overlay_val_video', true) );
    $wp_estate_splash_overlay_image     =   '';
    $term_list                          =   wp_get_post_terms($postID, 'product_type');
    $wpstream_product_type_external_class=  '';
    $is_subscription_live_event         =   esc_html(get_post_meta($postID,'_subscript_live_event',true));
    
    
    if($wpstream_product_type==3){
        $wpstream_product_type_external_class= ' wpstream_external_video ';
    }
    
    $background_image= get_the_post_thumbnail_url( $postID, 'full');

    if($page_header_overlay_val_video==''){
        $page_header_overlay_val_video=1;
    }

    if($page_header_video_height==0){
        $page_header_video_height=807;
    }
    $paralax_header='yes';

        
     print '<div class="wpestate_header_video xxx1 '.$wpstream_product_type_external_class.' full_screen_'.$img_full_screen.' parallax_effect_'.$paralax_header.'" style="'; 
                print ' height:'.$page_header_video_height.'px; ';
                print '">';
                
                print '<div class="wpstrem_header_video_img_back" style="background-image:url('.$background_image.')"></div>';
                
                
                print '<div class="wpstream_item_image_preview">';
                
                print '<div class="wpstream_item_action_bar">';
                    print'<div id="wpstream_mute_preview"><i class="demo-icon icon-volume-up"></i></div>';
                
                    
            
                    
                    if ( is_singular('wpstream_product') && 
                            ( get_post_meta($postID, 'wpstream_product_type', true)==2 || get_post_meta($postID, 'wpstream_product_type', true)==3 )){
                        print'   <div id="wpstream_play_video"><i class="demo-icon icon-play"></i>'.esc_html__('Play','wpstream-wordpresstheme').'</div>';
                    }else{

                        if( wpstream_is_global_subscription() ){

                            if( wpstream_check_global_subscription_model()  ){

                                print'   <div id="wpstream_play_video"><i class="demo-icon icon-play"></i>'.esc_html__('Play','wpstream-wordpresstheme').'</div>';                        

                            }

                        }else{
                            if( !is_wp_error($term_list) &&  (isset($term_list[0]->name) &&   $term_list[0]->name=='video_on_demand')  || 
                                    ( !is_wp_error($term_list) &&  isset($term_list[0]->name) && $term_list[0]->name=='subscription' && $is_subscription_live_event=='no' ) ){

                                if ( wc_customer_bought_product( $current_user->user_email, $current_user->ID, $postID) ||
                                    ( function_exists('wcs_user_has_subscription') && wcs_user_has_subscription( $current_user->ID, $postID ,'active')) ) {
                                    print'   <div id="wpstream_play_video"><i class="demo-icon icon-play"></i>'.esc_html__('Play','wpstream-wordpresstheme').'</div>';
                                }
                            }
                        }
                    }
                  
                
                print'</div>';
                    
                
                
                print '<div class="wpstream_video_preview_image_wrapper">';
                        if($item_image_preview!=''){
                            print '<img class="wpstream_video_preview_image" src="'.$item_image_preview.' ">';
                        }else{
                            print '<div class="wpstream_no_preview_img"></div>';
                        }
                        print '<div class="wpstream_custom_info">';
                            $actors_list=get_the_term_list($postID,'wpstream_actors',' ',', ',' ');
                            if(!empty($actors_list)){
                                print '<div class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('cast_label').':</span><span class="wpstream_custom_info_field_title_list"> '.$actors_list.'</span></div>';
                            }
                            
                            $movie_type= get_the_term_list($postID,'wpstream_category',' ',', ',' ');
                            if($movie_type!=''){
                                $movie_type.=', ';
                            }
                            if(function_exists('wc_get_product_category_list')){
                                $movie_type.= wc_get_product_category_list($postID);
                            }
    
                            if(!empty($movie_type)){
                                print '<div class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('movie_type_label').':</span><span class="wpstream_custom_info_field_title_list"> '.$movie_type.'</span></div>';
                            }
                            $movie_rating=get_the_term_list($postID,'wpstream_movie_rating',' ',', ',' ');
                            if(!empty($movie_rating)){
                                print '<div class="wpstream_custom_info_field"><span class="wpstream_custom_info_field_title">'.wpstream_get_option('rating_label').':</span> <span class="wpstream_custom_info_field_title_list">'.$movie_rating.'</span></div>';   
                            }
                        print '</div>';
                  print'</div>
                </div>';

            if(is_singular('wpstream_product') && $wpstream_product_type==3){
            }else{
                if($page_custom_video!=''){
                    print '<video id="hero-vid" class="header_video 1" poster="'.$item_poster_preview.'"  width="100%" height="100%"  ';
                    if( wp_is_mobile() ){
                        print ' controls ';
                    }
                    //autoplay
                    print' autoplay  >
                        <source src="'.$page_custom_video.'" type="video/mp4" />
                    </video>';
                }
            }

}
endif;





if(!function_exists('wpstream_user_logged_in_product_already_bought_from_theme')):
function wpstream_user_logged_in_product_already_bought_from_theme($postID='') {
    global $woocommerce;
    if ( is_user_logged_in() ) {
        global $product;
        $current_user   =       wp_get_current_user();
        $product_id     =       $postID;
        $term_list      =       wp_get_post_terms($product_id, 'product_type');
        $free_to_include_player   =       0;
        
        if( wpstream_is_global_subscription()  ){
            if(wpstream_check_global_subscription_model()){
                $free_to_include_player   =       1;
            }
        }else{
            if (    wc_customer_bought_product( $current_user->user_email, $current_user->ID, $product_id) || 
                ( function_exists('wcs_user_has_subscription') && wcs_user_has_subscription( $current_user->ID, $product_id ,'active') ) 
            ){
                $free_to_include_player   =       1;
            }
        }
        
        
        
        if (  $free_to_include_player==1 ){

            $page_header_video_height           =   floatval ( get_post_meta($postID, 'page_header_video_height', true) );  
            if($page_header_video_height==0){
                $page_header_video_height=807;
            }
            
            echo '<div class="wpstream_player_wrapper">';
            echo'<div class="wpstream_player_wrapper_sec " >';

            $is_subscription_live_event =   esc_html(get_post_meta($product_id,'_subscript_live_event',true));
        

            if( $term_list[0]->name=='live_stream' || ($term_list[0]->name=='subscription' && $is_subscription_live_event=='yes' )  ){
                wpstream_live_event_player_for_theme($product_id);
            }else if( $term_list[0]->name=='video_on_demand'  || ($term_list[0]->name=='subscription' && $is_subscription_live_event=='no' ) ){
                wpstream_video_on_demand_player_for_theme($product_id);
            }

        }else{
            $vod_class='wpstream_vod_class ';
            if (is_singular('wpstream_product') && ( get_post_meta($postID, 'wpstream_product_type', true)==2 || get_post_meta($postID, 'wpstream_product_type', true)==3) ){
                $vod_class=' wpstream_vod_class ';
            }
            if( $term_list[0]->name=='video_on_demand'  || ($term_list[0]->name=='subscription' && $is_subscription_live_event=='no' ) ){
                $vod_class=' wpstream_vod_class ';
            }
            $paralax_header='yes';
            $item_image_preview                 =   get_post_meta($postID, 'item_image_preview', true);
            echo '<div class="wpstream_player_wrapper no_buy '. $term_list[0]->name.'">';
            
            if( wpstream_is_global_subscription()  ){
                $main_subscription = wpstream_get_option('subscription_global_array');
                $postID=intval($main_subscription[0]);
            
                echo '<div class="wpstream_notice '.$vod_class.' ">'.__('You need to subcribe to watch this !','wpstream-wordpresstheme');
                    echo '<a href="'.wc_get_cart_url().'?add-to-cart='.$postID.'" name="add-to-cart" value="'.$postID.'" class="wpstream_addtocart wpstream_button_effect single_add_to_cart_button button alt wpstream_join_now_but">'.esc_html__('join now','wpstream-wordpresstheme').'</a>';
                echo '</div>';
            }else{
                echo '<div class="wpstream_notice '.$vod_class.' ">'.__('You did not buy this product!','wpstream-wordpresstheme');
                    echo '<a href="'.wc_get_cart_url().'?add-to-cart='.$postID.'" name="add-to-cart" value="'.$postID.'" class="wpstream_addtocart wpstream_button_effect single_add_to_cart_button button alt">'.esc_html__('Add to cart','wpstream-wordpresstheme').'</a>';
                echo '</div>';
            }
            
          
            echo'<div class="wpstream_please_buy_product xxx6 parallax_effect_'.$paralax_header.'" style="background-image:url('.$item_image_preview.')">';
        }

        echo '</div></div>';
    }
}
endif;

  function remove_http($url) {
        $disallowed = array('http://', 'https://');
        foreach($disallowed as $d) {
           if(strpos($url, $d) === 0) {
              return str_replace($d, '', $url);
           }
        }
        return $url;
    }
    

if(!function_exists('wpstream_live_event_player_for_theme')):
function wpstream_live_event_player_for_theme($product_id){
    global $wpstream_plugin;
   $wpstream_plugin->main->wpstream_player->wpstream_live_event_player($product_id,'no','yes');
return;  
    
 
}
endif;




if(!function_exists('wpstream_video_on_demand_player_for_theme')):
function wpstream_video_on_demand_player_for_theme($product_id){
    global $wpstream_plugin;
  
     
    $uri_details        =   $wpstream_plugin->main->wpstream_player->wpstream_video_on_demand_player_uri_request($product_id);
    $video_path_final   =   $uri_details['video_path_final'];
    $wpstream_data_setup =  $uri_details['wpstream_data_setup'];
    $video_type          =  $uri_details['video_type'];
                            
     
     
  
    echo '<video id="wpstream-video" class="video-js vjs-default-skin  vjs-16-9" controls preload="auto"
       '.$wpstream_data_setup.' >

          <source src="'.trim($video_path_final).'"  type="'.$video_type.'">
          <p class="vjs-no-js">
            To view this video please enable JavaScript, and consider upgrading to a web browser that
            <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a>
          </p>
        </video>';

}
endif;




if(!function_exists('wprentals_return_theme_slider_list')):
    function wprentals_return_theme_slider_list(){
        $return_array=array();
        $args = array(     
                'post_type'         => array( 'product','wpstream_product' ),
                'post_status'       =>  'publish',
                'paged'             =>  0,
                'posts_per_page'    =>  50,
                'cache_results'           =>    false,
                'update_post_meta_cache'  =>    false,
                'update_post_term_cache'  =>    false,
        );

        $recent_posts = new WP_Query($args);

        while ($recent_posts->have_posts()): $recent_posts->the_post();
            $theid                  =   get_the_ID();
            $return_array[$theid]   =   get_the_title();

        endwhile;

        return   $return_array;       
    }
endif;


if(!function_exists('wpstream_return_transparent_header_class')):
    function wpstream_return_transparent_header_class(){
        global $post;
        $header_transparent_class='';

        $global_header_transparent=wpstream_get_option('global_header_transparent','');
        if($global_header_transparent==1){
            $header_transparent_class=' transparent_header ';
        }

        if(isset($post->ID) &&  get_post_meta ( $post->ID, 'header_transparent', true) =='yes' ){
            $header_transparent_class=' transparent_header ';
        }else if(isset($post->ID) &&  get_post_meta ( $post->ID, 'header_transparent', true) =='no' ){
            $header_transparent_class='';
        }
        return $header_transparent_class;

    }
endif;


if(!function_exists('wpstream_blog_slider')):
function wpstream_blog_slider($postID){
    
    $arguments = array(
        'numberposts'       =>  -1,
        'post_type'         =>  'attachment',
        'post_parent'       =>  $postID,
        'post_status'       =>  null, 
        'orderby'           =>  'menu_order',
        'post_mime_type'    =>  'image',
        'order'             =>  'ASC'
    );
  
    $post_attachments   = get_posts($arguments);



    if ($post_attachments ) {  ?>   

        <div id="wpstream-carousel-post" class="carousel slide post-carusel" data-ride="carousel" data-interval="false">
             <!-- Wrapper for slides -->
        <div class="carousel-inner">

            <?php

            $counter=0;
            foreach ($post_attachments as $attachment) {

                $counter++;
                $active='';
                if($counter==1){
                    $active=" active ";
                }else{
                     $active=" ";
                }
                $full_img        = wp_get_attachment_image_src($attachment->ID, 'wpstrem_product_image');
                $full_prty       = wp_get_attachment_image_src($attachment->ID, 'full');
                $attachment_meta = wpestate_get_attachment($attachment->ID)
                ?>

                <div class="carousel-item <?php print $active;?>">
                    <a href="<?php print $full_prty[0]; ?>" class="prettygalery" > 
                        <img  src="<?php print $full_img[0];?>" alt="<?php print $attachment_meta['caption']; ?>" class="img-responsive" />
                    </a>
                </div>

             <?php } //end foreach?>

            </div>
             
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php  
                    $counter=0;
                    foreach ($post_attachments as $attachment) {
                    $preview = wp_get_attachment_image_src($attachment->ID, 'woocommerce_gallery_thumbnail');
                    $counter++;
                    $active='';
                    if($counter==1 ){
                        $active=" active ";
                    }else{
                        $active=" ";
                    }
                 ?>
                    <li data-target="#wpstream-carousel-post" data-slide-to="<?php print $counter-1;?>" class="<?php $active;?>">
                        <img  src="<?php print $preview[0];?>" alt="thumb" class="img-responsive" />
                    </li>   
                <?php
                }
                ?>
            </ol>

       

            <!-- Controls -->
            <a class="carousel-control-prev" href="#wpstream-carousel-post" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#wpstream-carousel-post" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

    <?php
    } // end if post_attachments
}
endif;


if (!function_exists('wpestate_get_attachment')):
    function wpestate_get_attachment($attachment_id) {

        $attachment = get_post($attachment_id);
        return array(
            'alt' => get_post_meta($attachment->ID, '_wp_attachment_image_alt', true),
            'caption' => $attachment->post_excerpt,
            'description' => $attachment->post_content,
            'href' => esc_url( get_permalink($attachment->ID) ),
            'src' => $attachment->guid,
            'title' => $attachment->post_title
        );
    }
endif;



if( !function_exists('wpstream_get_template_link') ):
function wpstream_get_template_link( $template_name  ,$bypass=0){   
   $transient_name=$template_name;
    
        if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
            $transient_name.='_'. ICL_LANGUAGE_CODE;
        }

        
        $template_link = wpstream_get_transient( 'wpestream_get_template_link_' . $transient_name );
        
        if( $template_link === false  || $bypass==1 ) {   
            $pages = get_pages(array(
                'meta_key'      => '_wp_page_template',
                'meta_value'    => $template_name
            ));

            if( $pages ){
                $template_link = get_permalink( $pages[0]->ID );
            }else{
                $template_link=home_url();
            }
            
          
            wpstream_set_transient('wpstream_get_template_link_' . $transient_name,$template_link,60*60*24);
           
        }



        return $template_link;
}
endif; // end  



function wpstream_generateRandomString_for_theme($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}





add_filter( 'body_class', 'wpstream_body_class' );
function wpstream_body_class($classes){
    $wpstream_use_chat_live_stream = wpstream_get_option('wpstream_use_chat_live_stream','');
    if ($wpstream_use_chat_live_stream==1){
        $classes[]='wpstream_use_chat_live_stream';
    }
    return $classes;
}


function wpstream_connect_to_chat(){
    return;
    $current_user           =   wp_get_current_user();
    $userID                 =   $current_user->ID;
    $user_login             =   $current_user->user_login;
   
    if(current_user_can('administrator')){
        $key = "3vjajxVV4B4Ylx259Z6u";
    }else{
        $key = "3vjajxVV4B4YIx259Z6u";
    }
    
    print '<script type="text/javascript">
        //<![CDATA[
        jQuery(document).ready(function(){
         
            username = "'.$user_login.'";
            key="'.$key.'";
            connect();
      
        });
        //]]>
        </script>';
    
}

if(!function_exists('convertAccentsAndSpecialToNormal')):
function convertAccentsAndSpecialToNormal($string) {
    $table = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Ă'=>'A', 'Ā'=>'A', 'Ą'=>'A', 'Æ'=>'A', 'Ǽ'=>'A',
        'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'ă'=>'a', 'ā'=>'a', 'ą'=>'a', 'æ'=>'a', 'ǽ'=>'a',

        'Þ'=>'B', 'þ'=>'b', 'ß'=>'Ss',

        'Ç'=>'C', 'Č'=>'C', 'Ć'=>'C', 'Ĉ'=>'C', 'Ċ'=>'C',
        'ç'=>'c', 'č'=>'c', 'ć'=>'c', 'ĉ'=>'c', 'ċ'=>'c',

        'Đ'=>'Dj', 'Ď'=>'D', 'Đ'=>'D',
        'đ'=>'dj', 'ď'=>'d',

        'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E', 'Ĕ'=>'E', 'Ē'=>'E', 'Ę'=>'E', 'Ė'=>'E',
        'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ĕ'=>'e', 'ē'=>'e', 'ę'=>'e', 'ė'=>'e',

        'Ĝ'=>'G', 'Ğ'=>'G', 'Ġ'=>'G', 'Ģ'=>'G',
        'ĝ'=>'g', 'ğ'=>'g', 'ġ'=>'g', 'ģ'=>'g',

        'Ĥ'=>'H', 'Ħ'=>'H',
        'ĥ'=>'h', 'ħ'=>'h',

        'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'İ'=>'I', 'Ĩ'=>'I', 'Ī'=>'I', 'Ĭ'=>'I', 'Į'=>'I',
        'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'į'=>'i', 'ĩ'=>'i', 'ī'=>'i', 'ĭ'=>'i', 'ı'=>'i',

        'Ĵ'=>'J',
        'ĵ'=>'j',

        'Ķ'=>'K',
        'ķ'=>'k', 'ĸ'=>'k',

        'Ĺ'=>'L', 'Ļ'=>'L', 'Ľ'=>'L', 'Ŀ'=>'L', 'Ł'=>'L',
        'ĺ'=>'l', 'ļ'=>'l', 'ľ'=>'l', 'ŀ'=>'l', 'ł'=>'l',

        'Ñ'=>'N', 'Ń'=>'N', 'Ň'=>'N', 'Ņ'=>'N', 'Ŋ'=>'N',
        'ñ'=>'n', 'ń'=>'n', 'ň'=>'n', 'ņ'=>'n', 'ŋ'=>'n', 'ŉ'=>'n',

        'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ō'=>'O', 'Ŏ'=>'O', 'Ő'=>'O', 'Œ'=>'O',
        'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ō'=>'o', 'ŏ'=>'o', 'ő'=>'o', 'œ'=>'o', 'ð'=>'o',

        'Ŕ'=>'R', 'Ř'=>'R',
        'ŕ'=>'r', 'ř'=>'r', 'ŗ'=>'r',

        'Š'=>'S', 'Ŝ'=>'S', 'Ś'=>'S', 'Ş'=>'S',
        'š'=>'s', 'ŝ'=>'s', 'ś'=>'s', 'ş'=>'s',

        'Ŧ'=>'T', 'Ţ'=>'T', 'Ť'=>'T',
        'ŧ'=>'t', 'ţ'=>'t', 'ť'=>'t',

        'Ù'=>'U', 'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ũ'=>'U', 'Ū'=>'U', 'Ŭ'=>'U', 'Ů'=>'U', 'Ű'=>'U', 'Ų'=>'U',
        'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ũ'=>'u', 'ū'=>'u', 'ŭ'=>'u', 'ů'=>'u', 'ű'=>'u', 'ų'=>'u',

        'Ŵ'=>'W', 'Ẁ'=>'W', 'Ẃ'=>'W', 'Ẅ'=>'W',
        'ŵ'=>'w', 'ẁ'=>'w', 'ẃ'=>'w', 'ẅ'=>'w',

        'Ý'=>'Y', 'Ÿ'=>'Y', 'Ŷ'=>'Y',
        'ý'=>'y', 'ÿ'=>'y', 'ŷ'=>'y',

        'Ž'=>'Z', 'Ź'=>'Z', 'Ż'=>'Z', 'Ž'=>'Z',
        'ž'=>'z', 'ź'=>'z', 'ż'=>'z', 'ž'=>'z',

        '“'=>'"', '”'=>'"', '‘'=>"'", '’'=>"'", '•'=>'-', '…'=>'...', '—'=>'-', '–'=>'-', '¿'=>'?', '¡'=>'!', '°'=>' degrees ',
        '¼'=>' 1/4 ', '½'=>' 1/2 ', '¾'=>' 3/4 ', '⅓'=>' 1/3 ', '⅔'=>' 2/3 ', '⅛'=>' 1/8 ', '⅜'=>' 3/8 ', '⅝'=>' 5/8 ', '⅞'=>' 7/8 ',
        '÷'=>' divided by ', '×'=>' times ', '±'=>' plus-minus ', '√'=>' square root ', '∞'=>' infinity ',
        '≈'=>' almost equal to ', '≠'=>' not equal to ', '≡'=>' identical to ', '≤'=>' less than or equal to ', '≥'=>' greater than or equal to ',
        '←'=>' left ', '→'=>' right ', '↑'=>' up ', '↓'=>' down ', '↔'=>' left and right ', '↕'=>' up and down ',
        '℅'=>' care of ', '℮' => ' estimated ',
        'Ω'=>' ohm ',
        '♀'=>' female ', '♂'=>' male ',
        '©'=>' Copyright ', '®'=>' Registered ', '™' =>' Trademark ',
    );

    $string = strtr($string, $table);
    // Currency symbols: £¤¥€  - we dont bother with them for now
    $string = preg_replace("/[^\x9\xA\xD\x20-\x7F]/u", "", $string);

    return $string;
}
endif;

