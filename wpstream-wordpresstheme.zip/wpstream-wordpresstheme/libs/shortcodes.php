<?php

if(!function_exists('wpstream_list_items_by_id_function')):
   function wpstream_list_items_by_id_function($attributes, $content = null) {
        global $options;
        global $align;
        global $align_class;
        global $post;
        global $currency;
        global $where_currency;
        global $is_shortcode;
        global $show_compare_only;
        global $row_number_col;    
        global $current_user;
        global $curent_fav;
        global $property_unit_slider;
        global $no_listins_per_row;
        global $wpestate_uset_unit;
        global $custom_unit_structure;
        global $wpstream_row_number;
        $wpstream_row_number='';
        $return_string            =   '';
        $custom_unit_structure    =   wpstream_get_option('wpestate_property_unit_structure');
        $wpestate_uset_unit       =   intval ( wpstream_get_option('wpestate_uset_unit','') );
        $no_listins_per_row       =   intval( wpstream_get_option('wp_estate_listings_per_row', '') );

        $current_user = wp_get_current_user();
    
    
        $title              =   '';
        if ( isset($attributes['title']) ){
            $title=$attributes['title'];
        }

        $attributes = shortcode_atts( 
            array(
                'title'                 => '',
                'type'                  => 'products',
                'ids'                   =>  '',
                'number'                =>  3,
                'rownumber'             =>  4,    
                'link'                  =>  '#',

            ), $attributes) ;
   
        if ( isset($attributes['ids']) ){
            $ids = $transient_ids=$attributes['ids'];
            $ids_array=explode(',',$ids);
        }

    
        if ( isset($attributes['title']) ){
            $title=$attributes['title'];    
        }

        $post_number_total = $attributes['number'];

    
        if ( isset($attributes['rownumber']) ){
            $row_number        = $attributes['rownumber']; 
        }

        // max 4 per row
        if($row_number>4){
            $row_number=4;
        }
        
        if ($attributes['type'] == 'products'){
            $type                   =   'product';      
        }   else if ($attributes['type'] == 'free products' ){
            $type                   =   'wpstream_product';      
        }else{
             $type = 'post';
        }
    
        $post_number_total = $attributes['number'];
        if ( isset($attributes['rownumber']) ){
            $wpstream_row_number        = $attributes['rownumber']; 
        } 


        if ($attributes['type'] == 'articles' && $wpstream_row_number>4){
            $wpstream_row_number=4;
        }   
    
        
        
        
        $button='';
        if ($attributes['link'] != '') {
            if ($attributes['type'] == 'product') {
                $button .= '<div class="listinglink-wrapper">
                               <a href="' . $attributes['link'] . '"> <span class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button more_list">'.esc_html__( ' More Listings','wpstream-wordpresstheme').' </span></a>
                           </div>';
            } else {
                $button .= '<div class="listinglink-wrapper">
                               <a href="' . $attributes['link'] . '"> <span class="wpb_btn-info wpb_btn-small wpestate_vc_button  vc_button more_list">'.esc_html__( ' More Articles','wpstream-wordpresstheme').'</span></a>
                            </div>';
            }
        } else {
            $class = "nobutton";
        }

    
 
    
   
        $args = array(
             'post_type'         => 'any',
             'post_status'       => 'publish',       
             'posts_per_page'    => $post_number_total, 
             'orderby'           => 'post__in',
             'post__in'          => $ids_array,
         );

        $recent_posts   =   false;
        if(function_exists('wpestate_request_transient_cache')){
            $recent_posts = wpstream_get_transient( 'wpestate_list_items_by_id_'.$transient_ids);
        }

        if( $recent_posts === false ) {
            $recent_posts = new WP_Query($args);
            if(function_exists('wpestate_set_transient_cache')){
                wpstream_set_transient( 'wpestate_list_items_by_id_'.$transient_ids,$recent_posts,4*60*60);
            }
        }
   

        
        
        
        
        
        
        
        
        global $count;
        $count=0;
        
        $design_type=wpstream_get_option('wpstream_unit_card');
        
        $return_string .= '<div class=" bottom-estate_property nobutton "><div class=" items_shortcode_wrapper">';
        if($title!=''){
            $return_string .= '<h2 class="shortcode_title">'.$title.'</h2>';
        }
    
        global $post;
        $design_type    =   wpstream_get_option('wpstream_unit_card');
        $items_class    =   ' columns-'.$wpstream_row_number.' ';
        $return_string .=   '<ul class="products '.$items_class.'">';
    
    
        ob_start();  

        while ($recent_posts->have_posts()): $recent_posts->the_post();
        
            if($type == 'product'){
                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3_shortcode',1 );
                
                if( function_exists('wc_get_template_part') ) {  
                    wc_get_template_part( 'content', 'product' );
                }
                
                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3_shortcode',1 );
                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
           
            }else if($type == 'wpstream_product'){
                get_template_part('templates/free_product_unit');
            }else {
                get_template_part('templates/blog_unit');
            }

            $count++;

        endwhile;

        $templates = ob_get_contents();
        ob_end_clean(); 
        
        $return_string .=$templates;
        $return_string .='</ul>';
        $return_string .=$button;
        $return_string .= '</div></div>';
        wp_reset_query();
        wp_reset_postdata();
    return $return_string;
}
endif;

    
    
if( !function_exists('wpstream_recent_posts_pictures_new') ):
function wpstream_recent_posts_pictures_new($attributes, $content = null) {
    global $options;
    global $align;
    global $align_class;
    global $post;
    global $currency;
    global $where_currency;
    global $is_shortcode;
    global $show_compare_only;
    global $row_number_col;    
    global $current_user;
    global $curent_fav;
    global $property_unit_slider;
    global $no_listins_per_row;
    global $wpestate_uset_unit;
    global $custom_unit_structure;
    global $wpstream_row_number;
        
    $custom_unit_structure    =   wpstream_get_option('wpestate_property_unit_structure');
    $wpestate_uset_unit       =   intval ( wpstream_get_option('wpestate_uset_unit','') );
    $no_listins_per_row       =   intval( wpstream_get_option('wp_estate_listings_per_row', '') );

    $current_user = wp_get_current_user();
    
    $title              =   '';
    if ( isset($attributes['title']) ){
        $title=$attributes['title'];
    }

    $attributes = shortcode_atts( 
                array(
                    'title'                 =>  '',
                    'type'                  => 'products',
                    'category_ids'          =>  '',
                    'movie_categ_ids'       =>  '',
                    'actors_ids'            =>  '',
                    'ratings_ids'           =>  '',
                    'number'                =>  4,
                    'rownumber'             =>  4,
                    'align'                 =>  'vertical',
                    'link'                  =>  '',
                    'control_terms_id'      =>  '',
                    'show_featured_only'    =>  'no',
                    'random_pick'           =>  'no',
                    'featured_first'        =>  'no'
                ), $attributes) ;

    

  
    $userID             =   $current_user->ID;
    $user_option        =   'favorites'.$userID;
    $curent_fav         =   get_option($user_option);
    $options            =   wpstream_page_details_sh($post->ID);
    $return_string      =   '';
    $pictures           =   '';
    $button             =   '';
    $class              =   '';
    $is_shortcode       =   1;
    $row_number_col     =   '';
    $wpstream_row_number=   '';       
    $show_featured_only =   '';
    $random_pick        =   '';
    $featured_first     =   '';
    $orderby            =   'meta_value';
   

    if ( isset($attributes['category_ids']) ){
        $category=$attributes['category_ids'];
    }

    if ( isset($attributes['movie_categ_ids']) ){
        $movie_categ=$attributes['movie_categ_ids'];
    }

    if ( isset($attributes['actors_ids']) ){
        $actors=$attributes['actors_ids'];
    }

    if ( isset($attributes['ratings_ids']) ){
        $ratings=$attributes['ratings_ids'];
    }

    if (isset($attributes['random_pick'])){
        $random_pick=   $attributes['random_pick'];
        if($random_pick==='yes'){
            $orderby    =   'rand';
        }
    }
    
    $post_number_total = $attributes['number'];
    if ( isset($attributes['rownumber']) ){
        $wpstream_row_number        = $attributes['rownumber']; 
    }
    
   
    if ($attributes['type'] == 'articles' && $wpstream_row_number>4){
        $wpstream_row_number=4;
    }
    
    
    $align=''; 
    $align_class='';
    if(isset($attributes['align']) && $attributes['align']=='horizontal'){
        $align="col-md-12";
        $align_class='the_list_view';
     
    }
      
  
    if ($attributes['type'] == 'products' || $attributes['type'] == 'free products' ) {
    
        if ($attributes['type'] == 'products'){
            $type                   =   'product';      
        }   else if ($attributes['type'] == 'free products' ){
            $type                   =   'wpstream_product';      
        }
        
        $category_array         =   '';
        $movie_categ_array      =   '';
        $actors_array           =   '';
        $ratings_array          =   '';
        
         // build category array
        if($category!=''){
            $category_of_tax=array();
            $category_of_tax=  explode(',', $category);
            $category_array=array(     
                            'taxonomy'  => 'product_cat',
                            'field'     => 'term_id',
                            'terms'     => $category_of_tax
                            );
        }
            
        
        // build movie categ array
        if($movie_categ!=''){
            $movie_categ_tax    =   array();
            $movie_categ_tax    =   explode(',', $movie_categ);
            $movie_categ_array  =   array(     
                            'taxonomy'  => 'wpstream_category',
                            'field'     => 'term_id',
                            'terms'     => $movie_categ_tax
                            );
        }
        
        // build actors array
        if($actors!=''){
            $actors_tax     =   array();
            $actors_tax     =  explode(',', $actors);
            $actors_array   =   array(     
                            'taxonomy'  => 'wpstream_actors',
                            'field'     => 'term_id',
                            'terms'     => $actors_tax
                            );
        }
        
        // build rating array
        if($ratings!=''){
            $ratings_tax    =   array();
            $ratings_tax    =   explode(',', $ratings);
            $ratings_array  =   array(     
                            'taxonomy'  => 'wpstream_movie_rating',
                            'field'     => 'term_id',
                            'terms'     => $ratings_tax
                            );
        }
        
        
        
        $exclude='';
        $subscription_model = intval( wpstream_get_option('subscription_model')) ;
        
        if($subscription_model==1){
            $main_subscription  =   wpstream_get_option('subscription_global_array');
            $exclude            =   intval($main_subscription[0]);
        }
        
          
        $meta_query         =   array();                
        $orderby            =   'ID';
            
        $args = array(
            'post_type'         => $type,
            'post_status'       => 'publish',
            'paged'             => 1,
            'posts_per_page'    => $post_number_total,
            'orderby'           => $orderby,
            'order'             => 'DESC',
            'tax_query'         => array( 
                                $category_array,
                                $movie_categ,
                                $actors_array,
                                $ratings_array,
                            )

        );
        

        if($exclude!=''){
            $args[ 'post__not_in']=array($exclude);
        }
  
    } else {
        $type = 'post';
        $args = array(
            'post_type'      => $type,
            'post_status'    => 'publish',
            'paged'          => 0,
            'posts_per_page' => $post_number_total,
            'orderby'        => $orderby,
       
        );
    }


    
    if ($attributes['type'] != 'products' || $attributes['type'] != 'free products' ) {
        $class.=" blogs_wrapper ";
    }

    
    if($category!=''){
        $category.=',';
    }
    if($movie_categ!=''){
        $movie_categ.=',';
    }
    if($actors!=''){
        $actors.=',';
    }
    if($ratings!=''){
        $ratings.=',';
    }
   
    $anime_id='wpestate_sh_anime_'.rand(1,999);
    $return_string .= '<div id="'.$anime_id.'" class="article_container wpestate_latest_listings_sh bottom-'.$type.' '.$class.'"  '
            . 'data-type="'.$type.'" '
            . 'data-category_ids="'.$category.'" '
            . 'data-movie_categ_ids="'.$movie_categ.'" '
            . 'data-actors_ids="'.$actors.'" '
            . 'data-ratings_ids="'.$ratings.'" '
            . 'data-number="'.$post_number_total.'" '
            . 'data-row-number="'.$wpstream_row_number.'" '
            . 'data-align="'.$attributes['align'].'" '
            . 'data-show_featured_only="'.$show_featured_only.'"  '
            . 'data-random_pick="'.$random_pick.'"  '
            . 'data-featured_first="'.$featured_first.'" '
            . 'data-page="1" >';
    if($title!=''){
        $return_string .= '<h2 class="shortcode_title">'.$title.'</h2>';
    }
  
    
    
    
    global $post;
    $design_type    =   wpstream_get_option('wpstream_unit_card');
    $items_class    =   ' columns-'.$wpstream_row_number.' ';
            
    
    $return_string .='<ul class="products '.$items_class.'">';
    
    
    $transient_name= 'wpestate_recent_posts_pictures_query_' . $type . '_' . $category . '_' . $movie_categ . '_' . $actors . '_' . $ratings.'_'.$wpstream_row_number.'_'.$post_number_total.'_'.$featured_first.'_'.$align.'_'.$random_pick;
   
    if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
        $transient_name.='_'. ICL_LANGUAGE_CODE;
    }
   
    
    $templates = wpstream_get_transient( $transient_name);
    $templates  =   false;

    if( $templates === false || $random_pick=='yes' ) {
        
        if ($attributes['type'] == 'products' || $attributes['type'] == 'free products' ) {
            if($random_pick !=='yes'){
                $recent_posts = new WP_Query($args);
                
            }else{
                $args['orderby']    =   'rand';
                $recent_posts = new WP_Query($args); 
               
            }

        }else{
            $recent_posts = new WP_Query($args);
           
        }
        global $count;
        $count=0;
        
        $design_type=wpstream_get_option('wpstream_unit_card');
    
        ob_start();  
        global $wpstream_row_number;
        while ($recent_posts->have_posts()): $recent_posts->the_post();
        
            if($type == 'product'){
                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3_shortcode',1 );
                
                if( function_exists('wc_get_template_part') ) {  
                    wc_get_template_part( 'content', 'product' );
                }
                
                remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3_shortcode',1 );
                add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
           
            }else if($type == 'wpstream_product'){
                get_template_part('templates/free_product_unit');
            }else {
                get_template_part('templates/blog_unit');
            }

            $count++;

        endwhile;

        $templates = ob_get_contents();
        ob_end_clean(); 
        if($orderby!=='rand'){
            wpstream_set_transient( $transient_name,wpstream_html_compress( $templates ), 60*60*4 );
        }
    }
    
    
    
    
    $return_string .=$templates;

    $return_string.='</ul>';
    $return_string .=$button;
    $return_string .= '</div>';
    wp_reset_query();
    $is_shortcode       =   0;
    
    return $return_string;
    
    
}
endif; // end   wpestate_recent_posts_pictures 

    



if( !function_exists('wpstream_slider_recent_posts_pictures') ):
function wpstream_slider_recent_posts_pictures($attributes) {
    global $options;
    global $align;
    global $align_class;
    global $post;
    global $currency;
    global $where_currency;
    global $is_shortcode;
    global $show_compare_only;
    global $row_number_col;
    global $curent_fav;
    global $current_user;
    global $property_unit_slider;
    global $prop_unit;
    global $no_listins_per_row;
  
    global $custom_unit_structure;
  
    $no_listins_per_row       =   intval( wpstream_get_option('wp_estate_listings_per_row', '') );
    $prop_unit          =   'grid';
   
    
    
    $return_string      =   '';
    $pictures           =   '';
    $button             =   '';
    $class              =   '';
    $category           =   '';
    $action             =   '';
    $city               =   '';
    $area               =   '';
    $state              =   '';
    $title              =   '';
    $currency           =   esc_html( wpstream_get_option('wp_estate_currency_symbol', '') );
    $where_currency     =   esc_html( wpstream_get_option('wp_estate_where_currency_symbol', '') );
    $is_shortcode       =   1;
    $show_compare_only  =   'no';
    $row_number_col     =   '';
    $wpstream_row_number         =   '';       
    $show_featured_only =   '';
    $autoscroll         =   '';
    $property_unit_slider = wpstream_get_option('wp_estate_prop_list_slider','');
    $templates          =   '';
    $featured_first     =   'no';
    $current_user       =   wp_get_current_user();
    $userID             =   $current_user->ID;
    $user_option        =   'favorites'.$userID;
    $curent_fav         =   get_option($user_option);


   
    $title              =   '';
   
    
    $property_card_type         =   intval(wpstream_get_option('wp_estate_unit_card_type'));
    $property_card_type_string  =   '';
    if($property_card_type==0){
        $property_card_type_string='';
    }else{
        $property_card_type_string='_type'.$property_card_type;
    }
     
    $attributes = shortcode_atts( 
                array(
                    'title'                 =>  '',
                    'type'                  => 'products',
                    'category_ids'          =>  '',
                    'movie_categ_ids'            =>  '',
                    'actors_ids'            =>  '',
                    'ratings_ids'           =>  '',
                    'number'                =>  4,
                    'random_pick'           =>  'no',
                    'autoscroll'            =>  0,
                    'systemx'               =>  '',
                ), $attributes) ;
    
    if ( isset($attributes['title']) ){
        $title=$attributes['title'];
    }
    if ( isset($attributes['systemx']) ){
        $systemx=$attributes['systemx'];
    }
    
    if ( isset($attributes['category_ids']) ){
        $category=$attributes['category_ids'];
    }

    if ( isset($attributes['movie_categ_ids']) ){
        $movie_categ=$attributes['movie_categ_ids'];
    }

    if ( isset($attributes['actors_ids']) ){
        $actors=$attributes['actors_ids'];
    }

    if ( isset($attributes['ratings_ids']) ){
        $ratings=$attributes['ratings_ids'];
    }
   
    if ( isset($attributes['autoscroll']) ){
        $autoscroll=intval ( $attributes['autoscroll'] );
    }    
    
    $post_number_total = $attributes['number'];
    if ( isset($attributes['rownumber']) ){
        $wpstream_row_number        = $attributes['rownumber']; 
    }

  
    
    
    if ($attributes['type'] == 'products' || $attributes['type'] == 'free products' ) {
        if ($attributes['type'] == 'products'){
            $type                   =   'product';      
        }   else if ($attributes['type'] == 'free products' ){
            $type                   =   'wpstream_product';      
        }
     
        $category_array         =   '';
        $movie_categ_array      =   '';
        $actors_array           =   '';
        $ratings_array          =   '';
    
        // build category array
        if($category!=''){
            $category_of_tax=array();
            $category_of_tax=  explode(',', $category);
            $category_array=array(     
                            'taxonomy'  => 'product_cat',
                            'field'     => 'term_id',
                            'terms'     => $category_of_tax
                            );
        }
            
        
        // build action array
        if($movie_categ!=''){
            $movie_categ_tax    =   array();
            $movie_categ_tax    =   explode(',', $movie_categ);
            $movie_categ_array  =   array(     
                            'taxonomy'  => 'wpstream_category',
                            'field'     => 'term_id',
                            'terms'     => $movie_categ_tax
                            );
        }
        
        // build movie categ array
        if($actors!=''){
            $actors_tax     =   array();
            $actors_tax     =  explode(',', $actors);
            $actors_array   =   array(     
                            'taxonomy'  => 'wpstream_actors',
                            'field'     => 'term_id',
                            'terms'     => $actors_tax
                            );
        }
        
        // build rating array
        if($ratings!=''){
            $ratings_tax    =   array();
            $ratings_tax    =   explode(',', $ratings);
            $ratings_array  =   array(     
                            'taxonomy'  => 'wpstream_movie_rating',
                            'field'     => 'term_id',
                            'terms'     => $ratings_tax
                            );
        }
        
        
        
        
        
        
        $meta_query         =   array();                
        $orderby            =   'ID';
        
        $exclude='';
        $subscription_model = intval( wpstream_get_option('subscription_model')) ;
        if($subscription_model==1){
            $main_subscription = wpstream_get_option('subscription_global_array');

            $exclude=intval($main_subscription[0]);
        }
            
        $args = array(
            'post_type'         => $type,
            'post_status'       => 'publish',
            'paged'             => 0,
            'posts_per_page'    => $post_number_total,
            'orderby'           => $orderby,
            'order'             => 'DESC',
            'tax_query'         => array( 
                                    $category_array,
                                    $movie_categ,
                                    $actors_array,
                                    $ratings_array,
                                )

        );
        
        if($exclude!=''){
            $args[ 'post__not_in']=array($exclude);
        }
  
          
    } else {
        $type = 'post';
        $args = array(
            'post_type'      => $type,
            'post_status'    => 'publish',
            'paged'          => 0,
            'posts_per_page' => $post_number_total,
            'cat'            => $category
        );
    }



    
    $return_string .= '<div class="article_container slider_container bottom-'.$type.' '.$class.' '.$systemx.' " >';
    if($title!=''){
        $return_string .= '<h2 class="shortcode_title title_slider">'.$title.'</h2>';
    }


    $is_autoscroll  =   ' data-auto="'.$autoscroll.'" '; 
    $return_string .=   '<div class="shortcode_slider_wrapper" >';
    $transient_name =   'wpstream_recent_posts_slider_' . $type . '_' . $category . '_' . $action . '_' . $city . '_' . $area.'_'.$state.'_'.$wpstream_row_number.'_'.$post_number_total.'_'.$featured_first.'_'.$show_featured_only.'_'.$is_autoscroll;
   
    if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
        $transient_name.='_'. ICL_LANGUAGE_CODE;
    }
  
    
    global $wpstream_layout;
    $items_class    =   '';
    $items_per_row  =   2;
    $design_type    =   wpstream_get_option('wpstream_unit_card');
    
    if(isset($post->ID)){
        $wpstream_layout         = intval( get_post_meta($post->ID,'page_layout',true) );
        if($wpstream_layout==3 || $wpstream_layout==4){
            $items_class    =   ' columns-3 ';
            $items_per_row  =   3;
            
            if($design_type==2){
                $wpstream_layout         =   $items_per_row=wpstream_get_option('wpstream_unit2_per_row','');
                $items_class    =   ' columns-'.$wpstream_layout.' ';
            }
            
        }else{
            $items_class=' columns-2 ';
        }
    }
    
    
    $templates  =   wpstream_get_transient( $transient_name);
    $templates  =   false;
    if($templates === false ){

   
        $recent_posts   = new WP_Query($args);
        global $count;
        $count=0;

        ob_start();
        print '<div class="shortcode_slider_list '.$items_class.' " >';
        print '<ul class="wpstream_slick_slider  '.$items_class.'" data-items-per-row="'.$items_per_row.'" '.$is_autoscroll.'>';
        $design_type=wpstream_get_option('wpstream_unit_card');
    
    
        
            while ($recent_posts->have_posts()): $recent_posts->the_post();



                    if($type == 'product'){
                        
                        if($wpstream_layout==3 || $wpstream_layout==4){
                            remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );
                            add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3',1 );
                        }
                        
                        if(function_exists('wc_get_template_part')){
                            wc_get_template_part( 'content', 'product' );
                        }
                        
                        if($wpstream_layout==3 || $wpstream_layout==4){
                            remove_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns_per3',1 );
                            add_filter( 'loop_shop_columns', 'wpstream_wordpresstheme_woocommerce_loop_columns' );

                        }
                        
                    }else if($type == 'wpstream_product'){
                        get_template_part('templates/free_product_unit');
                    } else {
                        get_template_part('templates/blog_unit');
                    }

                    $count++;


            endwhile;
        
         print '</ul>';
       
        $templates = ob_get_contents();
        ob_end_clean(); 
        wpstream_set_transient ($transient_name,wpstream_html_compress($templates),4*60*60);
    }
    
    
    
    $return_string .=$templates;
    $return_string .=$button;
    
    $return_string .= '</div></div>';// end shrcode wrapper
    $return_string .= '</div>';
    wp_reset_query();
    wp_reset_postdata();
    $is_shortcode       =   0;
    return $return_string;
    
    
}
endif; // end   wpstream_slider_recent_posts_pictures 





if( !function_exists('wpstream_featured_product') ):
function wpstream_featured_product($attributes, $content = null) {
    $return_string  =   '';
    $prop_id        =   '';
    $design_type    =   '';
    global $backimage;
    global $featured_unit_hight;
   
    $attributes = shortcode_atts( 
                array(
                    'id'                  => '',
                    'featured_unit_hight' => '',
                    'backimage'           => '',
                    'design_type'         => 1
                ), $attributes) ;
     
    if( isset($attributes['id'])){
        $prop_id=$attributes['id'];
    }
    
    if( isset($attributes['design_type'])){
        $design_type=$attributes['design_type'];
    }
    
    if( isset($attributes['backimage'])){
        $backimage=$attributes['backimage'];
    }
    
 
    if($design_type==1){
        $backimage_array = wp_get_attachment_image_src($backimage, 'wpstrem_product_featured');
    }else{
        $backimage_array = wp_get_attachment_image_src($backimage, 'full');
    }
    $backimage=$backimage_array[0];

    $featured_unit_hight='';
    if ( isset($attributes['featured_unit_hight'])){
        $featured_unit_hight =  $attributes['featured_unit_hight'];
    }
    
    $transient_name='wpstream_featured_prop_'.$prop_id;
    if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
        $transient_name.='_'. ICL_LANGUAGE_CODE;
    }
   
    $transient_name.='_type'.$design_type;
    $return_string = wpstream_get_transient($transient_name);
    $return_string  =   false;
    if($return_string===false){
        $args = array('post_type'   => array('product','wpstream_product'),
                      'post_status' => 'publish',
                      'p'           => $prop_id
                    );

        $my_query = new WP_Query($args);
        if ($my_query->have_posts()) {
            ob_start();
            while ($my_query->have_posts()) {
                $my_query->the_post();

                if($design_type==1){
                    get_template_part('templates/featured_product_1');
                }else if($design_type==2){
                    get_template_part('templates/featured_product_2');
                }else if($design_type==3){
                    get_template_part('templates/featured_product_3');
                }

            }
            $return_string = ob_get_contents();
            ob_end_clean();  
        }

        wp_reset_query();
        wpstream_set_transient($transient_name,wpstream_html_compress($return_string),60*60*4);
    }


    return $return_string;
}
endif; // end   wpstream_featured_property



if( !function_exists('wpstream_featured_free_product') ):
function wpstream_featured_free_product($attributes, $content = null) {
    $return_string  =   '';
    $prop_id        =   '';
    $design_type    =   '';
    global $sale_line;
   
    $attributes = shortcode_atts( 
                array(
                    'id'                  => '',
                    'sale_line'           => '',
                    'design_type'         => 1
                ), $attributes) ;
     
     
    if( isset($attributes['id'])){
        $prop_id=$attributes['id'];
    }
    
    if( isset($attributes['design_type'])){
        $design_type=$attributes['design_type'];
    }
    
    
    $sale_line='';
    if ( isset($attributes['sale_line'])){
        $sale_line =  $attributes['sale_line'];
    }
    
    $transient_name='wpstream_featured_free_prop_'.$prop_id;
    if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
        $transient_name.='_'. ICL_LANGUAGE_CODE;
    }
   
    $transient_name.='_type'.$design_type;
    $return_string = wpstream_get_transient($transient_name);
    $return_string  =   false;
    if($return_string===false){
        $args = array('post_type'   => 'wpstream_product',
                      'post_status' => 'publish',
                      'p'           => $prop_id
                    );

        $my_query = new WP_Query($args);
        if ($my_query->have_posts()) {
            ob_start();
            while ($my_query->have_posts()) {
                $my_query->the_post();

                if($design_type==1){
                    get_template_part('templates/featured_free_product_1');
                }else if($design_type==2){
                    get_template_part('templates/featured_free_product_2');
                }

            }
            $return_string = ob_get_contents();
            ob_end_clean();  
        }

        wp_reset_query();
        wpstream_set_transient($transient_name,wpstream_html_compress($return_string),60*60*4);
    }


    return $return_string;
}
endif; // end   wpstream_featured_property




if( !function_exists('wpstream_featured_article') ):
function wpstream_featured_article($attributes, $content = null) {
    $return_string  =   '';
    $prop_id        =   '';
    $design_type    =   '';
    global $sale_line;
   
    $attributes = shortcode_atts( 
                array(
                    'id'                  => '',
                    'sale_line'           => '',
                    'design_type'         => 1
                ), $attributes) ;
     
     
    if( isset($attributes['id'])){
        $prop_id=$attributes['id'];
    }
    
    if( isset($attributes['design_type'])){
        $design_type=$attributes['design_type'];
    }
    
    
    $sale_line='';
    if ( isset($attributes['sale_line'])){
        $sale_line =  $attributes['sale_line'];
    }
    
    $transient_name='wpstream_featured_article_'.$prop_id;
    if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
        $transient_name.='_'. ICL_LANGUAGE_CODE;
    }
   
    $transient_name.='_type'.$design_type;
    $return_string = wpstream_get_transient($transient_name);
    $return_string  =   false;
    if($return_string===false){
        $args = array('post_type' => 'post',
                      'post_status' => 'publish',
                      'p'           => $prop_id
                    );

        $my_query = new WP_Query($args);
        if ($my_query->have_posts()) {
            ob_start();
            while ($my_query->have_posts()) {
                $my_query->the_post();

                if($design_type==1){
                    get_template_part('templates/featured_free_article_1');
                }else if($design_type==2){
                    get_template_part('templates/featured_free_article_2');
                }

            }
            $return_string = ob_get_contents();
            ob_end_clean();  
        }

        wp_reset_query();
        wpstream_set_transient($transient_name,wpstream_html_compress($return_string),60*60*4);
    }


    return $return_string;
}
endif; // end   wpstream_featured_property




if(!function_exists('wpstream_categories_slider') ):
function wpstream_categories_slider($attributes, $content = null){

    global $full_page;
    global $is_shortcode;
    global $row_number_col;
    global $place_id;
    global $place_per_row;

    $is_shortcode       = 1;
    $place_list         = '';
    $return_string      = '';
    $extra_class_name   = '';



    $attributes = shortcode_atts(
                    array(
                    'place_list'        => '',
                    'place_per_row'     => 3,
                    'extra_class_name'  => '',
                     ), 
        $attributes);

    $post_number_total = $attributes['place_per_row'];

 
    if ( isset($attributes['place_list']) ){
        $place_list = $attributes['place_list'];
    }
    
    if ( isset($attributes['place_per_row']) ){
        $place_per_row = $attributes['place_per_row'];
    }
    
    if($place_per_row>5){
        $place_per_row = 5;
    }

    if( isset($attributes['extra_class_name'])){
        $extra_class_name = $attributes['extra_class_name'];
    }

    
    $all_places_array = explode(',', $place_list);
    $slide_cont = '';
    
    
    foreach( $all_places_array as $single_term){
        $place_id = intval( $single_term );
        ob_start();
    
        get_template_part('templates/category_unit');
        $slide_cont_tmp = ob_get_clean();
        
        if( $slide_cont_tmp && trim($slide_cont_tmp) != '' ){
            $slide_cont .= '<div class="single_slide_container">';
            $slide_cont .= $slide_cont_tmp;
            $slide_cont .= '</div>';
        }

    }

    $return_string = '<div class="wpstream_categories_slider '.$extra_class_name.'"  data-items-per-row="'.$place_per_row.'" data-auto="0" >'. $slide_cont.'</div>';
    //ob_end_clean(); 
    $is_shortcode = 0;
    return $return_string;
}
endif; // end wpstream_categories_slider 



if( !function_exists('wpstream_category_list_function') ):
function wpstream_category_list_function($attributes, $content = null) {
    $place_list='';
    $return_string ='';
    $status         ='';
    $extra_class_name='';
    $place_type         = '';
    global $featured_unit_hight;
    $attributes = shortcode_atts( 
        array(
            'place_list'             => '',
            'extra_class_name'       => '',
            'status'                 => '',
            'featured_unit_hight'    => '',
            'place_type'             => 1,
        ), $attributes) ;


    
    if ( isset($attributes['place_list']) ){
        $place_list=$attributes['place_list'];
    }

    if( isset($attributes['extra_class_name'])){
        $extra_class_name=$attributes['extra_class_name'];
    }    
    
    if ( isset($attributes['status']) ){
        $status=$attributes['status'];
    }
    
    $featured_unit_hight='';
    if ( isset($attributes['featured_unit_hight'])){
        $featured_unit_hight =  $attributes['featured_unit_hight'];
    }
    
    if ( isset($attributes['place_type']) ){
        $place_type        = $attributes['place_type']; 
    }
    
    //$return_string .=$place_list;
    
    $all_places_array=  explode(',', $place_list);
    
   // $return_string .='<div class="places_wrapper '.$extra_class_name.' ">';
    foreach($all_places_array as $place_id){
        
        $place_id=intval($place_id);
        $category_attach_id             =   '';
        $category_tax                   =   '';
        $category_featured_image        =   '';
        $category_name                  =   '';
        $category_featured_image_url    =   '';
        $term_meta                      =   get_option( "taxonomy_$place_id");
        $category_tagline               =   '';
        $category_count                 =   '';
        
        if(isset($term_meta['category_featured_image'])){
            $category_featured_image    =   $term_meta['category_featured_image'];
        }
        
        if(isset($term_meta['category_attach_id'])){
            $category_attach_id         =   $term_meta['category_attach_id'];
            $category_featured_image    =   wp_get_attachment_image_src( $category_attach_id, 'wpstrem_product_featured');
            $category_featured_image_url=   $category_featured_image[0];
        }
        
        if(isset($term_meta['category_tax'])){
            $category_tax           =   $term_meta['category_tax'];
            $term                   =   get_term( $place_id, $category_tax);
            $category_name          =   $term->name;
            $category_count         =   $term->count;
        }
       
         if(isset($term_meta['category_tagline'])){
            $category_tagline   =  stripslashes( $term_meta['category_tagline'] );           
        }
     
        $term_link =  get_term_link( $place_id, $category_tax );
        if ( is_wp_error( $term_link ) ) {
            $term_link='';
        }
        
         
        if($category_featured_image_url==''){
            $category_featured_image_url=get_template_directory_uri().'/img/defaultimage.jpg';
        }
        
      

        $category_count = sprintf( _n( 'One Item', '%s Items', $category_count, 'wpstream-wordpresstheme' ), $category_count );
         
        if($place_type==1){

            $return_string .= '<div class="featured_category_wrapper featured_category'.$place_type.' '.$extra_class_name.'" data-link="'.$term_link.'" style="height:'.$featured_unit_hight.'px;">';
            $return_string .= '<div class="product_slider_image_back"  style="background-image:url('.$category_featured_image_url.');"></div>';
            $return_string .= '<div class="listing-hover-gradient"></div><div class="product_new_details_back"></div>';      
            $return_string .= '<div class="category_details"><div class="category_status">'.$status.'</div>';
            $return_string .= '<a class="featured_category_title" href="'.$term_link.'">'.$category_name.'</a>';
            $return_string .= '<div class="category_tagline">'.$category_tagline.'</div>';
            $return_string .= '<div class="categories_slider_type_1_listings_no">'.$category_count.'</div></div>';
            $return_string .= '</div>';  
        }else{
            $return_string .= '<div class="featured_category_wrapper featured_category'.$place_type.' '.$extra_class_name.'" data-link="'.$term_link.'" >';      
            $return_string .= '<div class="featured_category_image">';
            $return_string .= '<div class="product_slider_image_back"  style="background-image:url('.$category_featured_image_url.');"></div>';
            $return_string .= '<div class="product_new_details_back"></div>';
            $return_string .= '<div class="categories_slider_type_1_listings_no">'.$category_count.'</div></div>';
               
            $return_string .= '<div class="category_name"><a class="featured_category_title" href="'.$term_link.'">'.$category_name.'</a>';
            $return_string .= '<div class="category_tagline">'.$category_tagline.'</div></div>';
         
            $return_string .= '</div>';  
        }
        
        
  
        
    }

    
    return $return_string;
     
}
endif;






function wpstream_return_article_array(){
    $article_array = wpstream_get_transient ('wpstream_js_composer_article_array');
    if($article_array === false){
        $args_inner = array(
                'post_type' => array( 'post'),
                'showposts' => -1
        );
        $all_article_packages = get_posts( $args_inner );
        if( count($all_article_packages) > 0 ){
                foreach( $all_article_packages as $single_package ){
                        $temp_array=array();
                        $temp_array['label'] = $single_package->post_title;
                        $temp_array['value'] = $single_package->ID;

                        $article_array[] = $temp_array;
                }
        }
        wpstream_set_transient('wpstream_js_composer_article_array',$article_array,60*60*4);
    }
    return $article_array;
}
   


add_action( 'create_term',  'wpstream_redo_woo_transient' );
add_action( 'edit_term',    'wpstream_redo_woo_transient' );
add_action( 'delete_term',  'wpstream_redo_woo_transient' );

function wpstream_redo_woo_transient(){
    delete_transient('wpstream_woo_category_values');
    wpstream_generate_woo_category_values_shortcode();
}


function wpstream_generate_woo_category_values_shortcode(){
     
        $property_category_values = get_transient('wpstream_woo_category_values');

        if($property_category_values===false){
            $terms_category = get_terms( array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
            ) );

            if( is_array($terms_category) ){
                foreach($terms_category as $term){

                    $temp_array=array();
                    $temp_array['label'] = $term->name;
                    $temp_array['value'] = $term->term_id;

                    $property_category_values[] = $temp_array;
                }
            }
           
            set_transient('wpstream_woo_category_values',$property_category_values,60*60*4);
        }
        return $property_category_values;
}



///////////////////////////////////////////////////////////////////////////////////////////
// register form  function
///////////////////////////////////////////////////////////////////////////////////////////

if( !function_exists('wpstream_register_form_function') ):
    function wpstream_register_form_function($attributes, $content = null) {
        global $wpestate_login_register;
        return  '<div class="wpestate_login_register_wrapper">'.$wpestate_login_register->show_register_form('shortcode').'</div>';
    }
endif; // end   wpstream_register_form_function   




///////////////////////////////////////////////////////////////////////////////////////////
// Login form  function
///////////////////////////////////////////////////////////////////////////////////////////

if( !function_exists('wpstream_login_form_function') ):  
    function wpstream_login_form_function($attributes, $content = null) {
        global $wpestate_login_register;
        $attributes = shortcode_atts( 
        array(
            'register_label'                  => '',
            'register_url'                =>  '',

        ), $attributes) ;  
        
        $return_string= '<div class="wpestate_login_register_wrapper">'. $wpestate_login_register->show_login_form('shortcode');
                
        if(isset($attributes['register_label']) && $attributes['register_label']!=''){
            $return_string.='<a href="'.$attributes['register_url'].'">'.$attributes['register_label'].'</a> ';
        }  
        $return_string.='</div>';
 
        return $return_string;
        
        
}
endif; // end   wpstream_login_form_function 








/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  shortcode - memerbership packages function
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if( !function_exists('wpstream_membership_packages_function') ):
function wpstream_membership_packages_function($atts, $content=null){
    $package_id       =  '';
    $pack_featured_sh =  array('no','yes');
    $package_content  = '';
    $return_string='';
    $attributes = shortcode_atts(
            array(
                    'package_id'        => '',
                    'pack_featured_sh'  => 'no',
                    'package_content'   =>''
                      
            ), $atts);
   
    if ( isset($attributes['package_id']) ){
            $package_id=$attributes['package_id'];
    	}
    if ( isset($attributes['pack_featured_sh']) ){
        $pack_featured_sh=$attributes['pack_featured_sh'];
    }
    if ( isset($attributes['package_content']) ){
        $package_content=$attributes['package_content'];
    }
    
    
 
  
    
    if($pack_featured_sh=='yes'){
        $pack_featured_sh='featured_pack_sh';                         
    }else{
        $pack_featured_sh='';
    }
    
    $pack_price             = get_post_meta($package_id, 'pack_price', true);
    $biling_period          = get_post_meta($package_id, 'biling_period', true);
    $billing_freq           = get_post_meta($package_id, 'billing_freq', true);
    $pack_image_included    = get_post_meta($package_id, 'pack_image_included', true);
    $pack_featured          = get_post_meta($package_id, 'pack_featured_listings', true);
    $currency           =   esc_html( get_option('wp_estate_submission_curency', '') );
    $where_currency     =   esc_html( get_option('wp_estate_where_currency_symbol', '') );
    if($billing_freq>1){
        $biling_period.='s';
    }
    
    
  
    
    switch (strtolower($biling_period)) {
        case 'day':
            $biling_period=esc_html__('Day','wpstream-wordpresstheme');
            break;
        case 'days':
            $biling_period=esc_html__('Days','wpstream-wordpresstheme');
            break;
        case 'week':
            $biling_period=esc_html__('Week','wpstream-wordpresstheme');
            break;
        case 'weeks':
            $biling_period=esc_html__('Weeks','wpstream-wordpresstheme');
            break;
        case 'month':
            $biling_period=esc_html__('Month','wpstream-wordpresstheme');
            break;
        case 'month':
            $biling_period=esc_html__('Months','wpstream-wordpresstheme');
            break;
        case 'year':
            $biling_period=esc_html__('Year','wpstream-wordpresstheme');
            break;
        case 'years':
            $biling_period=esc_html__('Years','wpstream-wordpresstheme');
            break;
    }
    
    
    
    
    
    
    if (intval($pack_image_included)==0){
        $pack_image_included=esc_html__('Unlimited', 'wpstream-wordpresstheme');
    }
    
    
    $pack_list              = get_post_meta($package_id, 'pack_listings', true);
    $unlimited_listings     = get_post_meta($package_id, 'mem_list_unl', true);
    if($unlimited_listings==1){
        $unlimited_listings_sh='<div><strong>'.esc_html__('Unlimited', 'wpstream-wordpresstheme').' </strong> '.esc_html__('Products', 'wpstream-wordpresstheme').' </div>';
    }else{
        $unlimited_listings_sh='<div><strong> '.$pack_list.'</strong>  '.esc_html__('Products', 'wpstream-wordpresstheme').' </div>';
    }
                            

    
        
  
   $link   =   get_home_url();
   // $link   =   add_query_arg('packet',$package_id,$link);
    $return_string.='<div class="membership_package_product '.$pack_featured_sh.'">'
                    .'<h4>'.get_the_title($package_id).'</h4>'
                    .'<div class="pack-price_sh"></div>' 
                    .'<div class="pack_content">'.$package_content.'</div>' 
                    .'<div class="pack-bill_freg_sh"><strong>'.$billing_freq.'</strong> '.$biling_period.'</div>'
                    .'<div class="pack-listing_sh"> '.$unlimited_listings_sh.'</div>'
                    .'<div class="pack-listing-period_sh"><strong> '.$pack_image_included.'</strong>  '.esc_html__('Images ', 'wpstream-wordpresstheme').'</div> '
                    .'<div class="pack-listing_feat_sh"><strong> '.$pack_featured.'</strong> '.esc_html__('Featured Products', 'wpstream-wordpresstheme').'</div> '
                    .'<div class="buy_package_sh"><a href="'.$link.'" class="wpstream_button">'.esc_html__('Get started', 'wpstream-wordpresstheme').'</a></div>'
            
                    .'</div>';
  
  
    return '<div class="article_container">'.$return_string.'</div>';
      
  }
endif;//end memerbership packages function



function wpstream_generate_woo_movie_category_values_shortcode(){
    global $all_tax;
    global $all_tax_labels;
    
    $property_action_category_values = wpstream_get_transient('wpstream_woo_movie_category_values');
    $property_action_category_values=false;
    if($property_action_category_values===false){
        $terms_category = get_terms( array(
            'taxonomy' => 'wpstream_category',
            'hide_empty' => false,
        ) );
        print_r($terms_category);

        if( is_array($terms_category) ){
            foreach($terms_category as $term){

                $temp_array=array();
                $temp_array['label'] = $term->name;
                $temp_array['value'] = $term->term_id;
                $all_tax[]=$temp_array;
                $action_array[]=$temp_array;
                $all_tax_labels[$term->term_id]=  $term->name;
                // tax based_array
                $property_action_category_values[] = $temp_array;

            }
        }
        wpstream_set_transient('wpstream_woo_movie_category_values_label',$all_tax_labels,60*60*4);
        wpstream_set_transient('wpstream_woo_movie_category_values',$property_action_category_values,60*60*4);
    }
    return $property_action_category_values;
}






function wpstream_generate_actors_category_values_shortcode(){
    global $all_tax;
    global $all_tax_labels;
    $movie_actors_values = wpstream_get_transient('wpstream_woo_actors_category_values');
$movie_actors_values=false;
    if($movie_actors_values===false){
        $terms_actors= get_terms( array(
            'taxonomy' => 'wpstream_actors',
            'hide_empty' => false,
        ) );
      
        
        if( is_array($terms_actors) ){
            foreach($terms_actors as $term){
                $places[$term->name]= $term->term_id;
                $temp_array=array();
                $temp_array['label'] = $term->name;
                $temp_array['value'] = $term->term_id;
                $all_tax[]=$temp_array;

                $all_tax_labels[$term->term_id]=  $term->name;
                // tax based_array
                $movie_actors_values[] = $temp_array;
            }
        }
        
        
        wpstream_set_transient('wpstream_woo_actors_category_values_label',$all_tax_labels,60*60*4);
        wpstream_set_transient('wpstream_woo_actors_category_values',$movie_actors_values,60*60*4);
    }
    return $movie_actors_values;
}


function wpstream_generate_woo_product_tax_values_shortcode(){
    global $all_tax;    
    global $all_tax_labels;
    $product_categ_values = wpstream_get_transient('wpstream_woo_product_cat');
    $product_categ_values=false;
    if($product_categ_values===false){
        $product_cat= get_terms( array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ) );
        
        
       
        if( is_array($product_cat) ){
            foreach($product_cat as $term){
                $places[$term->name]= $term->term_id;
                $temp_array=array();
                $temp_array['label'] = $term->name;
                $temp_array['value'] = $term->term_id;
                $all_places[]=$temp_array;
                $area_array[]=$temp_array;
                $all_tax[]=$temp_array;
                $all_tax_labels[$term->term_id]=  $term->name;
                // tax based_array
                $product_cat_values[] = $temp_array;

            }
        }
        wpstream_set_transient('wpstream_woo_product_cat_label',$all_tax_labels,60*60*4);
        wpstream_set_transient('wpstream_woo_product_cat',$product_cat_values,60*60*4);
    }
    
    return $product_cat_values;
}





function wpstream_generate_movie_rating_category_values_shortcode(){
    global $all_tax;    
    global $all_tax_labels;
    $movie_rating_values = wpstream_get_transient('wpstream_woo_movie_rating_category_values');
    $movie_rating_values=false;
    if($movie_rating_values===false){
        $movie_ratiog= get_terms( array(
            'taxonomy' => 'wpstream_movie_rating',
            'hide_empty' => false,
        ) );
        if( is_array($movie_ratiog) ){
            foreach($movie_ratiog as $term){
                $places[$term->name]= $term->term_id;
                $temp_array=array();
                $temp_array['label'] = $term->name;
                $temp_array['value'] = $term->term_id;
                $all_places[]=$temp_array;
                $area_array[]=$temp_array;
                $all_tax[]=$temp_array;
                $all_tax_labels[$term->term_id]=  $term->name;
                // tax based_array
                $movie_rating_values[] = $temp_array;

            }
        }
        wpstream_set_transient('wpstream_woo_movie_rating_category_values_label',$all_tax_labels,60*60*4);
        wpstream_set_transient('wpstream_woo_movie_rating_category_values',$movie_rating_values,60*60*4);
    }
    
    return $movie_rating_values;
            
}


function wpstream_generate_all_tax(){
    global $all_tax;
    $all_tax1 =    wpstream_get_transient('wpstream_js_composer_all_tax');
    if($all_tax1===false){
        wpstream_set_transient('wpstream_js_composer_all_tax',$all_tax,60*60*4);
    }
    $all_tax=$all_tax1;
    return $all_tax;
}
       


function wpstream_generate_all_tax_labels(){
    global $all_tax_labels;
    $all_tax1 =    wpstream_get_transient('wpstream_js_composer_all_tax_labels');
    if($all_tax1===false){
        wpstream_set_transient('wpstream_js_composer_all_tax_labels',$all_tax_labels,60*60*4);
    }
    $all_tax_labels=$all_tax1;
    return $all_tax_labels;
}



  
function wpstream_return_agent_array(){
    $agent_array = wpstream_get_transient('wpstream_js_composer_agent_array');

    if($agent_array ===false ){
        $args_inner = array(
            'post_type' => array( 'estate_agent',
                                'estate_agency',
                                'estate_developer'),
            'showposts' => -1
        );
        $all_agent_packages = get_posts( $args_inner );
        if( count($all_agent_packages) > 0 ){
                foreach( $all_agent_packages as $single_package ){
                        $temp_array=array();
                        $temp_array['label'] = $single_package->post_title;
                        $temp_array['value'] = $single_package->ID;

                        $agent_array[] = $temp_array;
                }
        }
        wpstream_set_transient('wpstream_js_composer_agent_array',$agent_array,60*60*4);
    }
    return $agent_array;
}


if( !function_exists('wpstream_page_details_sh') ):
    function wpstream_page_details_sh($post_id){
    
    $return_array=array();
   
    if($post_id !='' && !is_home() && !is_tax() ){      
       $sidebar_name   =  esc_html( get_post_meta($post_id, 'sidebar_select', true) );
       $sidebar_status =  esc_html( get_post_meta($post_id, 'sidebar_option', true) );
    }else{
        $sidebar_name   = esc_html( wpstream_get_option('wp_estate_blog_sidebar_name', '') );
        $sidebar_status = esc_html( wpstream_get_option('wp_estate_blog_sidebar', '') );
    }
   
    
    
    if(''==$sidebar_name){
        $sidebar_name='primary-widget-area';
    }
    if(''==$sidebar_status){
        $sidebar_status='right';
    }
   
     
    
    if( 'left'==$sidebar_status ){
        $return_array['content_class']  =   'col-md-9 col-md-push-3 rightmargin';
        $return_array['sidebar_class']  =   'col-md-3 col-md-pull-9 ';      
    }else if( $sidebar_status=='right'){
        $return_array['content_class']  =   'col-md-9 rightmargin';
        $return_array['sidebar_class']  =   'col-md-3';
    }else{
        $return_array['content_class']  =   'col-md-12';
        $return_array['sidebar_class']  =   'none';
    }
    
    $return_array['sidebar_name']  =   $sidebar_name;
   
    return $return_array;

}
endif; // end   wpstream_page_details 