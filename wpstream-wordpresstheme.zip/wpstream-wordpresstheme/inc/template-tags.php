<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WpStream WordpressTheme
 */


//DE STERS

if ( ! function_exists( 'wpstream_wordpresstheme_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function wpstream_wordpresstheme_posted_on() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		echo '<span class="posted-on"><i class="fas fa-calendar-alt"></i>' . $time_string . '</span>'; 

	}
endif;

if ( ! function_exists( 'wpstream_wordpresstheme_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function wpstream_wordpresstheme_posted_by() {
		$byline = sprintf(
			'<span class="author vcard"><i class="fas fa-edit"></i><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		echo '<span class="byline"> ' . $byline . '</span>'; 

	}
endif;


if ( ! function_exists( 'wpstream_wordpresstheme_post_comments' ) ) :
	function wpstream_wordpresstheme_post_comments() {
            $post_comments =get_comments_number( '0','1','%');
    
            echo '<span class="post_comments"><i class="far fa-comment"></i> ' . $post_comments . ' ' . esc_html__( 'comments', 'wpstream-wordpresstheme' ) . '</span>'; 

	}
endif;

if ( ! function_exists( 'wpstream_wordpresstheme_post_categories' ) ) :
	function wpstream_wordpresstheme_post_categories() {
                    if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list( esc_html__( ', ', 'wpstream-wordpresstheme' ) );
				echo'<span class="cat-links"><i class="fas fa-tag"></i>'.$categories_list.'</span>';
                    }
        }

endif;



if ( ! function_exists( 'wpstream_wordpresstheme_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function wpstream_wordpresstheme_entry_footer() {
		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() ) {
			
			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'wpstream-wordpresstheme' ) );
			if ( $tags_list ) {
				/* translators: 1: list of tags. */
				echo '<span class="tags-links"><span class="tags-text"><i class="fas fa-tags"></i>' . esc_html__( 'Tags:  ', 'wpstream-wordpresstheme' ).'</span> '.$tags_list.'</span>'; 
			}
		}

                
                 ?> 


                <!-- show share options --> 
                <div class="blog_social_share">
                    <a href="http://www.facebook.com/sharer.php?u=<?php echo esc_url(get_permalink()); ?>&amp;t=<?php echo urlencode(get_the_title()); ?>" target="_blank" class="share_facebook"><i class="fab fa-facebook-square"></i></a>
                    <a href="http://twitter.com/home?status=<?php echo urlencode(get_the_title() .' '. esc_url(get_permalink())); ?>" class="share_tweet" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://plus.google.com/share?url=<?php echo esc_url(get_permalink()); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" class="share_google"><i class="fab fa-google-plus-g fa-2"></i></a> 
                    <?php if (has_post_thumbnail()){
                            $pinterest = wp_get_attachment_image_src(get_post_thumbnail_id(),'full');
                        }
                        if (isset($pinterest[0])){ 
                        ?>
                        <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url(get_permalink()); ?>&amp;media=<?php print $pinterest[0];?>&amp;description=<?php echo urlencode(get_the_title()); ?>" target="_blank" class="share_pinterest"> <i class="fab fa-pinterest-p fa-2"></i> </a>      
                    <?php } ?>
                    <a href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php print urlencode(get_the_title()); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    <a href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php print urlencode(get_the_title()); ?>" target="_blank"><i class="fab fa-reddit-alien"></i></a>
                    <a href="mailto:?subject=<?php print urlencode(get_the_title()); ?>&amp;body=<?php the_permalink(); ?>" target="_blank"><i class="fas fa-envelope"></i></a>
               
                </div>
                
                <!-- end share --> 
                
                <!-- show author --> 
                <?php if ( get_the_author_meta( 'description' ) ) { // If a user has filled out their description, show a bio on their entries  ?>
                        <div id="wrapper_author-info">
                              <?php print get_avatar( get_the_author_meta( 'user_email' ), 80 ); ?>
                            <div id="post_author_details">
                                <div class="author_name"><?php  the_author_meta( 'display_name' );?></div>
                                <p class="author_email"><?php  the_author_meta( 'user_email' );?></p>
                                <p><?php the_author_meta( 'description' ); ?></p>
                            </div>
                         </div><!-- #entry-author-info -->
                <?php } ?>
                <!-- end author --> 
          
                <?php 
                
   
       
        
                
	}
endif;

if ( ! function_exists( 'wpstream_wordpresstheme_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function wpstream_wordpresstheme_post_thumbnail() {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>

			<div class="post-thumbnail">
                            <?php 
                            
                   
                                the_post_thumbnail(); 
                                global $post;
                                $post_local_video               =   get_post_meta($post->ID, 'post_local_video', true);
                                $post_external_video            =   get_post_meta($post->ID, 'post_external_video', true);
                                $post_external_video_id         =   get_post_meta($post->ID, 'post_external_video_id', true);


                                if($post_local_video!='' || $post_external_video_id!=''){
                                    print '<div class="featured_gradient"></div>';
                                    print wpstream_post_play_video($post->ID);
                                }
                            ?>

			</div><!-- .post-thumbnail -->

		<?php else : ?>

		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			the_post_thumbnail( 'post-thumbnail', array(
				'alt' => the_title_attribute( array(
					'echo' => false,
				) ),
			) );
			?>
		</a>

		<?php
		endif; // End is_singular().
	}
endif;

