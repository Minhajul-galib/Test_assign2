<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WpStream WordpressTheme
 */

get_header();
global $wpstream_row_number;
$wpstream_row_number=2;
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<div class="archive-description">', '</div>' );
				?>
			</header><!-- .page-header -->
                        
            <div class="blog_list_wrapper">
                
			<?php
			/* Start the Loop */
                        echo '<ul class="blog_list_wrapper_list">';
                            while ( have_posts() ) :the_post();

                                     get_template_part('templates/blog_unit');

                            endwhile;
                        echo '</ul>';
                        wp_reset_query();
			the_posts_navigation();
                        wpstream_pagination('', $range = 2);            

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
            </div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();
