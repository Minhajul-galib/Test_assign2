<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WpStream WordpressTheme
 */



global $post;
if(isset($post->ID)){
    $wpstream_layout         = intval( get_post_meta($post->ID,'page_layout',true) );
    $sidebar_name   = get_post_meta($post->ID,'sidebar_select',true);
    
    if($wpstream_layout==3 or $wpstream_layout==4){
        return;
    }
}
?>


<?php if ( ! class_exists( 'WooCommerce' ) || 
        (  class_exists( 'WooCommerce' ) && !is_cart() && !is_checkout() && !is_account_page() ) 
        ){ ?>
<aside id="secondary" class="widget-area">
    <div class="sidebar-wrapper">
	<?php dynamic_sidebar( $sidebar_name ); ?>
    </div>    
</aside><!-- #secondary -->
<?php } ?>